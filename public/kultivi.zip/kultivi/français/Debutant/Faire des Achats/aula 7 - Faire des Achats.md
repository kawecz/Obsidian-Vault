---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Faire Des Achats | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/EWNz4V8W9n0?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Compras e Vestuário (_Faire des Achats et Vêtements_)

---

### 🎯 Visão Geral da Aula

Esta aula se concentra no vocabulário e nas estruturas de diálogo utilizadas para **fazer compras**. É apresentada a diferença sutil entre _faire des achats_ (compras em geral, como roupas ou móveis) e _faire des courses_ (compras de supermercado/alimentos). A lição explora os principais locais de compra e introduz a conjugação de dois verbos essenciais: **Acheter (Comprar)** e **Payer (Pagar)**. O foco prático está no vocabulário de **Vestuário (_Vêtements_)** e nas expressões formais de interação em lojas.

### [[aula7.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## 🛍️ Vocabulário de Compras e Locais

### Distinção de Tipos de Compra

|Expressão|Tradução Literal|Sentido em Francês|
|---|---|---|
|**Faire des achats**|Fazer compras|Compras de bens duráveis (roupas, móveis, eletrodomésticos).|
|**Faire des courses**|Fazer corridas|Compras de alimentos e itens de mercado.|

### Locais de Compra (_Les Lieux_)

|Local|Francês|Gênero|Observação|
|---|---|---|---|
|Supermercado|**Un supermarché**|Masc.|Para _faire des courses_.|
|Feira (de rua)|**Un marché**|Masc.|Sem o _super_, é a feira livre.|
|Padaria|**Une boulangerie**|Fem.|Local de grande importância cultural na França.|
|Loja|**Un magasin**|Masc.|_Magasin de vêtements_ (loja de roupas).|
|**ATENÇÃO**|**Un magazine**|Masc.|Significa **revista** (falso cognato).|
|Shopping|**Un centre commercial**|Masc.|Usado no lugar de "shopping".|

## Verbos Essenciais: Acheter e Payer

### 1. Acheter (Comprar)

Este verbo apresenta uma mudança de vogal na conjugação (o 'e' do radical vira 'è' em algumas pessoas).

|Pessoa|Conjugação|Pronúncia Aproximada|
|---|---|---|
|Je|**J'achète**|_Jashét_|
|Tu|**Tu achètes**|_Tu ashét_|
|Il/Elle/On|**Il/Elle/On achète**|_Il/Elle ashét_|
|Nous|**Nous achetons**|_Nous ashetõ_|
|Vous|**Vous achetez**|_Vous ashetê_|
|Ils/Elles|**Ils/Elles achètent**|_Ils/Elles ashét_|

### 2. Payer (Pagar)

Este verbo com 'y' (y grego) tem duas conjugações possíveis, sendo a mais comum a que troca o 'y' por 'i' nas formas do singular e na terceira pessoa do plural.

|Pessoa|Conjugação (Y -> I)|Observação|
|---|---|---|
|Je|**Je paie**|Mais comum.|
|Tu|**Tu paies**||
|Il/Elle/On|**Il/Elle/On paie**||
|Nous|**Nous payons**|O 'y' é mantido.|
|Vous|**Vous payez**|O 'y' é mantido.|
|Ils/Elles|**Ils/Elles paient**||

## 👗 Vocabulário: Les Vêtements (As Roupas)

O vocabulário é dividido pelo gênero do substantivo, crucial para a concordância.

### Masculino (_Masculin_)

|Item|Francês|Significado|
|---|---|---|
|Calça|**Un pantalon**||
|Suéter/Pulôver|**Un pull**||
|Camiseta|**Un t-shirt**|Pronunciado: _Tee-chirt_.|
|Terno/Conjunto|**Un tailleur**|Conjunto social (costume).|
|Jeans|**Un jean**|Usado no singular (_un jean_).|

### Feminino (_Féminin_)

|Item|Francês|Significado|
|---|---|---|
|Camisa (Social)|**Une chemise**||
|Gravata|**Une cravate**||
|Saia|**Une jupe**||
|Vestido|**Une robe**||

### Neutro/Unisex ou Uso Misto

|Item|Francês|Gênero do Substantivo|
|---|---|---|
|Casaco/Jaqueta|**Un manteau**|Masc. (Mais pesado)|
|Paletó/Blazer|**Une veste**|Fem. (Mais leve)|
|Sapato|**Une chaussure**|Fem. (Sapatos em geral, plural **les chaussures**).|
|Tênis|**Des baskets**|Fem. (Geralmente no plural).|
|Salto|**Des talons**|Masc. (Sapatos de salto, sempre no plural).|

## 💬 Expressões de Compra e Pagamento

### Pedir Informação e Mostrar Satisfação

|Expressão|Uso|Significado (PT-BR)|
|---|---|---|
|**Taille**|Substantivo|Tamanho (de roupa).|
|**Modèle**|Substantivo|Modelo.|
|**Ça vous plaît ? / Ça te plaît ?**|Pergunta|Isso lhe agrada? (Formal/Informal).|
|**Ça me plaît bien !**|Resposta|Sim, eu gosto bastante!|

### Preço

|Função|Expressão em Francês|Significado (PT-BR)|
|---|---|---|
|**Perguntar**|**Ça coûte combien ?**|Quanto custa isso?|
|**Perguntar**|**Quel est le prix ?**|Qual é o preço?|
|**Responder**|**Ça coûte [preço] euros.**|Isso custa [preço] euros.|
|**Responder (Informal)**|**Ça fait [preço] euros.**|Dá [preço] euros.|
|**Caro**|**C'est cher.**|É caro.|
|**Barato (Literal)**|**Ce n'est pas cher.**|Não é caro.|
|**Barato (Informal)**|**C'est bon marché.**|É bom negócio (barato).|

### Formas de Pagamento

|Forma|Francês|
|---|---|
|Dinheiro (Espécie)|**Par espèces** (ou _en espèces_)|
|Cheque|**Par chèque**|
|Cartão|**Par carte**|

---

## 📚 Tópicos Gramaticais Chave

### Substantivos (_Les Noms_)

|Palavra|Gênero|Significado (PT-BR)|
|---|---|---|
|**Les achats**|Masc. Plural|As compras (em geral).|
|**Les courses**|Fem. Plural|As compras (de mercado).|
|**Le magasin**|Masc. Singular|A loja.|
|**La boulangerie**|Fem. Singular|A padaria.|
|**La chemise**|Fem. Singular|A camisa.|
|**Le manteau**|Masc. Singular|O casaco (pesado).|
|**La taille**|Fem. Singular|O tamanho.|

### Adjetivos (_Les Adjectifs_)

|Palavra|Forma|Significado (PT-BR)|
|---|---|---|
|**Cher / Chère**|Variável|Caro / Cara (Concorda com o item, e.g., _une chemise chère_).|
|**Social / Sociale**|Variável|Social (Em _chemise sociale_ ou _costume social_).|
|**Commercial**|Masc. Sing.|Comercial (Em _centre commercial_).|
|**Long / Longue**|Variável|Longo / Longa (Em _jupe longue_).|

### Preposições e Conectores (_Les Prépositions et Mots de Liaison_)

|Palavra|Significado (PT-BR)|Função no Contexto|
|---|---|---|
|**dans**|em, dentro de|Indica o local (_dans un supermarché_).|
|**de**|de|Especifica o tipo de loja (_magasin **de** vêtements_).|
|**par**|por, via|Indica o método de pagamento (_payer **par** carte_).|
|**ou**|ou|Alternativa (_par chèque **ou** par carte_).|