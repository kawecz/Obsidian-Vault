---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Le Futur Proche | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/UZChK7MAHM0?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: O Futuro Próximo (_Le Futur Proche_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #22) introduz o **Futuro Próximo** (_Futur Proche_), um tempo verbal simples e extremamente comum, usado para falar de planos ou eventos que acontecerão em breve (hoje, amanhã, semana que vem).

O _Futur Proche_ em francês é o equivalente exato do português **"ir + infinitivo"** (Ex: "Eu **vou comer**").

### [[aula22.pdf]]
---

### ⏳ Linha do Tempo dos Tempos Verbais

Até agora, trabalhamos apenas com o **Présent** (Presente). O _Futur Proche_ se localiza logo após o presente na linha do tempo.

![](data:,)

---

### 1️⃣ Estrutura do Futur Proche

O _Futur Proche_ é formado pela conjugação do verbo **Aller** no presente, seguida do verbo principal no **Infinitivo**.

![](data:,)

#### Conjugação do Verbo Aller (Irregular – Revisão)

O verbo **Aller** é o único verbo auxiliar necessário para o _Futur Proche_.

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**vais**|**Nous**|**allons**|
|**Tu**|**vas**|**Vous**|**allez**|
|**Il/Elle/On**|**va**|**Ils/Elles**|**vont**|

#### Exemplos de Aplicação

|Estrutura|Exemplo em Francês|Significado (PT-BR)|
|---|---|---|
|![](data:,)|**Tu vas cuisiner** ce soir.|Você **vai cozinhar** essa noite.|
||**Nous allons aller** au cinéma.|Nós **vamos ir** ao cinema. (Perfeitamente normal, como em português).|
||**Ils vont acheter** du vin.|Eles **vão comprar** vinho.|
||**Il va rentrer** à la maison.|Ele **vai voltar** para casa.|

---

### 2️⃣ O Futur Proche na Negativa

A negação (**ne... pas**) sempre envolve o verbo conjugado, que, neste caso, é o verbo **Aller**. O verbo no infinitivo permanece fora da negação.

|Estrutura|Exemplo em Francês|Significado (PT-BR)|
|---|---|---|
|![](data:,)|**Je ne vais pas rester** longtemps.|Eu não **vou ficar** muito tempo.|
|![](data:,)|**Il ne va pas faire** la fête.|Ele não **vai fazer** a festa.|
|![](data:,)|**Nous n'allons pas travailler** demain.|Nós não **vamos trabalhar** amanhã.|

**Cuidado:** O verbo principal (**rester, faire, travailler**) sempre fica fora do _ne... pas_.

---

### 3️⃣ Vocabulário e Expressões Úteis

|Expressão|Significado (PT-BR)|
|---|---|
|**Bientôt**|Em breve|
|**Demain**|Amanhã|
|**La semaine prochaine**|A semana que vem|
|**Faire une randonnée**|Fazer uma caminhada (trilha)|
|**Rentrer**|Voltar para casa|
|**Faire la grasse matinée**|Dormir até tarde|
|**Faire les courses**|Fazer compras (supermercado)|
|**Je n'en peux plus**|Não aguento mais (_penser_ = pensar, _plus_ = mais)|
|**Le vin**|O vinho|

---

### 📝 Devoir (Lição de Casa)

**Pratique o _Futur Proche_:**

1. Escreva pelo menos cinco frases em francês descrevendo planos que você tem para os próximos dias, usando a estrutura do _Futur Proche_.
    
2. Use o vocabulário de atividades que você aprendeu em aulas anteriores (esportes, _hobbies_, família).
    
3. Inclua pelo menos uma frase na forma negativa para praticar a colocação do **ne... pas** em torno do verbo **Aller**.
    

**Exemplo:** _Ce week-end, **je vais marcher** au parc. **Je ne vais pas faire** la grasse matinée._ (Neste fim de semana, **eu vou caminhar** no parque. Eu não **vou dormir** até tarde.)