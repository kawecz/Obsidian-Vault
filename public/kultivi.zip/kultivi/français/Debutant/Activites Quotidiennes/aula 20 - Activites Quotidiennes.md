---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Des Habitudes et es Activités Quotidiennes | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/10H11j_YNX8?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Rotina Diária e Verbos Pronominais (_Habitudes et Activités Quotidiennes_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #20) é dedicada a descrever o que você faz no dia a dia (_ma routine_). O ponto principal é o uso e a conjugação dos **Verbos Pronominais** (_Les verbes pronominaux_), que são cruciais para descrever ações que o sujeito realiza em si mesmo (ex: _se_ levantar, _se_ vestir). A aula também introduz vocabulário para sequenciar ações e indicar horas.

### [[aula20.pdf]]
---

### 👑 Verbos Pronominais (_Les Verbes Pronomineux_)

Verbos pronominais são aqueles que são **obrigatoriamente** acompanhados por um pronome reflexivo (**me, te, se, nous, vous, se**) antes do verbo. A ação é feita pelo sujeito em si mesmo.

#### Exemplo de Conjugação: Se Réveiller (Acordar)

|Pronome Pessoal|Pronome Reflexivo|Verbo Conjugado|Significado (PT-BR)|
|---|---|---|---|
|**Je**|**me**|**réveille**|Eu me acordo|
|**Tu**|**te**|**réveilles**|Tu te acordas|
|**Il/Elle/On**|**se**|**réveille**|Ele/Ela se acorda|
|**Nous**|**nous**|**réveillons**|Nós nos acordamos|
|**Vous**|**vous**|**réveillez**|Vós vos acorda(i)s|
|**Ils/Elles**|**se**|**réveillent**|Eles/Elas se acordam|

#### Vocabulário de Rotina (Verbos Pronominais)

|Verbo (Infinitivo)|Significado (PT-BR)|Atividade Típica|
|---|---|---|
|**Se lever**|Levantar-se||
|**Se raser**|Barbear-se||
|**S'informer**|Informar-se|_S'informer sur Internet_|
|**Se coucher**|Deitar-se||
|**Se reposer**|Descansar||
|**Se divertir**|Divertir-se||
|**S'habiller**|Vestir-se||
|**Se connecter**|Conectar-se|_Se connecter à Internet_|
|**Se préparer**|Preparar-se||
|**Se brosser les dents**|Escovar os dentes|_Brosser_ é escovar.|
|**Se doucher**|Tomar banho (de chuveiro)||
|**Se coiffer**|Pentear-se||

---

### 🌙 Expressões de Tempo e Conectores de Sequência

Para descrever a rotina, usamos expressões que indicam o tempo e a ordem dos acontecimentos.

#### Indicando o Horário

|Expressão|Significado (PT-BR)|Uso|
|---|---|---|
|**À [Hora]**|Às [Hora]|Horário **exato** e fixo. _Ex: À 7h30._|
|**Vers [Hora]**|Por volta das [Hora]|Horário **aproximado** (mais ou menos). _Ex: Vers 7h._|
|**De [Hora] à [Hora]**|De [Hora] a [Hora]|Período de tempo (intervalo). _Ex: De 8h à 17h._|
|**Midi / Minuit**|Meio-dia / Meia-noite||

#### Conectores de Sucessão de Ações (_Connecteurs de Sucession_)

|Conector|Significado (PT-BR)|Uso|
|---|---|---|
|**D’abord**|Primeiro, de início|Para começar a sequência.|
|**Ensuite**|Em seguida, depois|Para a próxima ação (sucessão lógica).|
|**Puis**|Depois|Similar ao _Ensuite_, mas pode indicar uma sucessão mais rápida/leve.|
|**Après [Substantivo]**|Depois de [Algo]|Usado antes de um substantivo. _Ex: Après le travail._|
|**Finalement / Enfin**|Finalmente|Para a última ação.|

---

### 🚫 A Negação com Verbos Pronominais

Em frases negativas, o pronome reflexivo fica junto ao verbo, e o **Ne... Pas** envolve todo o bloco verbal.

|Estrutura|Exemplo (Afirmativa)|Exemplo (Negativa)|Significado (PT-BR)|
|---|---|---|---|
|**[Pronome] + ne [Pron. Ref.] [Verbo] pas**|_Je me couche tôt._|_Je **ne me couche pas** tôt._|Eu não me deito cedo.|
||_Tu te coiffes._|_Tu **ne te coiffes jamais**._|Você nunca se penteia.|
||_Elle s'informe._|_Elle **ne s'informe pas** sur Internet._|Ela não se informa pela internet.|

**Regra-Chave:** O par **Ne** e **Pas** (ou _jamais, rien_) deve sempre englobar o pronome reflexivo e o verbo.

---

### 📝 Devoir (Lição de Casa)

**Escreva sua Rotina (_Ma Routine_):**

1. Use os verbos pronominais e as expressões de tempo desta aula para descrever em francês o que você faz desde que acorda até a hora de dormir.
    
2. Use os conectores de sucessão (_d'abord, ensuite, après, finalement_) para ligar as frases e dar fluidez ao seu texto.
    
3. Inclua horários exatos (**à**) e aproximados (**vers**).
    

**Modelo a Seguir:**

- _D'abord, je **me réveille** vers 7h du matin._
    
- _Ensuite, je **me douche** et **je m'habille**._
    
- _Après le petit-déjeuner, je **vais** au travail de 8h à 17h._
    
- _Finalement, je **me connecte** sur Internet et **je me couche**._