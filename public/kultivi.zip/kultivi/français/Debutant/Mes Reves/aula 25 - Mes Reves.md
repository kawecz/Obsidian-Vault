---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Conversation - Mes Rêves | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/MRyNjNnikQc?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Conversação: Expressando Sonhos e Desejos (_Mes Rêves_)

### 🎯 Visão Geral da Aula

Esta lição, a última do nível básico (Curso #25), ensina a falar sobre seus **sonhos** (_les rêves_) e **desejos de vida** (_rêves de vie_). O foco é na expressão **"Je rêve de"** e na consolidação de vocabulário e estruturas complexas (preposições, negação) aprendidas no curso.

### [[aula25.pdf]]
---

### 1️⃣ Verbo RÊVER (Sonhar)

O verbo **Rêver** é um verbo regular do primeiro grupo (-er) e se conjuga da forma padrão:

|Pronome|Conjugação|Pronúncia Aproximada|
|---|---|---|
|**Je**|**rêve**|/ʒə ʀɛv/|
|**Tu**|**rêves**|/ty ʀɛv/|
|**Il/Elle/On**|**rêve**|/il ʀɛv/|
|**Nous**|**rêvons**|/nu ʀevɔ̃/|
|**Vous**|**rêvez**|/vu ʀeve/|
|**Ils/Elles**|**rêvent**|/zil ʀɛv/|

#### Estruturas para Expressar Sonhos

Existem duas formas principais de expressar seus sonhos em francês:

|Estrutura|Uso|Exemplo em Francês|Significado (PT-BR)|
|---|---|---|---|
|**Je rêve de** + **Infinitivo**|Sonho em fazer algo.|**Je rêve de voyager.**|Eu sonho em viajar.|
|**Mon rêve, c'est de** + **Infinitivo**|Meu sonho é fazer algo.|**Mon rêve, c'est de chanter.**|Meu sonho é cantar.|
|**Je rêve d'** + **Substantivo**|Sonho com algo.|**Je rêve d'une maison.**|Eu sonho com uma casa.|

**Atenção:** A preposição **"de"** (ou **d'** antes de vogal) é obrigatória após _rêver_ neste contexto.

**Exemplos Notáveis:**

- _Mon rêve, c'est d'être **riche**._ (Meu sonho é ser rico.)
    
- _Je rêve d'avoir **de l'argent**._ (Eu sonho em ter dinheiro.)
    
- _Je rêve d'aller **au Brésil**._ (Eu sonho em ir ao Brasil.)
    

---

### 2️⃣ Vocabulário e Revisão da Conversação

|Expressão/Palavra|Significado (PT-BR)|Contexto/Observação|
|---|---|---|
|**Un rêve de gosse**|Um sonho de criança|_Gosso_ (criança) é informal.|
|**Surtout**|Acima de tudo|Intensificador.|
|**Le Château de Versailles**|O Palácio de Versalhes|Ponto turístico.|
|**Il va sans dire**|É evidente, nem precisa dizer||
|**Être en feu**|Estar pegando fogo, estar animado|Sentido de estar no auge.|
|**Chéri(e)**|Querido(a)|Termo carinhoso.|
|**Un métier**|Uma profissão||
|**Les planches**|O palco (teatro)|_Mon rêve, c'est de monter sur les planches._|

#### Revisão de Preposições de Lugar (Viagens)

É crucial usar a preposição correta antes de locais geográficos.

|Regra|Preposição|Exemplo|Significado (PT-BR)|
|---|---|---|---|
|**Cidades**|**À**|**À** Rome, **À** Paris|Em/Para Roma, Paris|
|**Países/Continentes (Masc.)**|**AU**|**AU** Maroc, **AU** Brésil|No/Para o Marrocos, Brasil|
|**Países/Continentes (Fem.)**|**EN**|**EN** France, **EN** Asie|Na/Para a França, Ásia|
|**Países/Continentes (Plural)**|**AUX**|**AUX** États-Unis|Nos/Para os Estados Unidos|

---

### 3️⃣ Dicas para Continuar o Estudo (Pós-Básico)

Para fazer a transição do nível Básico para o Intermediário, a imersão é essencial.

1. **Imersão Auditiva Constante:**
    
    - Continue escutando a rádio **France Info**.
        
    - Utilize vídeos e músicas para manter o cérebro "ligado" no francês.
        
2. **Leitura em Francês:**
    
    - Comece a ler livros simples. O livro **"Le Petit Prince" (O Pequeno Príncipe)** é altamente recomendado para iniciantes, pois é fácil de encontrar e tem uma linguagem acessível.
        
3. **Use Dicionários Confiáveis:**
    
    - Use o dicionário online **Larousse.fr** para checar o significado, gênero e contexto de palavras.
        

---

### 📝 Devoir (Lição de Casa Final)

Parabéns, esta é sua última lição de casa do Nível Básico!

Responda à pergunta: **"Quel est votre/ton rêve?"** (Qual é o seu sonho?)

1. Escreva um parágrafo (3 a 5 frases) em francês sobre seus maiores sonhos de vida (viagens, carreira, _hobbies_).
    
2. Use as expressões **Je rêve de/d'** ou **Mon rêve, c'est de** e o vocabulário de verbos no **infinitivo** que você aprendeu.
    
3. Pratique a fala, lendo o seu parágrafo em voz alta, como se estivesse conversando comigo.
    

_Exemplo:_ _"Mon rêve, c'est de devenir **professeur**. Je rêve de **voyager** beaucoup, surtout **en** Asie, et j'espère un jour **parler** parfaitement français."_
