---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Les Articles | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/IdRMX2eHNIw?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Os Artigos (Les Articles)

---

### 🎯 Visão Geral da Aula

Esta aula de gramática aborda os **Artigos em Francês**, que são cruciais para a concordância e a definição dos substantivos. O conteúdo é dividido em três grupos: **Definidos (_Définis_)**, **Indefinidos (_Indéfinis_)** e **Contraídos (_Contractés_)**. O francês exige que os substantivos sejam sempre acompanhados por um artigo, tornando este tópico essencial para a construção de frases corretas.

### [[aula9.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## 📎 Artigos Definidos (_Les Articles Définis_)

Os artigos definidos são usados para se referir a um substantivo específico ou já conhecido, equivalente ao "o", "a", "os" e "as" do português.

|Gênero e Número|Artigo|Pronúncia|Equivalente (PT-BR)|Exemplo|
|---|---|---|---|---|
|**Masculino Singular**|**Le**|_Lê_ (Língua no céu da boca)|O|_Le livre_ (O livro)|
|**Feminino Singular**|**La**|_Lá_|A|_La maison_ (A casa)|
|**Plural (Masc. e Fem.)**|**Les**|_Lê_ (Mudo no 's')|Os, As|_Les étudiants_ (Os estudantes)|
|**Vogal/H Mudo (Sing.)**|**L'**|_L'_|O, A|_L'arbre_ (A árvore), _L'hôpital_ (O hospital)|

**Dica de Pronúncia:** Evite pronunciar o 's' final de **Les**.

## 🖋️ Artigos Indefinidos (_Les Articles Indéfinis_)

Os artigos indefinidos referem-se a um substantivo não específico ou não conhecido, equivalente ao "um", "uma" e "uns", "umas" do português.

|Gênero e Número|Artigo|Pronúncia|Equivalente (PT-BR)|Exemplo|
|---|---|---|---|---|
|**Masculino Singular**|**Un**|_Ã_ (Som nasal)|Um|_Un travail_ (Um trabalho)|
|**Feminino Singular**|**Une**|_In_|Uma|_Une photo_ (Uma foto)|
|**Plural (Masc. e Fem.)**|**Des**|_Dê_ (Mudo no 's')|Uns, Umas|_Des photos_ (Umas fotos)|

**Observação:** O artigo indefinido **Des** não tem um equivalente perfeito em português e é usado para indicar pluralidade não específica (ex: _Des Français_ - "franceses" em geral).

### Artigos Definidos vs. Indefinidos

|Artigo Indefinido|Artigo Definido|Contexto|
|---|---|---|
|_C'est **un** musée._|_C'est **le** Musée du Louvre._|Um museu genérico vs. um museu específico.|
|_**Une** étudiante._|_**L'** étudiante de Paris._|Uma estudante qualquer vs. a estudante de Paris.|
|_**Des** villes._|_**Les** villes de France._|Cidades em geral vs. as cidades da França.|

## 🔗 Artigos Contraídos (_Les Articles Contractés_)

Estes artigos são a união de uma preposição (**à** ou **de**) com um artigo definido (**le** ou **les**). Essa contração é obrigatória em francês.

|Contração|Combinação|Gênero e Número|Equivalente (PT-BR)|Exemplo|
|---|---|---|---|---|
|**Au**|![](data:,)|Masc. Singular|Ao (_à o_)|_Je vais **au** musée._ (Eu vou **ao** museu.)|
|**Aux**|![](data:,)|Plural (Masc./Fem.)|Aos, às (_a os, a as_)|_Je parle **aux** étudiants._ (Eu falo **aos** estudantes.)|
|**Du**|![](data:,)|Masc. Singular|Do (_de o_)|_À côté **du** restaurant._ (Ao lado **do** restaurante.)|
|**Des**|![](data:,)|Plural (Masc./Fem.)|Dos, das (_de os, de as_)|_Les chefs **des** restaurants._ (Os chefs **dos** restaurantes.)|

**Atenção:**

- A contração **NÃO** ocorre com **la** ou **l'**: _À **la** maison_, _De **l'** eau_.
    
- O **Des** de artigo contraído (![](data:,)) tem a mesma forma escrita do artigo indefinido plural. O sentido é dado pelo contexto!
    

## 📚 Tópicos Gramaticais Chave

### Substantivos (_Les Noms_)

|Palavra|Gênero|Significado (PT-BR)|
|---|---|---|
|**L'article**|Masc. Sing.|O artigo.|
|**Le singulier**|Masc. Sing.|O singular.|
|**Le pluriel**|Masc. Sing.|O plural.|
|**La prononciation**|Fem. Sing.|A pronúncia.|
|**La vie**|Fem. Sing.|A vida.|
|**La voiture**|Fem. Sing.|O carro.|

### Adjetivos (_Les Adjectifs_)

|Palavra|Forma|Significado (PT-BR)|
|---|---|---|
|**Défini(e)**|Variável|Definido.|
|**Indéfini(e)**|Variável|Indefinido.|
|**Contracté(e)**|Variável|Contraído.|
|**Exotique**|Invariável|Exótico (Em _repas exotiques_).|
|**Correct(e)**|Variável|Correto (Em _réponses correctes_).|

### Preposições (_Les Prépositions_)

|Palavra|Significado (PT-BR)|Função no Contexto|
|---|---|---|
|**à**|a, em|Usada na formação dos artigos _Au_ e _Aux_.|
|**de**|de|Usada na formação dos artigos _Du_ e _Des_.|

Para fixar a regra de concordância, tente escrever uma lista de 10 objetos que você usa diariamente, aplicando o artigo definido correto (Le, La, L', Les)!