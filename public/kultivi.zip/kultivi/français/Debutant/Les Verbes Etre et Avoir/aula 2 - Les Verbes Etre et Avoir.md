---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Les Verbes Être et Avoir | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/mei8gFBZrxk?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
# 🇫🇷 Aula 2 – Verbos _Être_ e _Avoir_ (Bases para Apresentação)

> [!summary] **Visão Geral**  
> Esta aula trabalha dois verbos essenciais do francês:
> 
> - **Être (ser/estar)** → usado para se apresentar, indicar nacionalidade, profissão e características.
>     
> - **Avoir (ter)** → usado para posse, sentimentos, necessidades e expressões idiomáticas.  
>     Esses verbos são base para muitas construções do francês e aparecem constantemente em apresentações pessoais.
>     

### [[aula2.pdf]]
---

## 🔑 Verbo _Être_ (ser/estar)

|Pessoa|Conjugação|Pronúncia aproximada|
|---|---|---|
|je|je suis|jə suí|
|tu|tu es|ty ê|
|il/elle|il/elle est|il ê / el ê|
|nous|nous sommes|nu sôm|
|vous|vous êtes|vu zêt|
|ils/elles|ils/elles sont|il sõ / el sõ|

### Usos do _être_

1. **Apresentação pessoal**
    
    - _Je suis Edson._ → Eu sou Edson.
        
    - _Je suis pharmacienne._ → Eu sou farmacêutica.
        
2. **Profissões**
    
    - _Je suis avocat._ → Eu sou advogado.
        
    - _Je suis chanteuse._ → Eu sou cantora.
        
    - _Je suis journaliste._ → Eu sou jornalista.
        
    
    > [!tip] As profissões em francês **não levam artigo definido** (_un/une_).  
    > Ex.: _Je suis avocat_ (não: _Je suis un avocat_).
    
3. **Nacionalidade**
    
    - _Je suis brésilien._ → Eu sou brasileiro.
        
    - _Elle est espagnole._ → Ela é espanhola.
        
4. **Adjetivos (descrições)**
    
    - _Je suis jeune._ → Eu sou jovem.
        
    - _Elle est vieille._ → Ela é velha.
        
    - _Il est petit._ → Ele é pequeno.
        
    - _Elle est petite._ → Ela é pequena.
        
    - _Je suis heureux._ → Eu sou feliz (masc.).
        
    - _Je suis heureuse._ → Eu sou feliz (fem.).
        

---

## 🧾 Vocabulário – Profissões

|Francês|Português|Observações|
|---|---|---|
|pharmacien / pharmacienne|farmacêutico(a)|feminino → +ne|
|avocat / avocate|advogado(a)|cuidado com pronúncia [avôcá]|
|chanteur / chanteuse|cantor(a)|feminino → +se|
|journaliste|jornalista|não muda no feminino|
|étudiant / étudiante|estudante|feminino → +e|

---

## 🧾 Vocabulário – Nacionalidades

|Masculino|Feminino|Português|
|---|---|---|
|français|française|francês/francesa|
|espagnol|espagnole|espanhol/espanhola|
|brésilien|brésilienne|brasileiro/brasileira|
|italien|italienne|italiano/italiana|
|portugais|portugaise|português/portuguesa|

> [!info] Regras comuns:
> 
> - Muitos adjetivos de nacionalidade formam o feminino com **+e**.
>     
> - Quando já terminam em **e**, não mudam (_belge, suisse_).
>     
> - Alguns duplicam a consoante: _italien → italienne_.
>     

---

## 🔑 Verbo _Avoir_ (ter)

|Pessoa|Conjugação|Pronúncia aproximada|
|---|---|---|
|j’|j’ai|jê|
|tu|tu as|ty á|
|il/elle|il/elle a|il á / el á|
|nous|nous avons|nu zavõ|
|vous|vous avez|vu zavê|
|ils/elles|ils/elles ont|il zõ / el zõ|

### Usos do _avoir_

1. **Posse**
    
    - _J’ai une maison._ → Eu tenho uma casa.
        
    - _Elle a une voiture._ → Ela tem um carro.
        
2. **Idade** (diferente do português)
    
    - _J’ai 20 ans._ → Eu tenho 20 anos. (literal: Eu tenho 20 anos).
        
3. **Expressões idiomáticas**
    
    - _J’ai froid._ → Estou com frio.
        
    - _J’ai faim._ → Estou com fome.
        
    - _J’ai soif._ → Estou com sede.
        
    - _J’ai envie de voyager._ → Tenho vontade de viajar.
        
    - _J’ai besoin d’un stylo._ → Preciso de uma caneta.
        
    - _J’ai peur des araignées._ → Tenho medo de aranhas.
        

---

## 🧾 Vocabulário – Objetos

|Francês|Português|
|---|---|
|une maison|uma casa|
|une voiture|um carro|
|un stylo|uma caneta|
|un livre|um livro|

---

## ✅ Resumo Final

- _Être_ = ser/estar → usado para apresentação, profissão, nacionalidade e adjetivos.
    
- _Avoir_ = ter → usado para posse, idade, necessidades e expressões idiomáticas.
    
- Profissões e nacionalidades não levam artigo definido.
    
- Feminino geralmente se forma com **+e**, mas há variações (duplicação ou invariável).
    
- Expressões com _avoir_ não são traduzidas literalmente (ex.: _j’ai froid_ = estou com frio).
