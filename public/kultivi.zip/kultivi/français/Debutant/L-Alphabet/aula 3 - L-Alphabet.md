---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - L'Alphabet | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/e925P4CJFA4?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
# 🇫🇷 Aula 3 – O Alfabeto Francês e Como Soletrar

> [!summary] **Visão Geral**  
> Nesta aula aprendemos o **alfabeto francês** (26 letras, 20 consoantes e 6 vogais), suas particularidades de pronúncia e uso prático para **soletrar nomes**. Também vimos a importância do _R_ gutural, do _U_ com bico, do _Y_ (vogal em francês), e de como responder quando alguém pede para soletrar.

### [[aula3.pdf]]
---

## 🔠 O Alfabeto Francês

- O francês tem **26 letras** como o português.
    
- São **20 consoantes** (_consonnes_) e *_6 vogais_ (_voyelles_).
    
- O **Y** é considerado vogal porque tem som de **i**.
    

|Letra|Nome em francês|Observações|
|---|---|---|
|A|a|igual ao português|
|B|bé|com _é_ fechado|
|C|cé|igual ao português|
|D|dé|com _é_ fechado|
|E|e|som neutro, não é “é” nem “ê”|
|F|effe|dobrado → “effe”|
|G|gé|com _é_ fechado|
|H|ache|sempre mudo|
|I|i|igual ao português|
|J|ji|som parecido com “j” em “jornal”|
|K|ka|igual ao português|
|L|elle|dobrado → “elle”|
|M|emme|dobrado → “emme”|
|N|enne|dobrado → “enne”|
|O|o|igual ao português|
|P|pé|com _é_ fechado|
|Q|qu|sempre acompanhado de _u_|
|R|erre (gutural)|som na garganta|
|S|esse|igual ao português|
|T|té|com _é_ fechado|
|U|u|bico dos lábios → **não é “u” do português**|
|V|vé|igual ao português|
|W|double vé|“duas vezes V”|
|X|ixe|“ks” ou “gz”|
|Y|i grec|vogal com som de _i_|
|Z|zède|com _è_ aberto|

---

## 📌 Diferenças Importantes

- **Acento agudo (é)** → fecha o som (_bé, dé, gé_).
    
- **Acento grave (è)** → abre o som (_zède_).
    
- **R** → som gutural, produzido na garganta, não na boca.
    
- **U** → exige “biquinho” → [y], diferente do “u” português.
    
- **H** → é **mudo** (ex.: _hôpital_ = hospital).
    
- **Y** → chamado de _i grec_ (i grego), é vogal.
    

---

## 📚 Exemplos com Palavras

|Letra|Palavra|Tradução|Observação|
|---|---|---|---|
|A|avocat|advogado|já visto na aula anterior|
|B|banane|banana|igual ao português|
|C|chien|cachorro|_ch_ = som de “x”|
|D|dentiste|dentista||
|E|école|escola|_é_ fechado|
|F|femme|mulher / esposa|_mm_ longo|
|G|garçon|rapaz|não é garçom de restaurante|
|H|hôpital|hospital|_h_ mudo|
|J|journaliste|jornalista||
|L|livre|livro|atenção: _libre_ = livre|
|M|mère|mãe|mesma pronúncia de _mer_ (mar)|
|N|neige|neve||
|O|oreille|orelha|_ll_ forte|
|P|pied|pé|_d_ final não se pronuncia|
|Q|qui|quem|_qu_ = som de “k”|
|R|raisin|uva|_r_ gutural|
|S|secrétaire|secretário(a)|_r_ forte no meio|
|T|train|trem|_in_ = som nasal [ẽ]|
|V|vin|vinho|nasal [vã]|
|W|William|nome próprio|pronúncia francesa|
|X|xylophone|xilofone|emprestado do grego|
|Y|Yves|nome próprio|som de _i_|
|Z|zéro|zero||

---

## ✍️ Como Soletrar

### Perguntar

- **Épelez, s’il vous plaît.** → Soletre, por favor. (formal)
    
- **Comment ça s’écrit ?** → Como isso se escreve?
    
- **Épel ton prénom.** → Soleta teu primeiro nome.
    

### Responder

- _W I L L I A M_ → William.
    
- _T A I S_ → Taís.
    

### Mini-diálogo

- **A:** Bonjour, Madame.
    
- **B:** Bonjour. Comment vous appelez-vous ?
    
- **A:** Je m’appelle William.
    
- **B:** Épelez, s’il vous plaît.
    
- **A:** W I L L I A M.
    
- **B:** Merci.
    

---

## ✅ Resumo Final

- O francês tem 26 letras, mas 6 vogais (inclui _Y_).
    
- Diferença essencial: **U, R, H, Y, E**.
    
- O _R_ é gutural, o _U_ exige biquinho, o _H_ é mudo.
    
- Muitas palavras têm **última consoante não pronunciada**.
    
- Saber soletrar é essencial em situações formais (nome, sobrenome, endereço).
