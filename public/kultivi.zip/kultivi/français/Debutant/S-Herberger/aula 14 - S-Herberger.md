---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - S'Heberger | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/RV2OdeIgcxM?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Alojamento Provisório e Reservas (Se Loger / Se Berger)

---

### 🎯 Visão Geral da Aula

Esta lição de nível intermediário (Curso #14) foca no vocabulário e nas habilidades práticas necessárias para encontrar e reservar **alojamento provisório (_logement provisoire_)** durante uma viagem na França. O material explora os diferentes tipos de hospedagem, a estrutura para a comunicação por e-mail e as frases úteis para a estadia.

### [[aula14.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## 🏠 Tipos de Alojamento (_Types de Logement_)

O termo **Logement** refere-se ao local de moradia/alojamento, que pode ser tanto fixo quanto provisório. **Se Berger** significa "encontrar abrigo/alojamento provisório".

|Tipo de Alojamento|Francês|Definição / Observação|
|---|---|---|
|Pousada Familiar|**Chambre d'hôte**|Quarto na casa de um particular, comum no interior.|
|Hotel|**Hôtel**|Alojamento tradicional (pode ser de 1 a 5 estrelas).|
|Hostel / Albergue|**Auberge de jeunesse**|Quartos grandes com camas múltiplas, espaços (_cuisine_, _salle de bain_) compartilhados.|
|Apartamento (Fixo)|**Un appartement**||

## 📧 Comunicação: E-mail de Reserva

Ao fazer uma reserva por escrito, a comunicação segue uma estrutura formal:

|Elemento|Francês|Exemplo de Uso|
|---|---|---|
|Assunto|**Objet**|_Réservation_ (Reserva)|
|Saudação|**Bonjour Monsieur/Madame**|Saudação formal ao iniciar.|
|Pedido (Polido)|**Je voudrais...**|_Je voudrais faire une réservation._ (Eu gostaria de fazer uma reserva.)|
|Dúvidas|**J'ai quelques doutes**|Tenho algumas dúvidas.|
|Despedida|**Cordialement**|Atenciosamente (Forma educada de encerrar o e-mail).|

### Perguntas Essenciais em E-mail

- **Le déjeuner est-il inclus?** (O café da manhã está incluso?)
    
- **Les chambres sont-elles mixtes?** (Os quartos são mistos?)
    
- **Puis-je utiliser la cuisine?** (Posso usar a cozinha?)
    
- **Quelle est la différence entre la Chambre A et la Chambre B?** (Qual a diferença entre o Quarto A e o Quarto B?)
    
- **Y a-t-il une salle de bain dans la chambre?** (Há um banheiro no quarto?)
    

## 📄 Ficha de Reserva (_Fiche de Réservation_)

|Campo|Francês|Significado (PT-BR)|
|---|---|---|
|Sobrenome|**Nom**|Priorizado em cadastros na França.|
|Primeiro Nome|**Prénom**||
|Data de Chegada|**Date d'arrivée**||
|Data de Partida|**Date de départ**||
|Número de Noites|**Nombre de nuits**||
|Tipo de Quarto|**Type de chambre**|Ex: _Chambre double_ (Quarto duplo), _Lit en dortoir_ (Cama em dormitório).|

## 🛎️ Expressões Úteis na Recepção

|Frase|Francês|Significado (PT-BR)|
|---|---|---|
|Preço|**Quel est le prix par personne/nuit?**|Qual é o preço por pessoa/noite?|
|Quartos|**Chambre à deux/quatre/huit lits**|Quarto com duas/quatro/oito camas.|
|Horário|**Quelles sont les heures d'ouverture?**|Quais são os horários de funcionamento?|
|Estacionamento|**Y a-t-il un parking?**|Há um estacionamento?|
|Pagamento|**Je peux payer par carte?**|Posso pagar com cartão?|
|Crianças|**Nous avons des enfants.**|Nós temos crianças.|
|Restaurante|**Y a-t-il un restaurant?**|Há um restaurante?|

---

## 📝 Devoir (Lição de Casa)

**Objetivo:** Simular um e-mail de reserva.

1. Encontre um **Hôtel, Chambre d'hôte ou Auberge de Jeunesse** francês (pode ser usando o Google Maps ou sites como Booking).
    
2. Redija um e-mail formal de reserva para o estabelecimento.
    
3. Inclua: Saudação, pedido polido (_Je voudrais..._), data de chegada e partida, e pelo menos **duas perguntas** sobre a estadia (e.g., _parking_, _petit-déjeuner_).
    
4. Finalize com a despedida apropriada (_Cordialement_).