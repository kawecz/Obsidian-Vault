---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Les Couleurs | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/5IC1Iiws8mw?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Cores, Expressões e Concordância (_Les Couleurs_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #24) é uma expansão de vocabulário focada nas cores, na sua aplicação prática e na regra fundamental de **concordância de gênero e número** dos adjetivos de cor. A aula também introduz algumas expressões idiomáticas úteis.

### [[aula24.pdf]]
---

### 1️⃣ Vocabulário Principal de Cores

|Cor (Masc. Sing.)|Cor (Fem. Sing.)|Pronúncia Aproximada|Observação / Curiosidade|
|---|---|---|---|
|**Blanc**|**Blanche**|/blɑ̃/ /blɑ̃ʃ/|Masculino termina em **-c**; Feminino em **-che**.|
|**Noir**|**Noire**|/nwaʀ/ /nwaʀ/||
|**Gris**|**Grise**|/gʀi/ /gʀiz/|Masculino termina em **-s**; Feminino adiciona **-e**.|
|**Vert**|**Verte**|/vɛʀ/ /vɛʀt/||
|**Bleu**|**Bleue**|/blø/ /blø/||
|**Rouge**|**Rouge**|/ʀuʒ/ /ʀuʒ/|**Invariável** no feminino (já termina em _-e_).|
|**Jaune**|**Jaune**|/ʒon/ /ʒon/|**Invariável** no feminino (já termina em _-e_).|
|**Orange**|**Orange**|/oʀɑ̃ʒ/ /oʀɑ̃ʒ/|**Invariável** no feminino e plural.|
|**Rose**|**Rose**|/ʀoz/ /ʀoz/|**Invariável** no feminino e plural.|
|**Violet**|**Violette**|/vjɔlɛ/ /vjɔlɛt/|Feminino adiciona **-te**.|
|**Marron**|**Marron**|/maʀɔ̃/ /maʀɔ̃/|**Invariável** no feminino e plural.|

---

### 2️⃣ Concordância dos Adjetivos de Cor

Assim como em português, os adjetivos de cor (exceto as cores invariáveis) devem **concordar em gênero e número** com o substantivo que modificam.

|Gênero/Número|Exemplo Masculino|Exemplo Feminino|Exemplo Plural|
|---|---|---|---|
|**Singular**|Un mur **vert**.|Une feuille **verte**.|Des murs **verts**.|
|**Plural**|Des pulls **gris**.|Des robes **grises**.|Des chemises **blanches**.|

Exceções: Cores Invariáveis

As cores que derivam de frutas, flores ou materiais (como marron, orange, rose) não variam em gênero ou número.

- _Des robes **orange**._ (Correta)
    
- _Des pulls **marron**._ (Correta)
    

---

### 3️⃣ Intensidade e Nuances de Cores

Para descrever variações de cor (claro, escuro, etc.), usamos adjetivos após a cor.

|Termo|Significado (PT-BR)|Exemplo|
|---|---|---|
|**Clair(e)**|Claro(a)|_Vert **clair**_ (Verde claro)|
|**Foncé(e)**|Escuro(a)|_Bleu **foncé**_ (Azul escuro)|
|**Sombre**|Sombrio, escuro|_Couleur **sombre**_ (Cor escura/sombria)|

---

### 4️⃣ Expressões Idiomáticas com Cores

|Expressão|Significado Literal|Significado (PT-BR)|
|---|---|---|
|**Avoir la main verte**|Ter a mão verde|Ter jeito para jardinagem.|
|**Un cordon bleu**|Um cordão azul|Um cozinheiro(a) excelente.|
|**Être vert de jalousie**|Ser verde de inveja|Estar muito ciumento/invejoso.|
|**L'or noir**|O ouro preto|O petróleo.|
|**Rouler sur l'or**|Rolar sobre o ouro|Ser muito rico (ter muito dinheiro).|
|**Lèvres rouges**|Vermelho para os lábios|Batom (qualquer cor).|
|**Un œuf est jaune**|A gema é amarela|A gema de ovo é amarela.|

---

### 5️⃣ Vocabulário e Aplicações Práticas

|Palavra em Francês|Significado (PT-BR)|Contexto de Uso|
|---|---|---|
|**La ligne (jaune/rouge)**|A linha (amarela/vermelha)|Usado para indicar linhas de metrô ou transporte.|
|**Quel gâteau ?**|Qual bolo?|Usado em confeitarias/padarias para escolher o sabor/cor.|
|**La robe**|O vestido|Vestuário (concordância de cor: _La robe **rouge**_).|
|**Le pull**|O suéter/Blusão|Vestuário (concordância de cor: _Le pull **bleu**_).|

---

### 📝 Devoir (Lição de Casa)

Para fixar as cores, faça o seguinte exercício de observação e escrita:

1. **Olhe ao seu redor** e nomeie 10 objetos em francês, descrevendo a cor (ex: _Mon portable est **noir**._ / _La chaise est **blanche**._)
    
2. Preste atenção à **concordância** e ao **gênero** do substantivo que você está descrevendo.
    
3. Tente lembrar de situações em que você usaria as cores no dia a dia (Ex: Comprar um **bolo**, escolher uma **linha de metrô**, descrever uma **roupa**).
