---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Exprimer une Passion | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/JVWqiBZ8UZE?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Expressando Paixões e Gostos (Exprimer ses Passions)

---

### 🎯 Visão Geral da Aula

Esta lição foca no vocabulário e nas estruturas verbais para expressar **gostos, paixões e preferências** (_passions_) em francês. A aula introduz e compara os verbos **Aimer** (Amar/Gostar) e **Adorer** (Adorar), além de fornecer advérbios para modular a intensidade dessas preferências: **Bien**, **Beaucoup**, e **Trop**. A estrutura é reforçada pela revisão da conjugação dos verbos regulares do Primeiro Grupo.

### [[aula11.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## ❤️ Exprimindo Paixões e Gostos

Em francês, a palavra **"passion"** (_paixão_) refere-se tanto ao amor romântico quanto a um grande **gosto** ou **entusiasmo** por algo.

### Verbos de Gosto e Adoração

|Verbo|Sentido Principal (PT-BR)|Conjugação (Presente)|
|---|---|---|
|**Aimer** (1º Grupo)|Gostar / Amar|_J'aime, tu aimes, il/elle aime, nous aimons, vous aimez, ils/elles aiment_|
|**Adorer** (1º Grupo)|Adorar / Amar intensamente|_J'adore, tu adores, il/elle adore, nous adorons, vous adorez, ils/elles adorent_|

**Observação de Intensidade:** No francês falado, a ordem de intensidade é **Adorer** > **Aimer**.

- **J'adore** (Eu amo/gosto muito) é mais forte que **J'aime** (Eu gosto).
    

|Expressão de Paixão|Estrutura|Exemplo|
|---|---|---|
|Usando o verbo principal|![](data:,)|_Ma passion, c'est l'Italie._ (Minha paixão é a Itália.)|
|Usando o verbo _Avoir_ (Ter)|![](data:,)|_J'ai une passion pour le vin._ (Eu tenho uma paixão por vinho.)|
|Usando o verbo **Aimer**|![](data:,)|Eu amo estudar francês.|

## 📈 Intensificadores de Gosto

Para modificar a intensidade dos verbos _Aimer_ e _Adorer_, você deve usar advérbios colocados **imediatamente após o verbo**.

|Intensificador|Sentido (PT-BR)|Nível de Intensidade|Estrutura|
|---|---|---|---|
|**Bien**|Bastante, bem|Moderado (o menos intenso)|_J'aime **bien** sortir._|
|**Beaucoup**|Muito|Alto (Gosto forte)|_J'aime **beaucoup** le cinéma._|
|**Trop**|Demais, muito|Extremo (Pode ser positivo ou negativo)|_J'adore **trop** ce film._|

**Sequência de Intensidade:** ![](data:,)

### Contraste e Negação

Você pode usar as estruturas de gosto para criar frases contrastantes:

- **Contraste (Mas):** _J'aime le chocolat noir, **mais** j'adore le chocolat blanc._
    
- **Negação (_Ne... pas_):** Para dizer que **não gosta**, use _ne... pas_ + o advérbio _trop_, _beaucoup_ ou _bien_.
    
    - Ex: _Je **n'aime pas** le suspense._ (Eu não gosto de suspense.)
        

## 📝 Regra Essencial: Gosto + Infinitivo

Quando você expressa o gosto por uma **ação** (um verbo), o verbo de gosto (_aimer_, _adorer_) é conjugado, e a ação que vem em seguida permanece no **infinitivo** (forma não conjugada).

![](data:,)

|Verbo Conjugado|Ação no Infinitivo|Exemplo|
|---|---|---|
|_J'aime_|**acheter** (comprar)|_J'aime **acheter** des robes._ (Eu gosto de comprar vestidos.)|
|_Il/Elle adore_|**sortir** (sair)|_Il/Elle adore **sortir** le soir._ (Ele/Ela adora sair à noite.)|

## 📚 Tópicos Gramaticais Chave

### Substantivos (_Les Noms_)

|Palavra|Gênero|Significado (PT-BR)|
|---|---|---|
|**La passion**|Fem. Singular|A paixão.|
|**Le chocolat**|Masc. Singular|O chocolate.|
|**Le vin**|Masc. Singular|O vinho.|
|**Le suspense**|Masc. Singular|O suspense.|
|**Le soir**|Masc. Singular|A noite (fim de tarde/início da noite).|
|**Le roman**|Masc. Singular|O romance (livro).|

### Advérbios (_Les Adverbes_)

|Palavra|Significado (PT-BR)|Função no Contexto|
|---|---|---|
|**Bien**|Bem, bastante|Intensificador (Moderado).|
|**Beaucoup**|Muito|Intensificador (Alto).|
|**Trop**|Demais|Intensificador (Extremo).|
|**Mais**|Mas|Conector de contraste.|
|**Très**|Muito|Advérbio para adjetivos (_très beau_).|

### Verbos (Revisão do 1º Grupo)

- A conjugação dos verbos **Aimer** e **Adorer** segue o padrão regular **-e, -es, -e, -ons, -ez, -ent**.
    
- **Aimer** usa a contração **J'aime** por começar com vogal.
    

---

Agora que você sabe expressar seus gostos, o que você **adore trop** fazer? Tente responder em francês usando um infinitivo!