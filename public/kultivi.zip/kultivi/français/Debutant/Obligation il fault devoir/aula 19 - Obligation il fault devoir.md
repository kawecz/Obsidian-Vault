---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Obligation: Il Faut / Devoir | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/yMiHn4CMCYc?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Expressando Obrigação (_L'Obligation_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #19) aborda as duas formas principais de expressar **obrigação** em francês:

1. **Obrigação Impessoal:** Usando a estrutura **Il faut** (É preciso), que se aplica a todos.
    
2. **Obrigação Pessoal:** Usando o verbo **Devoir** (Dever), que se refere a um sujeito específico.
    

O domínio dessas estruturas é essencial para dar conselhos, ordens gerais ou expressar necessidades pessoais.

### [[aula19.pdf]]
---

### 1️⃣ Obrigação Impessoal: IL FAUT (É Preciso / É Necessário)

O **Il faut** é uma expressão invariável, conjugada apenas na terceira pessoa do singular (**Il**). Ela exprime uma **obrigação geral ou universal**.

|Estrutura|Uso|Exemplo em Francês|Significado (PT-BR)|
|---|---|---|---|
|**Il faut** + **Infinitivo**|Obrigação para _qualquer pessoa_ (impessoal).|**Il faut étudier.**|É preciso estudar.|
|||**Il faut être sincère.**|É preciso ser sincero.|
|||**Il faut acheter des produits bio.**|É preciso comprar produtos orgânicos.|

**Regra-Chave:** O verbo que segue **Il faut** deve estar sempre no **Infinitivo** (forma não conjugada).

---

### 2️⃣ Obrigação Pessoal: DEVOIR (Dever / Ter Que)

O verbo **Devoir** é um verbo irregular do 3º grupo e é usado para exprimir uma **obrigação, um dever ou uma forte necessidade** de um sujeito específico (eu, você, ele, etc.).

#### Conjugação do Verbo Devoir (Irregular)

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**dois**|**Nous**|**devons**|
|**Tu**|**dois**|**Vous**|**devez**|
|**Il/Elle/On**|**doit**|**Ils/Elles**|**doivent**|

**Atenção à Escrita:** A pronúncia de _Je dois_, _Tu dois_ e _Il/Elle doit_ é a mesma, mas a escrita varia: **-s, -s, -t**.

|Estrutura|Uso|Exemplo em Francês|Significado (PT-BR)|
|---|---|---|---|
|**Devoir** + **Infinitivo**|Obrigação para um _sujeito específico_ (pessoal).|**Je dois manger moins.**|Eu tenho que comer menos.|
|||**Tu dois acheter des euros.**|Você tem que comprar euros.|
|||**Nous devons prendre le bus.**|Nós devemos pegar o ônibus.|

**Uso Adicional:** O verbo **Devoir** também pode ser usado para exprimir uma **probabilidade ou suposição forte** (assim como em português).

**Exemplo:** _Tu dois être fatigué ce soir._ (Você **deve** estar cansado hoje à noite.) – _Não é uma obrigação, é uma dedução._

---

### 📝 Resumo e Comparação

|Estrutura|Tipo de Obrigação|Aplicável a...|Exige que o próximo verbo esteja no...|
|---|---|---|---|
|**Il faut**|Impessoal, geral|Todos|**Infinitivo**|
|**Devoir**|Pessoal, específica|Sujeito específico|**Infinitivo**|

---

### 📞 Vocabulário Adicional (Diálogo Telefônico)

|Palavra em Francês|Significado (PT-BR)|Observação de Uso|
|---|---|---|
|**Allô**|Alô|Usado ao atender o telefone.|
|**Alors**|Então|Conjunção de transição.|
|**Tôt**|Cedo|Advérbio de tempo.|
|**Numéro de portable**|Número de celular|_Portable_ significa móvel/celular.|
|**Moins le quart**|Menos um quarto (ou **menos quinze**)|Expressão de tempo, ex: _Quatre heures **moins le quart**_ (Três e quarenta e cinco, ou quinze para as quatro).|
|**Être heureux(se)**|Ser feliz|_Heureux_ (masculino), _Heureuse_ (feminino).|

---

### 📝 Devoir (Lição de Casa)

**Pratique suas Obrigações:**

1. Escreva uma lista das suas obrigações pessoais (**vos obligations personnelles**) usando o verbo **Devoir** (conjugado no _Je dois_ ou _Nous devons_).
    
2. Escreva uma lista de conselhos ou obrigações gerais (**obligations impersonnelles**) que você daria para seus amigos ou para a sociedade, usando a estrutura **Il faut**.
    
3. Se desejar, pratique a conjugação completa de **Devoir** no seu caderno para memorizar as terminações.
    

**Exemplos:**

- **Je dois** étudier le français tous les jours. (Pessoal)
    
- **Il faut** travailler. (Impessoal)
    
- **Il faut** dormir tôt. (Impessoal)