---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Les Nombres | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/weBG1X_t_DY?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Os Números (Les Nombres) e Uso Prático

---

### 🎯 Visão Geral da Aula

Esta aula se concentra em um tema fundamental da língua francesa: **Os Números (_Les Nombres_)**. O foco principal é a contagem a partir do dezessete, com especial atenção às construções numéricas complexas e únicas da língua francesa para 70, 80 e 90. Além da memorização, o curso aborda a aplicação prática dos números no dia a dia, como perguntar e responder sobre **idade**, **números de telefone**, **preços** e **horas**. É um tema essencial para a comunicação básica e formal em francês.

### [[aula4.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## Les Nombres (Os Números)

O sistema de contagem francês é, em grande parte, decimal, mas apresenta estruturas específicas para os números 70, 80 e 90, que são baseadas em operações de soma e multiplicação.

### Contagem Padrão (20 a 69)

A contagem básica segue um padrão de dezena + unidade, geralmente com um hífen.

|Número|Francês|Observação|
|---|---|---|
|**17**|_dix-sept_|Contagem direta.|
|**20**|_vingt_|Base para a próxima dezena.|
|**22**|_vingt-deux_|Hífen obrigatório (exceto para '21', que usa _-et-un_).|
|**30**|_trente_|Base para a próxima dezena.|
|**40**|_quarante_|Base para a próxima dezena.|
|**50**|_cinquante_|Base para a próxima dezena.|
|**60**|_soixante_|Base para a próxima dezena.|
|**63**|_soixante-trois_|Exemplo de dezena + unidade com hífen.|

### As Exceções "Matemáticas"

Os números 70, 80 e 90 são construídos usando operações de soma e multiplicação das dezenas anteriores.

|Número|Francês|Estrutura|Tradução Literal|Regra de Formação|
|---|---|---|---|---|
|**70**|_soixante-dix_|60 + 10|Sessenta e dez|Usa _soixante_ (60) como base e adiciona os números de 10 a 19.|
|**71**|_soixante-et-onze_|60 + 11|Sessenta e onze|Para 71, usa-se _et_ (e) ao invés do hífen.|
|**80**|_quatre-vingts_|4 x 20|Quatro vinténs|Usa _quatre_ (4) e _vingt_ (20) como base. O _vingt_ leva **'s'** quando multiplicado (apenas no 80 e 800, etc., quando não é seguido por outro número).|
|**90**|_quatre-vingt-dix_|(4 x 20) + 10|Quatro vinténs e dez|Usa _quatre-vingts_ (80) como base e adiciona os números de 10 a 19.|
|**95**|_quatre-vingt-quinze_|80 + 15|Quatro vinténs e quinze|Contagem de 90 a 99 usa os números de 10 a 19.|

**Adição de Informação:** Para os números 21, 31, 41, 51, 61 e 71, o número 1 (_un_) é ligado à dezena pela conjunção **_et_**: _vingt-et-un_, _soixante-et-onze_.

### Números Grandes

|Número|Francês|
|---|---|
|**100**|_cent_|
|**200**|_deux cents_|
|**1 000**|_mille_|
|**1 000 000**|_un million_|
|**1 000 000 000**|_un milliard_|

---

## Aplicações Práticas dos Números

Os números são essenciais para as seguintes situações de comunicação:

### 1. Idade (_L'Âge_)

|Uso|Pergunta em Francês|Significado|Observação|
|---|---|---|---|
|**Formal**|**Quel âge avez-vous ?**|Qual a sua idade?|Uso de _vous_ (formal).|
|**Informal**|**Quel âge as-tu ?** / **Tu as quel âge ?**|Qual a sua idade?|Uso de _tu_ (informal).|
|**Resposta**|**J'ai [número] ans.**|Eu tenho [número] anos.|Usar o verbo **_avoir_** (ter).|

### 2. Número de Telefone (_Numéro de Téléphone_)

Em francês, os números de telefone são geralmente ditos em pares (ou em sequências de dois dígitos).

|Exemplo|Leitura|Tradução Literal|
|---|---|---|
|**01 45 67 89 00**|_zéro un / quarante-cinq / soixante-sept / quatre-vingt-neuf / zéro zéro_|Zero um / quarenta e cinco / sessenta e sete / oitenta e nove / zero zero|

**Importante:** O zero (_0_) é lido como **_zéro_**.

### 3. Preço (_Le Prix_)

|Uso|Pergunta em Francês|Significado|
|---|---|---|
|**Perguntar**|**C'est combien ?** ou **Quel est le prix ?**|Quanto é? ou Qual é o preço?|
|**Perguntar**|**Ça coûte combien ?**|Quanto custa?|
|**Responder**|**C'est [número] euros.**|É [número] euros.|

### 4. Horas (_L'Heure_)

|Expressão|Francês|Significado|
|---|---|---|
|**Que horas são?**|**Quelle heure est-il ?**|Usar o verbo **_être_** (ser/estar) na resposta.|
|**1h00**|_Il est une heure._|É uma hora.|
|**5h15**|_Il est cinq heures **et quart**._|Cinco horas e um quarto.|
|**5h30**|_Il est cinq heures **et demie**._|Cinco horas e meia.|
|**5h45**|_Il est six heures **moins le quart**._|Seis horas menos um quarto (quinze para as seis).|

---

## 📚 Tópicos Gramaticais Chave

Os seguintes elementos gramaticais foram destacados ou são inerentes ao tema da aula:

### Substantivos (_Les Noms_)

|Palavra|Significado (PT-BR)|Categoria|Observação|
|---|---|---|---|
|**un nombre**|um número|Masculino|O conceito matemático.|
|**l'âge**|a idade|Masculino|A idade de alguém.|
|**un numéro**|um número (em sequência)|Masculino|Usado para telefone.|
|**le prix**|o preço|Masculino|O valor de algo.|
|**l'heure**|a hora|Feminino|O momento ou duração.|

### Adjetivos (_Les Adjectifs_)

|Palavra|Significado (PT-BR)|Aplicação no Contexto|
|---|---|---|
|**important(e)**|importante|Descrever a relevância do assunto.|
|**spécifique**|específico(a)|Descrever a regra particular de certos números.|
|**formel(le)**|formal|Usado para distinguir a pergunta com _vous_.|
|**informel(le)**|informal|Usado para distinguir a pergunta com _tu_.|

### Preposições e Conectores (_Les Prépositions et Mots de Liaison_)

|Palavra|Significado (PT-BR)|Função no Contexto|
|---|---|---|
|**de**|de|Indica posse ou relação (_numéro **de** téléphone_, _quart **de** heure_).|
|**à**|a, em|Usado em estruturas verbais ou para indicar o tempo (_à midi_, _à minuit_).|
|**et**|e|Conjunção usada para ligar elementos. **Regra Especial:** Usado apenas em 21, 31, 41, 51, 61, 71 (_vingt-**et**-un_).|
|**moins**|menos|Usado especificamente na leitura das horas (_cinq heures **moins** le quart_).|