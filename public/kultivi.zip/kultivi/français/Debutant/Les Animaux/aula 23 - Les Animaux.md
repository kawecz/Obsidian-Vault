---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Les Animaux | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/3P4CE86wHPY?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Animais, **Chez** e **Il y a**

### 🎯 Visão Geral da Aula

Esta lição (Curso #23) foca em expandir o vocabulário de **animais** (_les animaux_), essencial para o dia a dia. A aula também introduz duas estruturas gramaticais fundamentais: **Chez** (para indicar lugar/casa) e **Il y a** (para indicar existência/haver).

### [[aula23.pdf]]
---

### 1️⃣ Vocabulário de Animais (_Les Animaux_)

Preste atenção à pronúncia, especialmente ao som de "eu" e aos sons nasais.

#### 🏡 Animais Domésticos (_Animaux Domestiques_)

|Francês (Singular)|Gênero|Pronúncia Aproximada|Significado (PT-BR)|
|---|---|---|---|
|**Le chien**|Masc.|/lœ ʃjɛ̃/|Cão|
|**Le chat**|Masc.|/lœ ʃa/|Gato|
|**Le poisson**|Masc.|/lœ pwasɔ̃/|Peixe|
|**Le cochon d’Inde**|Masc.|/lœ koʃɔ̃ dɛ̃d/|Porquinho-da-Índia|
|**La tortue**|Fem.|/la tɔʀty/|Tartaruga|
|**Le hamster**|Masc.|/lœ amstɛʀ/|Hamster|

#### 🌳 Animais da Floresta (_Animaux de la Forêt_)

|Francês (Singular)|Gênero|Pronúncia Aproximada|Significado (PT-BR)|
|---|---|---|---|
|**Le lion**|Masc.|/lœ ljɔ̃/|Leão|
|**L'ours**|Masc.|/luʀs/|Urso|
|**Le tigre**|Masc.|/lœ tigʀ/|Tigre|
|**Le zèbre**|Masc.|/lœ zɛbʀ/|Zebra|
|**Le serpent**|Masc.|/lœ sɛʀpɑ̃/|Cobra/Serpente|
|**La souris**|Fem.|/la suʀi/|Rato|
|**Le renard**|Masc.|/lœ ʀənaʀ/|Raposa|

#### 🚜 Animais da Fazenda (_Animaux de la Ferme_)

|Francês (Singular)|Gênero|Pronúncia Aproximada|Significado (PT-BR)|
|---|---|---|---|
|**La vache**|Fem.|/la vaʃ/|Vaca|
|**Le mouton**|Masc.|/lœ mutɔ̃/|Ovelha/Carneiro|
|**Le cochon**|Masc.|/lœ koʃɔ̃/|Porco|
|**Le canard**|Masc.|/lœ kanaʀ/|Pato|
|**La chèvre**|Fem.|/la ʃɛvʀ/|Cabra|
|**Le coq**|Masc.|/lœ kɔk/|Galo|

---

### 2️⃣ Estrutura I: CHEZ (Na Casa de / No Local de)

**Chez** é uma preposição exclusiva do francês, usada para indicar a **casa, o local de trabalho, ou o estabelecimento** de uma pessoa ou profissão. No português, é traduzido por "na casa de", "no consultório de", etc.

|Estrutura|Exemplo em Francês|Significado (PT-BR)|
|---|---|---|
|**Chez** + **Pronome Tônico**|**Je vais chez moi.**|Eu vou para minha casa.|
|**Chez** + **Nome Próprio**|**Chez ma grand-mère.**|Na casa da minha avó.|
|**Chez** + **Profissão**|**Je vais chez le dentiste.**|Eu vou ao dentista (no consultório dele).|

**Pronomes Tônicos (Revisão):**

- **Moi** (Eu)
    
- **Toi** (Você)
    
- **Lui** (Ele)
    
- **Elle** (Ela)
    
- **Nous** (Nós)
    
- **Vous** (Você/Vocês Formal)
    
- **Eux** (Eles)
    
- **Elles** (Elas)
    

---

### 3️⃣ Estrutura II: IL Y A (Haver / Existe)

**Il y a** é uma expressão invariável usada para indicar **existência** de algo. Ela equivale a "há" ou "tem" (no sentido de existir) em português.

|Estrutura|Exemplo em Francês|Significado (PT-BR)|
|---|---|---|
|**Il y a** + **Substantivo**|**Il y a un aquário chez moi.**|Há (Tem) um aquário na minha casa.|
||**Il y a beaucoup de lapins.**|Há muitos coelhos.|

**Uso Adicional (Tempo):** _Il y a_ também significa "faz/há tempo" (Ex: _Il y a deux ans_ = Há dois anos).

---

### 4️⃣ Gênero dos Animais (Feminino vs. Masculino)

Lembre-se que o gênero dos animais em francês é definido pelo artigo (**Le/Un** para masculino, **La/Une** para feminino) e pelo adjetivo.

|Animal|Masculino (M)|Feminino (F)|
|---|---|---|
|**Leão**|**Le lion**|**La lionne**|
|**Novo (Adjetivo)**|**Nouveau**|**Nouvelle**|
|**Africano (Nacionalidade)**|**Africain**|**Africaine**|

**Exemplo de Concordância:**

- _Il y a un **nouveau** lion **africain** au zoo._ (Masc. Sing.)
    
- _Il y a une **nouvelle** lionne **africaine** au zoo._ (Fem. Sing.)
    

---

### 5️⃣ Vocabulário de Conversação (_Enquête_)

|Expressão|Significado (PT-BR)|
|---|---|
|**Faire une enquête**|Fazer uma pesquisa/levantamento.|
|**Un endroit**|Um lugar, um sítio.|
|**Est-ce que... ?**|Usado para introduzir uma pergunta (forma _standard_).|
|**Combien de fois par an ?**|Quantas vezes por ano?|
|**Parfaitement**|Perfeitamente, com certeza.|
|**Bien sûr**|Claro, com certeza.|
|**Rarement**|Raramente.|
|**D’accord !**|De acordo!|
|**Une idée super**|Uma ideia ótima/super.|

---

### 📝 Devoir (Lição de Casa)

**Pratique a Descrição de Animais e Lugares:**

1. Crie pelo menos 5 frases usando a estrutura **Chez** e o vocabulário de animais para indicar onde eles estão (_Ex: Le chat est chez le voisin._ – O gato está na casa do vizinho.)
    
2. Crie pelo menos 5 frases usando **Il y a** e o vocabulário de animais para indicar a existência de algo em um local (_Ex: Il y a des moutons à la ferme._ – Há ovelhas na fazenda.)
    
3. Tente formular uma pergunta complexa como no diálogo, usando **Est-ce que** e **combien de fois** para praticar.
