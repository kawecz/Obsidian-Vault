---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Carte Postale | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/OWjSwEQhHrc?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: A Carta Postal (_La Carte Postale_) e a Escrita Criativa

### 🎯 Visão Geral da Aula

Esta lição (Curso #16, focada na **escrita**) concentra-se na arte de redigir uma **carta postal** (_carte postale_), um formato conciso e pessoal para relatar impressões de viagem e atividades. O conteúdo é estruturado para ensinar o uso de vocabulário de impressões, atividades de viagem, expressões climáticas e, fundamentalmente, os **Adjetivos Demonstrativos** para apontar e descrever lugares.

### [[aula16.pdf]]
---

### 👑 Verbo Essencial: Écrire (Escrever)

**Écrire** é um verbo irregular do 3º Grupo, essencial para o tema da escrita.

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**j'écris**|**Nous**|**écrivons**|
|**Tu**|**écris**|**Vous**|**écrivez**|
|**Il/Elle/On**|**écrit**|**Ils/Elles**|**écrivent**|

**Observação:** A terminação é irregular, mas a pronúncia de _j'écris_, _tu écris_ e _il/elle écrit_ é a mesma (como _êcri_). O **J'écris** utiliza a contração (_j'_) pois o verbo começa com vogal (_e_).

---

### 💌 Início e Fim da Carta (Saudações Formais e Informais)

Para iniciar ou terminar uma carta postal com intimidade.

|Função|Francês|Significado (PT-BR)|Observação de Gênero/Plural|
|---|---|---|---|
|**Saudação (Formal/Informal)**|**Cher / Chère**|Querido / Querida|Adjetivo: **Chère** (fem. sing.), **Chers** (masc. plural), **Chères** (fem. plural).|
|**Saudação (Informal)**|**Coucou**|Oi / Olá|Informal e carinhoso.|
|**Saudação (Informal)**|**Salut**|Oi / Olá||
|**Encerramento (Beijos)**|**Bisous**|Beijos|Uso informal.|
|**Encerramento (Beijos)**|**Bises**|Beijos|Uso informal.|
|**Encerramento (Abraço/Beijo)**|**Je t'embrasse**|Te dou um beijo / Te abraço|_Embrasser_ significa beijar ou abraçar.|
|**Encerramento (Amigável)**|**Amicalement**|Amigavelmente|Usado quando a relação não é íntima.|
|**Encerramento (Ênfase)**|**Gros bisous**|Beijões / Muitos beijos|_Gros_ (grande) é usado como intensificador.|

---

### 🤩 Impressões de Viagem e Clima

|Expressão / Frase|Significado (PT-BR)|Vocabulário-Chave|
|---|---|---|
|**Set pays / Cette ville est...**|Este país / Esta cidade é...|**Pays** (Masc.) País / **Ville** (Fem.) Cidade.|
|**Magnifique**|Maravilhoso(a)|Não varia no feminino/masculino na escrita.|
|**Beau / Belle**|Bonito / Bonita|Variação de gênero: _Un pays **beau**_ / _Une ville **belle**_.|
|**Génial**|Legal / Fantástico|Em francês, significa "super legal", não necessariamente "gênio".|
|**Extraordinaire**|Extraordinário(a)||
|**Je passe des vacances...**|Estou passando férias...|**Vacances** (Fem. Plural) Férias.|
|**Il fait beau**|O tempo está bom/bonito|Expressão usada para o clima (sol, agradável).|
|**Il fait mauvais**|O tempo está ruim|Expressão usada para o clima (fechado, desagradável).|
|**Il fait chaud / froid**|Faz calor / frio|_Chaud_ (calor) / _Froid_ (frio).|

---

### 🏞️ Atividades de Viagem

|Atividade|Francês|Gramática/Vocabulário|
|---|---|---|
|**Caminhar nos parques**|**Marcher dans les parcs**|_Marcher_ (andar). _Parc_ é masc., mas aqui no plural.|
|**Visitar museus**|**Visiter des musées**|_Musée_ (museu).|
|**Ir à praia**|**Aller à la plage**|_Plage_ (Fem.) Praia. Uso do verbo _Aller_.|
|**Passear na cidade**|**Me promener dans la ville**|**Se promener** (verbo pronominal) significa passear.|
|**Fazer compras**|**Faire des achats / Faire du shopping**|_Faire_ (fazer).|
|**Aproveitar para...**|**Profiter pour...**|**Regra:** Após a preposição **pour**, o verbo seguinte fica no **Infinitivo** (Ex: _Profiter pour acheter_).|

---

### 📌 Adjetivos Demonstrativos (_Les Adjectifs Démonstratifs_)

Usados para "apontar" ou "demonstrar" algo (Este, Esta, Estes, Estas).

|Gênero/Número|Francês|Regra|Exemplos|
|---|---|---|---|
|**Masculino Singular**|**Ce**|Usado antes de palavras que começam com **consoante**.|_Ce voyage_ (Esta viagem)|
|**Masculino Singular**|**Cet**|Usado antes de palavras que começam com **vogal** ou **'h' mudo** (para evitar o som desagradável).|_Cet hôtel_, _Cet endroit_|
|**Feminino Singular**|**Cette**|Usado antes de qualquer palavra feminina.|_Cette plage_, _Cette ville_|
|**Plural (Masc. & Fem.)**|**Ces**|Não há distinção de gênero no plural.|_Ces musées_, _Ces plages_|

**Exemplo de Aplicação:** _C'est un pays magnifique._ (É um país magnífico.)

---

### 📬 Estrutura do Endereço na França

|Campo|Francês|Observação|
|---|---|---|
|**Nome do Destinatário**|**[PRÉNOM] [NOM]**|O **Sobrenome (NOM)** é frequentemente escrito em maiúsculas por ser a informação principal.|
|**Endereço**|**[NÚMERO] [RUE/AVENUE]**|**Regra:** O número vem antes do nome da rua.|
|**CEP e Cidade**|**[CODE POSTAL] [VILLE]**|Não se utiliza "estado" (UF) na França.|
|**País**|**France**||

---

### 📝 Sugestão de Prática (Devoir)

**Simule sua Viagem:**

1. **Escolha um local:** Um lugar que você visitou ou gostaria de visitar (Brasil, Espanha, etc.).
    
2. **Escreva uma _Carte Postale_** curta:
    
    - **Inicie** com uma saudação informal (_Coucou_, _Cher/Chère_).
        
    - **Use** o vocabulário de impressões e clima (_Il fait chaud_, _C'est magnifique_).
        
    - **Descreva** uma ou duas atividades (_Je me promène_, _Je visite..._).
        
    - **Empregue** pelo menos um dos Adjetivos Demonstrativos (_Ce, Cet, Cette, Ces_).
        
    - **Finalize** com uma despedida carinhosa (_Gros bisous_, _Je t'embrasse_).
        

_(Esta aula focou intensamente na **escrita**, então a prática escrita é o método mais eficaz para memorizar o vocabulário e as regras de gênero/concordância.)_