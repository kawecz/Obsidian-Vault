---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---


---
<iframe title="Francês | Kultivi - Au Restaurant | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/GLigoAHr17o?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Gastronomia e Restaurantes (Au Restaurant)

---

### 🎯 Visão Geral da Aula

Esta lição se aprofunda na **Gastronomia Francesa** e no vocabulário prático necessário para interagir em um **restaurante** (_au restaurant_). A aula aborda a estrutura típica das refeições francesas (_déjeuner_ e _dîner_), apresenta pratos e termos comuns (_entrée_, _plat principal_, _dessert_), e ensina frases essenciais para **pedir** e **pagar** a conta.

### [[aula12.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## 🍽️ O Universo da Gastronomia Francesa

A cultura gastronômica francesa valoriza a separação das etapas da refeição e a qualidade dos ingredientes.

### Estrutura das Refeições

|Refeição|Francês|Horário Típico|Observação|
|---|---|---|---|
|Almoço|**Le déjeuner**|Meio-dia (_midi_)|Geralmente inclui entrada, prato principal e sobremesa.|
|Jantar|**Le dîner**|Noite (_soir_)||
|Lanche da Tarde|**Le goûter**|Por volta das 16h|Baseado em **pâtisseries** (doces) ou **gâteaux** (bolos).|

### Vocabulário de Alimentos e Bebidas

|Categoria|Francês|Significado (PT-BR)|
|---|---|---|
|Pães e Doces|**Baguette**, **Croissant**, **Pâtisserie**, **Gâteau**|Pão, Croissant, Doce/Pastelaria, Bolo.|
|Massa (comida)|**Pâte**|Massa (ingrediente, e.g., macarrão, lasanha).|
|Queijo|**Fromage**|Os queijos são muito apreciados e variados.|
|Carne|**Viande**|Carne (em geral).|
|Peixe|**Poisson**|Peixe.|
|Frango|**Poulet**|Frango.|
|Bebidas|**Vin** (Vinho), **Bière** (Cerveja), **Tisane** (Chá de Ervas), **Jus de fruit** (Suco de fruta).||

### Partes da Refeição (_Les Étapes du Repas_)

|Etapa|Francês|Significado (PT-BR)|
|---|---|---|
|Entrada|**L'entrée** (Fem.)|Primeiro prato, geralmente leve.|
|Prato Principal|**Le plat principal**|O prato de carne/peixe/massa.|
|Acompanhamento|**L'accompagnement** (Masc.)|O que acompanha o prato principal (e.g., batatas, legumes).|
|Sobremesa|**Le dessert**|Sobremesa.|
|Café (após)|**Café / Un petit noir**|Tomado no final da refeição.|

## 👨‍🍳 Vocabulário de Restaurante e Pratos Comuns

|Item / Prato|Francês|Observação|
|---|---|---|
|Cardápio|**La carte / Le menu**|_La carte_ (cardápio completo), _Le menu_ (prato do dia/opção fechada).|
|Patê de Fígado|**Le foie gras**|Patê de fígado de pato ou ganso, servido como entrada.|
|Caseiro|**Fait maison**|Indica que o prato foi preparado ali (_home made_).|
|Frango Assado|**Le poulet rôti**|Frango assado.|
|Batatas Fritas|**Les frites** (Fem. Plural)||
|Hambúrguer|**Un burger**|Usam a palavra importada, mas pronunciam com sotaque francês (_bourguer_).|
|Crepe Salgado|**Une crêpe**|Panqueca fina, pode ser recheada e servida como prato principal.|
|Fondue|**La fondue**|Preparação de queijo ou chocolate derretido.|
|Prato do Dia|**Le plat du jour**|Opção especial, geralmente mais acessível.|
|Conta|**L'addition** (Fem.)|A conta.|

## 🥩 Ponto da Carne (_Cuisson de la Viande_)

Ao pedir carne (_viande_), você deve especificar o ponto de cozimento (_cuisson_).

|Ponto|Francês|Nível de Cozimento|
|---|---|---|
|Mal Passado|**Bleu / Saignant**|Cru, Vermelho|
|Ao Ponto para Mal|**À point**|No ponto|
|Ao Ponto para Bem|**Bien cuit**|Bem cozido, sem sangue|

## 🗣️ Interagindo no Restaurante

### Fazendo o Pedido

|Frase|Tradução (PT-BR)|Uso|
|---|---|---|
|**Je voudrais...**|Eu gostaria de...|Forma educada de pedir.|
|**Je vais prendre...**|Eu vou querer/pegar...|Mais direto, comum ao fazer a escolha.|
|**Le plat du jour, s'il vous plaît.**|O prato do dia, por favor.||
|**Qu'est-ce que c'est le [prato]?**|O que é o [prato]?|Para pedir a descrição de um item no menu.|

### Durante a Refeição

|Frase|Tradução (PT-BR)|
|---|---|
|**Bon appétit!**|Bom apetite!|
|**Ça vous a plu?**|Isso lhe agradou/Você gostou?|
|**L'addition, s'il vous plaît.**|A conta, por favor.|

### Talheres e Utensílios (_Les Couverts_)

|Item|Francês|
|---|---|
|Faca|**Un couteau**|
|Garfo|**Une fourchette**|
|Colher|**Une cuillère**|
|Copo|**Un verre**|

## ⚠️ Conjugação do Verbo Manger (Comer)

O verbo **Manger** (comer) é do 1º Grupo, mas exige uma regra ortográfica para manter o som:

|Pronome|Conjugação|Regra Especial|
|---|---|---|
|**Nous**|**Nous mangeons**|Adiciona-se um **'e'** antes do _-ons_ para manter a pronúncia _manjôn_ (se fosse _mangons_, teria som de G duro).|
|Os demais|_Je mange, tu manges, etc._|Seguem o padrão regular.|
