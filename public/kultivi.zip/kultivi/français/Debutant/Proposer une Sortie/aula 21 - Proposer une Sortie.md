---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Proposer une Sortie | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/iw-DGhq1W-4?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Propor uma Saída (_Proposer une Sortie_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #21) concentra-se na comunicação social: como propor um encontro (_rendez-vous_), aceitar ou recusar convites, e, crucialmente, introduzir o **pronome informal "On"**, amplamente usado na conversação cotidiana.

### [[aula21.pdf]]
---

### 1️⃣ O Conceito de Rendez-Vous (Encontro Marcado)

**Rendez-vous** (frequentemente abreviado para **R-D-V** em mensagens de texto) é uma palavra fundamental em francês e significa um **encontro marcado** em um local e hora específicos. Pode ser:

- Formal (ex: consulta médica, reunião de trabalho).
    
- Informal (ex: um encontro romântico, um programa entre amigos).
    

---

### 2️⃣ Expressões para Propor uma Saída

Para propor uma saída, geralmente usamos os verbos **Vouloir** (Querer) e **Pouvoir** (Poder), seguidos pelo **Infinitivo** do verbo da atividade.

#### Conjugação e Uso dos Verbos Auxiliares

|Verbo|Pronome|Conjugação|Pronúncia|Observação de Escrita|
|---|---|---|---|---|
|**Vouloir** (Querer)|**Je**|**veux**|/jə vø/|Termina em **-x**.|
||**Tu**|**veux**|/ty vø/|Termina em **-x**.|
||**Il/Elle/On**|**veut**|/il vø/|Termina em **-t**.|
||**Nous**|**voulons**|/nu vulɔ̃/||
||**Vous**|**voulez**|/vu vule/||
||**Ils/Elles**|**veulent**|/il vœl/||
|**Pouvoir** (Poder)|**Je**|**peux**|/jə pø/|Termina em **-x**.|
||**Tu**|**peux**|/ty pø/|Termina em **-x**.|
||**Il/Elle/On**|**peut**|/il pø/|Termina em **-t**.|
||**Nous**|**pouvons**|/nu puvɔ̃/||
||**Vous**|**pouvez**|/vu puve/||
||**Ils/Elles**|**peuvent**|/il pœv/||

**Perguntas Comuns:**

- **Tu veux sortir au restaurant avec moi ?** (Você quer sair para um restaurante comigo?)
    
- **On peut aller au cinéma ?** (A gente pode ir ao cinema?)
    
- **Où est-ce qu'on se retrouve ?** (Onde a gente se encontra?)
    

---

### 3️⃣ Introdução ao Pronome Informal ON (A Gente / Nós)

O pronome **On** é extremamente comum no francês falado e significa **"a gente"** ou **"nós"** (em um sentido informal).

|Pronome|Conjugação Verbal|Significado (PT-BR)|Observação|
|---|---|---|---|
|**On**|**A mesma de IL/ELLE**|A gente / Nós|É o equivalente informal de **Nous**.|

**Exemplos com "On":**

- **On va** au cinéma. (A gente vai/Nós vamos ao cinema.)
    
- **On prend** un rendez-vous. (A gente marca um horário.)
    
- **On veut** boire une bière. (A gente quer beber uma cerveja.)
    

**Regra-Chave:** Sempre use a conjugação da **terceira pessoa do singular (Il/Elle)** com o pronome **On**.

---

### 4️⃣ Aceitar e Recusar Propostas

|Ação|Expressões em Francês|Significado (PT-BR)|
|---|---|---|
|**Aceitar**|**D'accord ! / Ça me va.**|De acordo! / Isso me agrada/serve.|
||**Oui, avec plaisir.**|Sim, com prazer.|
||**Bien sûr. / Ça marche.**|Claro. / Funciona (para mim).|
||**Je veux bien !**|Eu quero muito! (_Veux bien_ é um intensificador de _Vouloir_.)|
|**Recusar**|**Je ne suis pas disponible.**|Eu não estou disponível.|
||**Je ne peux pas, désolé(e).**|Eu não posso, desculpa.|
||**Je suis pris(e).**|Eu estou ocupado(a).|
||**Ce n'est pas possible...**|Não é possível...|

---

### 5️⃣ Dicas Culturais e de Estudo

#### Comunicação na França

- O **SMS** (mensagem de texto tradicional) ainda é amplamente utilizado na França, muito mais do que o WhatsApp.
    
- **Sa va?** e **Ça marche?** são expressões informais muito comuns para checar se a proposta é conveniente.
    

#### Imersão e Prática

- **Escute Rádio:** A rádio **France Info** (disponível online e para escuta _en direct_) é uma ótima fonte de francês cotidiano.
    
- **Consuma Mídia:** Assista a **vídeos de notícias** e leia **textos curtos** (1 texto/dia) em sites franceses para treinar audição e leitura.
    
- **Música:** A cantora **Zaz** (estilo jazz/pop francês) tem canções como **"Je veux"** (Eu quero), que usa o verbo _Vouloir_ de forma simples e expressiva.
    

---

### 📝 Devoir (Lição de Casa)

**Simule uma Conversa por SMS:**

1. Crie uma conversa de texto curta em francês propondo um encontro (_rendez-vous_) a um amigo.
    
2. Use o pronome **On** para fazer a proposta (_Ex: On va boire un verre ?_).
    
3. Inclua perguntas sobre o dia ou horário disponível (_Ex: Tu es libre mardi soir ?_).
    
4. Pratique as frases de aceitação ou recusa que aprendeu.
    

Essa prática te ajudará a internalizar a informalidade e as estruturas de convite essenciais no francês falado!