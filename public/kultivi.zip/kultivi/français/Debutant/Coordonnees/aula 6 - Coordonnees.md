---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Coordonnées | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/XtgSYjd8PCM?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Coordenadas e Dados Pessoais (Coordonnées et Informations Personnelles)

---

### 🎯 Visão Geral da Aula

Esta aula aborda o vocabulário e as estruturas gramaticais necessárias para solicitar e fornecer **"coordenadas" (_coordonnées_)**, que no contexto francês se refere a **dados pessoais e de contato**. A lição foca na concordância do adjetivo interrogativo **Quel/Quelle** (Qual/Quais) com substantivos como **nome**, **endereço**, **e-mail** e **telefone**, enfatizando a importância do **gênero** (masculino/feminino) e do **número** (singular/plural) dos substantivos. A parte final é dedicada à prática auditiva de **números de telefone**, reforçando a importância da **escuta constante** para o aprendizado do idioma.

### [[aula6.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## Coordonnées (Dados de Contato)

_Coordonnées_ (Coordenadas) é um termo amplo que engloba os dados necessários para localizar e contatar uma pessoa.

### O Adjetivo Interrogativo: Quel / Quelle

A pergunta "**Qual/Quais são suas coordenadas?**" em francês (_Quelles sont vos coordonnées ?_) exige o uso do adjetivo interrogativo correto, que deve **concordar em gênero e número** com o substantivo que o acompanha.

|Gênero e Número|Forma|Aplicação|
|---|---|---|
|**Masculino Singular**|**Quel**|**Quel** est votre **nom** ? (Qual é o seu nome?)|
|**Feminino Singular**|**Quelle**|**Quelle** est votre **adresse** ? (Qual é o seu endereço?)|
|**Masculino Plural**|**Quels**|**Quels** sont vos **numéros** ? (Quais são seus números?)|
|**Feminino Plural**|**Quelles**|**Quelles** sont vos **coordonnées** ? (Quais são suas coordenadas?)|

**Adição de Informação:** A concordância é uma das "armadilhas" mais comuns para falantes de português. Por exemplo, _adresse_ (endereço) é **feminino** em francês, mas masculino em português.

### Vocabulário Essencial de Contato

|Vocabulário|Gênero/Número|Pergunta Comum|
|---|---|---|
|**Le nom**|Masc. Sing.|**Quel** est votre nom ?|
|**Le prénom**|Masc. Sing.|**Quel** est votre prénom ? (Primeiro nome)|
|**L'adresse**|Fem. Sing.|**Quelle** est votre adresse ?|
|**L'adresse e-mail**|Fem. Sing.|**Quelle** est votre adresse e-mail ?|
|**Le numéro de téléphone**|Masc. Sing.|**Quel** est votre numéro de téléphone ?|
|**L'âge**|Masc. Sing.|**Quel** âge avez-vous ? (Revisão da aula anterior)|
|**La nationalité**|Fem. Sing.|**Quelle** est votre nationalité ?|

**Observação:** O uso de **mon/ma/mes** (meu/minha/meus) ou **votre/vos** (seu/sua/seus) também deve seguir a concordância do substantivo.

|Substantivo|Pronome Possessivo (Singular)|
|---|---|
|Masculino Singular|**Mon** (Mon nom, mon téléphone)|
|Feminino Singular|**Ma** (Ma carte, ma nationalité)|
|Feminino/Masculino Plural|**Mes** (Mes coordonnées)|

## Prática de Números de Telefone

A aula incluiu um ditado para praticar a audição e escrita de números de telefone, reforçando o conhecimento da aula anterior sobre números.

### Dicas de Escuta para Números

1. **"Zero" é _Zéro_**: O zero é sempre lido.
    
2. **Agrupamento em Pares**: Os números de telefone são lidos em **grupos de dois dígitos** (e.g., _quarante-cinq_, _soixante-dix-huit_).
    
3. **Foco em 70, 80 e 90**: Preste atenção especial aos números _soixante-dix_ (70), _quatre-vingts_ (80) e _quatre-vingt-dix_ (90), pois eles exigem uma audição mais atenta.
    

## 🎧 A Importância da Imersão

A conclusão da aula reitera a estratégia de aprendizado mais eficaz para qualquer língua: a **escuta e o contato constantes**.

> **Ouvir Antes de Falar:** O processo natural de aprendizado de um idioma (assim como aprendemos nossa língua materna) começa pela **escuta** e pela **imersão**, e só depois passamos à produção (fala).

**Ações Sugeridas:**

- Assistir a **filmes e séries** em francês.
    
- Ouvir **rádios francesas** (e.g., France Inter).
    
- Dedicar **10 minutos diários** a um "relacionamento sério" com o francês.
    

---

## 📚 Tópicos Gramaticais Chave

### Substantivos (_Les Noms_)

|Palavra|Significado (PT-BR)|Categoria|
|---|---|---|
|**Les coordonnées**|Os dados de contato|Feminino Plural|
|**L'adresse**|O endereço|Feminino Singular|
|**L'e-mail**|O e-mail|Masculino Singular|
|**Le nom**|O nome|Masculino Singular|
|**La faute**|O erro (falha)|Feminino Singular|

### Adjetivos (_Les Adjectifs_)

|Palavra|Significado (PT-BR)|Concordância no Contexto|
|---|---|---|
|**Quel/Quelle**|Qual|Deve concordar em gênero/número com o substantivo (e.g., _Quelle_ adresse).|
|**Masculin/Féminin**|Masculino/Feminino|Descreve o gênero gramatical dos substantivos.|
|**Grand(e)**|Grande|_Une grande faute_ (Um grande erro)|

### Preposições e Conectores (_Les Prépositions et Mots de Liaison_)

|Palavra|Significado (PT-BR)|Função no Contexto|
|---|---|---|
|**chez**|na casa de, no lugar de|_chez les amis_ (na casa dos amigos).|
|**ou**|ou|Alternativa (_le nom **ou** le prénom_).|
|**de**|de|Usado em _numéro **de** téléphone_.|