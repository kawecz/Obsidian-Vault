---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - L'Affirmation et la Négation | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/Zkwu2vLMq0A?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Afirmação e Negação (L'Affirmation et La Négation)

---

### 🎯 Visão Geral da Aula

Esta é uma aula intensiva de gramática focada em duas estruturas fundamentais do francês: a **Afirmação (_L'Affirmation_)** e a **Negação (_La Négation_)**. A primeira parte da aula revisa a conjugação dos verbos regulares (Grupos 1 e 2), introduzindo o conceito de **radical (_la base_)** e **terminações (_terminaisons_)** fixas. A segunda parte se aprofunda na estrutura da negação (_ne... pas_) e suas variações (_ne... plus_, _ne... jamais_, _ne... rien_), sendo esta uma das regras com **pouquíssimas exceções** no idioma.

### [[aula8.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## L'Affirmation: Os Verbos no Modo Indicativo

Afirmar algo em francês (presente, passado ou futuro) geralmente utiliza o **Modo Indicativo** (_Mode Indicatif_). Os verbos em francês são divididos em três grupos, baseados em suas terminações e padrões de conjugação:

### Grupo 1: Verbos em -ER e Alguns em -IR

|Característica|Verbos terminados em **-ER** (maioria) e alguns em **-IR** (_offrir_, _ouvrir_).|
|---|---|
|**Base** (Radical)|Retira-se o **-ER** ou **-IR** da forma infinitiva.|
|**Exemplos**|_Manger_ (comer), _Aimer_ (amar/gostar), _S'appeler_ (chamar-se), _Offrir_ (ofertar).|

#### Terminações do Grupo 1 (Presente)

|Pronome|Terminação|Exemplo (_Manger_ - Comer)|Pronúncia da Terminação|
|---|---|---|---|
|**Je**|**-e**|_Je mange_|Mudo|
|**Tu**|**-es**|_Tu manges_|Mudo|
|**Il/Elle/On**|**-e**|_Il/Elle mange_|Mudo|
|**Nous**|**-ons**|_Nous mangeons_|_-õ_ (som nasal)|
|**Vous**|**-ez**|_Vous mangez_|_-ê_ (som fechado)|
|**Ils/Elles**|**-ent**|_Ils/Elles mangent_|Mudo|

**Regra de Pronúncia:** As terminações **-e**, **-es** e **-ent** são **muda**s no oral.

### Grupo 2: Verbos em -IR

|Característica|Verbos terminados em **-IR** (segundo padrão) e, menos comum, **-OIR** e **-RE**.|
|---|---|
|**Base** (Radical)|Retira-se o **-IR** da forma infinitiva.|
|**Exemplos**|_Finir_ (acabar), _Choisir_ (escolher), _Sortir_ (sair), _Lire_ (ler), _Savoir_ (saber - mas é irregular).|

#### Terminações do Grupo 2 (Presente - Padrão Mais Comum em -IR)

O padrão mais regular do Grupo 2 (verbos como _finir_, _choisir_) usa a base **+ -iss** + as terminações: **-s, -s, -t, -ssons, -ssez, -ssent**.

|Pronome|Terminação (em -IR mais usado)|Exemplo (_Finir_ - Acabar)|
|---|---|---|
|**Je**|**-s**|_Je sors_ / _Je lis_ (Para _sortir_ e _lire_)|
|**Tu**|**-s**|_Tu sors_ / _Tu lis_|
|**Il/Elle/On**|**-t**|_Il/Elle sort_ / _Il/Elle lit_|
|**Nous**|**-ons**|_Nous sortons_ / _Nous lisons_|
|**Vous**|**-ez**|_Vous sortez_ / _Vous lisez_|
|**Ils/Elles**|**-ent**|_Ils/Elles sortent_ / _Ils/Elles lisent_|

**Exemplo Irregular (_Savoir_ - Saber):** A base muda nos três primeiros pronomes. _Je sais, tu sais, il/elle sait_ (base **sa-**) e _nous savons, vous savez, ils/elles savent_ (base **sav-**).

### Grupo 3: Os Irregulares

Verbos que não se encaixam nos Grupos 1 ou 2, como **Être** (ser/estar) e **Avoir** (ter). Devem ser memorizados individualmente.

---

## ⛔ La Négation (A Negação)

A negação básica em francês é formada por um **bloco** que envolve o verbo conjugado.

### A Estrutura Básica (Ne... Pas)

A regra de ouro é: O **verbo fica sempre no meio** dos dois elementos da negação.

![](data:,)

|Exemplo de Afirmação|Negação (Simples)|Tradução|
|---|---|---|
|_Je suis Brésilien._|**Je ne suis pas** Brésilien.|Eu **não sou** brasileiro.|
|_Tu as 50 ans._|**Tu n'as pas** 50 ans.|Você **não tem** 50 anos.|

**Importante:** Se o verbo começar com uma **vogal** ou **'h' mudo**, o **ne** vira **n'** (e.g., _Je n'ai pas_ ao invés de _Je ne ai pas_).

### Variações da Negação

O **pas** pode ser substituído por outros advérbios para criar negações mais específicas:

|Negação|Significado|Estrutura|Exemplo|
|---|---|---|---|
|**Ne... plus**|Não... **mais**|![](data:,)|_Je ne mange **plus** de chocolat._ (Eu não como **mais** chocolate.)|
|**Ne... jamais**|Não... **jamais** ou **nunca**|![](data:,)|_Il ne sort **jamais** le dimanche._ (Ele **nunca** sai no domingo.)|
|**Ne... rien**|Não... **nada**|![](data:,)|_Je ne lis **rien**._ (Eu não leio **nada**.)|
|**Ne... personne**|Não... **ninguém**|![](data:,)|_Je ne vois **personne**._ (Eu não vejo **ninguém**.)|

---

## 📚 Tópicos Gramaticais Chave

### Substantivos (_Les Noms_)

|Palavra|Gênero|Significado (PT-BR)|
|---|---|---|
|**La grammaire**|Fem. Singular|A gramática.|
|**La base**|Fem. Singular|O radical (do verbo).|
|**Le groupe**|Masc. Singular|O grupo (de verbos).|
|**L'affirmation**|Fem. Singular|A afirmação.|
|**La négation**|Fem. Singular|A negação.|

### Adjetivos (_Les Adjectifs_)

|Palavra|Forma|Significado (PT-BR)|
|---|---|---|
|**Irrégulier / Irrégulière**|Variável|Irregular (e.g., _un verbe irrégulier_).|
|**Important(e)**|Variável|Importante (e.g., _une règle importante_).|
|**Facile**|Variável|Fácil.|

### Conectores e Advérbios de Negação (_Les Mots de Liaison et Adverbes_)

|Palavra|Significado (PT-BR)|Função no Contexto|
|---|---|---|
|**et**|e|Conjunção (_ne... **et** pas_ - não se usa assim; a estrutura é fixa).|
|**plus**|mais|Advérbio de negação (_ne... plus_).|
|**jamais**|jamais, nunca|Advérbio de negação (_ne... jamais_).|
|**rien**|nada|Advérbio/Pronome de negação (_ne... rien_).|
|**pas**|não|O elemento básico da negação.|
