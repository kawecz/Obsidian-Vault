---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Indiquer Un Itinéraire | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/7MToIjSxeug?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Indicando um Itinerário (_Indiquer un Itinéraire_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #15) é fundamental para a comunicação prática, focando em como **pedir e dar direções** (_indiquer un chemin_) em francês. O desafio é dominar o vocabulário de orientação e a conjugação de verbos-chave irregulares (_Aller_, _Prendre_ e _Descendre_) para se locomover com confiança e entender as instruções de um nativo.

### [[aula15.pdf]]
---

### 🛣️ Vocabulário Essencial para Direções

Dominar estas expressões é o primeiro passo para se orientar ou orientar alguém.

|Expressão|Significado (PT-BR)|Observação de Uso|
|---|---|---|
|**Aller à gauche / Tourner à gauche**|Ir para a esquerda / Virar à esquerda|Usado para indicar a direção exata.|
|**Aller à droite / Tourner à droite**|Ir para a direita / Virar à direita||
|**Aller tout droit / Continuer tout droit**|Ir em frente / Continuar em frente|Indica um movimento sem desvios.|
|**Prendre la rue...**|Pegar a rua...|Indica que você deve entrar naquela via.|
|**Au bout de la rue**|No final da rua|Indica o término daquela rua.|
|**Au coin (de la rue)**|Na esquina (da rua)|Indica um ponto de virada ou de referência.|
|**Passer la rue...**|Passar pela rua...|Significa atravessar ou ultrapassar aquela rua.|

---

### 👑 Verbos Irregulares Chave

Estes verbos são cruciais para falar sobre movimento e transporte. Devem ser memorizados!

#### 1. Aller (Ir)

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**vais**|**Nous**|**allons**|
|**Tu**|**vas**|**Vous**|**allez**|
|**Il/Elle/On**|**va**|**Ils/Elles**|**vont**|

**Uso:** _Je **vais** à Paris._ (Eu vou a Paris.) _Vous **allez** vers la première à gauche._ (Vocês vão em direção à primeira à esquerda.)

#### 2. Prendre (Pegar / Tomar)

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**prends**|**Nous**|**prenons**|
|**Tu**|**prends**|**Vous**|**prenez**|
|**Il/Elle/On**|**prend**|**Ils/Elles**|**prennent**|

**Uso:** _Tu **prends** le bus tous les jours._ (Você pega o ônibus todos os dias.) _Vous **prenez** la deuxième rue à droite._ (Vocês pegam a segunda rua à direita.)

#### 3. Descendre (Descer / Desembarcar)

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**descends**|**Nous**|**descendons**|
|**Tu**|**descends**|**Vous**|**descendez**|
|**Il/Elle/On**|**descend**|**Ils/Elles**|**descendent**|

**Uso:** _Je **descends** à la prochaine station._ (Eu desço na próxima estação.) _Il **descend** de l'avion._ (Ele desce do avião.)

---

### 🔢 Numerais Ordinais (_Les Nombres Ordinaux_)

Usados para indicar a ordem das ruas ou saídas.

|Ordem|Francês (Masc./Fem.)|Significado (PT-BR)|
|---|---|---|
|1º/1ª|**Premier / Première**|Primeiro / Primeira|
|2º/2ª|**Deuxième**|Segundo / Segunda|
|3º/3ª|**Troisième**|Terceiro / Terceira|

**Exemplo:** _Prenez la **première** à gauche._ (Pegue a **primeira** à esquerda.)

---

### 🛵 Meios de Locomoção (_Moyens de Transport_)

As preposições **à** e **en** são usadas para indicar o modo de transporte.

|Modo|Francês|Preposição|Significado (PT-BR)|
|---|---|---|---|
|**A pé**|**À pied**|**À**|(Usado para partes do corpo)|
|**De bicicleta**|**À vélo**|**À**|(Usado para veículos sem motor, exceto trem/avião)|
|**De carro**|**En voiture**|**En**|(Usado para veículos motorizados e fechados)|
|**De trem**|**En train**|**En**||
|**De avião**|**En avion**|**En**||
|**De ônibus**|**En bus / En car**|**En**||

**Atenção:** A diferença entre as preposições **dans** (dentro) e **en** (no/por) é sutil no contexto de transporte. **"En voiture"** é a regra geral para "ir de carro", enquanto **"dans la voiture"** enfatiza que você está **dentro** do carro.

---

### 🗣️ Frases Úteis para Pedir Informação

Ao pedir direções, é fundamental usar a forma polida (_s'il vous plaît_) e a conjugação **Vous** (formal) ou o Condicional (_Je voudrais_).

|Pergunta (PT-BR)|Francês (Polido)|
|---|---|
|Como eu chego à estação de metrô, por favor?|**Comment je vais à la station de métro, s'il vous plaît ?**|
|Perdão, para ir à rodoviária, por favor?|**Pardon, pour aller à la gare routière, s'il vous plaît ?**|
|Qual é o caminho para a.../o...?|**Pour aller à la rue Pasteur, s'il vous plaît ?**|

---

### 📝 Devoir (Lição de Casa)

Para fixar o conteúdo, o desafio é **aplicar as direções à sua vida real**:

1. Pegue um mapa do seu bairro ou do caminho para o seu trabalho/escola.
    
2. Descreva, em francês, o itinerário de um ponto A para um ponto B, usando os verbos (_Prenez, Tournez, Allez_) e os numerais ordinais (_première, deuxième, troisième_).
    

_(Lembre-se: Praticar as conjugações de **Aller, Prendre** e **Descendre** é crucial, especialmente o **vous**, pois é a forma mais comum de se dirigir a desconhecidos.)_