---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Activités Sportives et Culturalles | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/mRKM_m1sKB8?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Atividades Esportivas e Culturais (_Activités Sportives et Culturelles_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #18) é dedicada à descrição de _hobbies_ e atividades. O foco principal está na correta utilização dos verbos **Aller** (ir), **Faire** (fazer/praticar) e **Jouer** (jogar/tocar), todos exigindo preposições de forma obrigatória, mas com regras de concordância (masculino/feminino/plural/vogal) distintas para cada verbo.

### [[aula18.pdf]]
---

### 1️⃣ Verbo Aller (Ir): Indo a Algum Lugar

O verbo **Aller** (ir) é usado para se locomover a um lugar, exigindo a preposição **à** (a). Esta preposição se contrai ou se adapta ao gênero e número do lugar.

#### Conjugação de Aller (Revisão)

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**vais**|**Nous**|**allons**|
|**Tu**|**vas**|**Vous**|**allez**|
|**Il/Elle/On**|**va**|**Ils/Elles**|**vont**|

#### Preposições de Lugar com Aller

|Preposição|Categoria do Lugar|Exemplo|Significado (PT-BR)|
|---|---|---|---|
|**Au** (a + le)|Lugar **Masculino Singular**|**Au** théâtre, **Au** restaurant, **Au** cinéma|Ao teatro, Ao restaurante|
|**À la**|Lugar **Feminino Singular**|**À la** montagne, **À la** campagne, **À la** piscine|À montanha, Ao interior|
|**À l'**|Lugar com **Vogal ou 'h' mudo**|**À l'**étranger, **À l'**opéra|Ao estrangeiro|
|**Aux** (a + les)|Lugar **Plural**|**Aux** États-Unis|Aos Estados Unidos|

**Cuidado:** O francês usa contrações. Nunca se diz _à le théâtre_, e sim **au théâtre**.

---

### 2️⃣ Verbo Faire (Fazer / Praticar)

O verbo **Faire** é o mais comum para descrever a **prática de esportes** ou **atividades** em geral (ex: fazer música, fazer foto). Ele exige a preposição **de**, que também se contrai.

#### Conjugação de Faire (Irregular)

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**fais**|**Nous**|**faisons**|
|**Tu**|**fais**|**Vous**|**faites**|
|**Il/Elle/On**|**fait**|**Ils/Elles**|**font**|

#### Preposições de Atividade com Faire

|Preposição|Gênero da Atividade|Exemplo|Significado (PT-BR)|
|---|---|---|---|
|**Du** (de + le)|Atividade **Masculina**|**Faire du** sport, **du** football, **du** vélo|Praticar esporte, ciclismo|
|**De la**|Atividade **Feminina**|**Faire de la** natation, **de la** cuisine|Praticar natação, cozinhar|
|**De l'**|Atividade com **Vogal**|**Faire de l'**escalade, **de l'**aquarelle|Praticar escalada|
|**Des** (de + les)|Atividade **Plural**|**Faire des** photos, **des** achats|Tirar fotos, fazer compras|

**Exemplos Comuns:**

- _Je fais du sport tous les jours._ (Eu pratico esporte todos os dias.)
    
- _Elle fait de la musique._ (Ela faz música.)
    

---

### 3️⃣ Verbo Jouer (Jogar / Tocar)

O verbo **Jouer** (jogar/tocar) possui dois sentidos principais no francês e, para cada um, uma **preposição diferente** é exigida.

#### Conjugação de Jouer

|Pronome|Conjugação|Pronome|Conjugação|
|---|---|---|---|
|**Je**|**joue**|**Nous**|**jouons**|
|**Tu**|**joues**|**Vous**|**jouez**|
|**Il/Elle/On**|**joue**|**Ils/Elles**|**jouent**|

#### ⚽ Sentido 1: Jogar (Esportes com bola, jogos de tabuleiro)

Neste sentido, exige a preposição **à** (a), seguindo a mesma regra de contração do verbo **Aller**.

|Preposição|Gênero do Jogo/Esporte|Exemplo|Significado (PT-BR)|
|---|---|---|---|
|**Au**|Jogo **Masculino Singular**|**Jouer au** tennis, **au** football|Jogar tênis, futebol|
|**À la**|Jogo **Feminino Singular**|**Jouer à la** pétanque|Jogar petanca|
|**Aux**|Jogo **Plural**|**Jouer aux** échecs|Jogar xadrez|

#### 🎶 Sentido 2: Tocar (Instrumentos Musicais)

Neste sentido, exige a preposição **de** (da/do), seguindo a mesma regra de contração do verbo **Faire**.

|Preposição|Gênero do Instrumento|Exemplo|Significado (PT-BR)|
|---|---|---|---|
|**Du**|Instrumento **Masculino**|**Jouer du** piano, **du** violon|Tocar piano, violino|
|**De la**|Instrumento **Feminino**|**Jouer de la** guitare, **de la** flûte|Tocar violão, flauta|
|**De l'**|Instrumento com **Vogal**|**Jouer de l'**harmonica|Tocar gaita|

**Cuidado com os Falsos Cognatos Musicais:**

- **La guitare** = Violão (no Brasil).
    
- **Le violon** = Violino.
    

---

### 🗣️ Expressões para Descrever Frequência

|Expressão|Significado (PT-BR)|
|---|---|
|**Tous les jours**|Todos os dias|
|**Le week-end**|No fim de semana|
|**Le matin / Le soir**|De manhã / De noite|
|**Presque**|Quase (_Ex: Presque tous les week-ends_ = Quase todos os finais de semana)|
|**Beaucoup**|Muito (_Ex: J'aime beaucoup le tennis._ = Eu gosto muito de tênis.)|

---

### 📚 Vocabulário-Chave

|Classe|Palavra em Francês|Significado (PT-BR)|
|---|---|---|
|**Substantivo**|_Le match_|Jogo, partida.|
||_La montagne_|Montanha.|
||_La campagne_|Interior (área rural, campo).|
||_L'étranger_ (m.)|Estrangeiro (o exterior).|
||_La natation_|Natação.|
||_Un groupe_|Uma banda, um grupo musical.|
|**Adjetivo**|_Préféré(e)_|Preferido(a).|

---

### 📝 Devoir (Lição de Casa)

Para fixar as regras de preposição complexas (_Au, À la, Du, De la, De l'_, etc.), é fundamental praticar a escrita.

Responda em francês às seguintes perguntas, utilizando os verbos **Faire, Aller** e/ou **Jouer** com a preposição correta:

1. **Quelles sont vos activités sportives préférées ?** (Quais são as suas atividades esportivas preferidas?)
    
2. **Quelles sont vos activités culturelles ?** (Quais são as suas atividades culturais?)
    
3. **Qu'est-ce que vous faites le week-end ?** (O que você faz no final de semana?)
    
4. **Quelles sont vos activités pendant les vacances ?** (Quais são as suas atividades durante as férias?)
    

_(Lembre-se: O verbo **Faire** é o mais versátil para esportes, e a concordância das preposições (**au, du, de la**) é obrigatória e deve ser treinada na escrita!)_