---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---

<iframe title="Francês | Kultivi - Se Présenter | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/Om2350h2i0U?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
# 🇫🇷 Aula 1 – Saudações, Apresentações e Expressões Básicas 


> [!summary] **Visão Geral**  
> Nesta aula, aprendemos a **cumprimentar**, **se despedir**, **agradecer**, **pedir desculpas** e **se apresentar** em francês. Também vimos a importância da diferença entre **formal** (_vous_) e **informal** (_tu_), além da conjugação do verbo **s’appeler** (chamar-se).

### [[aula1.pdf]]

---

## 🧑‍🤝‍🧑 Pronomes Pessoais

|Francês|Português|Observação|
|---|---|---|
|je|eu||
|tu|você/tu|informal|
|il|ele||
|elle|ela||
|nous|nós||
|vous|vocês / o senhor(a)|plural ou formal|
|ils|eles|**s** não se pronuncia|
|elles|elas|**s** não se pronuncia|

> [!tip] **Dica**  
> Use **tu** com amigos/família.  
> Use **vous** em situações formais ou ao falar com desconhecidos.

---

## 👋 Saudações

|Francês|Português|Uso|
|---|---|---|
|Bonjour|Bom dia|até ~18h, não existe “boa tarde”|
|Bonsoir|Boa noite (ao chegar)|após 18h|
|Bonne nuit|Boa noite (ao dormir)|equivalente a _good night_|
|Salut|Oi|informal|
|Coucou|Oizinho|íntimo|

---

## 🙂 Perguntar “Como vai?”

|Francês|Português|Formalidade|
|---|---|---|
|Vous allez bien ?|Você vai bem?|formal|
|Comment allez-vous ?|Como vai o senhor(a)?|formal|
|Ça va ?|Tudo bem?|informal|

---

## 🏁 Despedidas

|Francês|Português|Observação|
|---|---|---|
|Au revoir|Tchau|padrão formal|
|Bonne journée|Tenha um bom dia|ao se despedir de manhã/tarde|
|Bonsoir (despedida)|Boa noite|ao sair do trabalho/festa|
|Bon week-end|Bom fim de semana|França|
|Bon FDS|Bom fim de semana|Canadá|
|À demain|Até amanhã|também com dias da semana: _à lundi_|
|Bisous|Beijos|íntimo|
|Tchao|Tchau|igual ao português|

---

## 🙏 Agradecimentos

|Francês|Português|Uso|
|---|---|---|
|Merci|Obrigado(a)|padrão|
|Merci beaucoup|Muito obrigado(a)|comum|
|Merci bien|Muito obrigado(a)|variante|
|Je vous remercie|Agradeço-lhe|formal|

### De nada

|Francês|Português|Formalidade|
|---|---|---|
|Je vous en prie|De nada|formal|
|De rien|De nada|informal|

---

## ❌ Pedir Desculpas

|Francês|Português|Contexto|
|---|---|---|
|Pardon|Perdão|forte, situações sérias|
|Désolé(e)|Desculpe|leve, cotidiano|
|Excusez-moi|Com licença / Desculpe|ao interromper alguém|

---

## 🙋 Verbo _s’appeler_ (chamar-se)

> [!info] **Verbo pronominal**  
> Sempre acompanhado de pronome reflexivo (_me, te, se, nous, vous, se_).

|Pessoa|Conjugação|Pronúncia|
|---|---|---|
|je|je m’appelle|jə mapél|
|tu|tu t’appelles|ty tapél|
|il/elle|il/elle s’appelle|il sapél / el sapél|
|nous|nous nous appelons|nu nu zaplõ|
|vous|vous vous appelez|vu vu zaplé|
|ils/elles|ils/elles s’appellent|il sapél / el sapél|

---

## 📛 Nome e Sobrenome

|Termo|Significado|
|---|---|
|le prénom|primeiro nome|
|le nom|sobrenome|
|le nom de famille|sobrenome de família|

### Perguntar o Nome

- **Comment vous appelez-vous ?** → Como o senhor(a) se chama? (formal)
    
- **Vous vous appelez comment ?** → Como o senhor(a) se chama? (formal)
    
- **Comment tu t’appelles ?** → Como você se chama? (informal)
    

### Responder

- **Je m’appelle Taís.** → Eu me chamo Taís.
    
- **Et vous ?** → E o senhor(a)?
    
- **Et toi ?** → E você?
    

---

## 🔑 Palavras Úteis

|Francês|Português|
|---|---|
|pardon|desculpe|
|désolé(e)|sinto muito|
|excusez-moi|com licença|
|s’il vous plaît|por favor (formal)|
|s’il te plaît|por favor (informal)|

---

## ✅ Resumo Final

- Diferença entre **formal (vous)** e **informal (tu)**.
    
- Saudações: **Bonjour, Salut, Coucou, Bonsoir**.
    
- Despedidas: **Au revoir, Bonne journée, À demain, Bisous, Tchao**.
    
- Como agradecer e responder.
    
- Como pedir desculpas em diferentes situações.
    
- Conjugação do verbo **s’appeler**.
    
- Diferença entre **prénom** (nome) e **nom** (sobrenome).
