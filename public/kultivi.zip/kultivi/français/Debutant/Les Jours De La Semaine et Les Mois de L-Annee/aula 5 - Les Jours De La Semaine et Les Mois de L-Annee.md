---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Les Jours de la Semaine et Les Mois de L'Année | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/zKSIaDPIsWg?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Dias, Meses e Frequência (Jours, Mois et Fréquence)

---

### 🎯 Visão Geral da Aula

Esta aula aborda vocabulário essencial para a organização do tempo em francês: **Os Dias da Semana (_Les Jours de la Semaine_)** e **Os Meses do Ano (_Les Mois de l'Année_)**. Além da simples memorização, o foco está em como usar esse vocabulário na prática para expressar **frequência** e se referir a **períodos específicos** (início, meio e fim) para descrever eventos e atividades. A aula enfatiza que o aprendizado de um idioma, como o francês, depende fundamentalmente do **contato constante** com a língua.

### [[aula5.pdf]]

---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## Les Jours et Les Mois (Dias e Meses)

Aprender os dias e meses é crucial para marcar compromissos, falar sobre datas de nascimento e expressar a rotina.

### Dias da Semana (_Les Jours de la Semaine_)

Todos os dias da semana em francês são **substantivos masculinos** e, diferentemente do português, **não são escritos com letra maiúscula** (exceto no início de frase).

|Dia|Francês|Observação|
|---|---|---|
|Segunda|**Lundi**||
|Terça|**Mardi**||
|Quarta|**Mercredi**||
|Quinta|**Jeudi**||
|Sexta|**Vendredi**||
|Sábado|**Samedi**||
|Domingo|**Dimanche**||
|**Fim de Semana**|**Le weekend**|Palavra de origem inglesa.|

**Adição de Informação:** Para se referir a todos os dias da semana (exemplo: "Todos os domingos"), basta usar o artigo definido **le** antes do dia (exemplo: _Je vais au parc **le dimanche**_ - "Eu vou ao parque todo domingo").

### Meses do Ano (_Les Mois de l'Année_)

Os meses em francês também são **substantivos masculinos** e **não são escritos com letra maiúscula**.

|Mês|Francês|
|---|---|
|Janeiro|**Janvier**|
|Fevereiro|**Février**|
|Março|**Mars**|
|Abril|**Avril**|
|Maio|**Mai**|
|Junho|**Juin**|
|Julho|**Juillet**|
|Agosto|**Août**|
|Setembro|**Septembre**|
|Outubro|**Octobre**|
|Novembro|**Novembre**|
|Dezembro|**Décembre**|

Uso Prático: Para perguntar o mês de nascimento: Quel est votre mois de naissance ? (Formal).

A resposta é dada geralmente com a preposição en: Je suis né(e) en [Mês]. (Eu nasci em [Mês]).

## Expressando Frequência e Períodos

A aula introduz a necessidade de expressar a frequência de ações e períodos do tempo.

### Frequência e Periodicidade

|Expressão|Francês|Significado|Exemplo|
|---|---|---|---|
|**Todo/Toda**|**Tout(e)** / **Tous** / **Toutes**|Frequência diária/semanal.|_Tous les jours_ (Todos os dias).|
|**Cada**|**Chaque**|Refere-se a cada item individualmente.|**_Chaque_** _territoire a sa culture._ (Cada território tem sua cultura.)|

### Referência a Períodos

É comum usar vocabulário para especificar o começo, meio ou fim de um período (mês, ano, dia, etc.).

|Período|Francês|Significado|
|---|---|---|
|**Início**|**Le début de...**|O começo de (ex: _le début du mois_).|
|**Meio**|**Le milieu de...**|O meio de (ex: _le milieu de l'année_).|
|**Fim**|**La fin de...**|O fim de (ex: _la fin de la semaine_).|

**Exemplo na Aula:**

- _Le **début** d'un **mois**:_ O começo de um mês.
    
- _La **fin** de la **semaine**:_ O fim da semana.
    

## 🎧 Imersão e Contato

A chave de ouro da aula é o conselho sobre o aprendizado de línguas:

> "Aprender uma língua é ter **contato constante** com ela."

|Sugestão|Ação Recomendada|Benefício|
|---|---|---|
|**Rádio/Áudio**|Ouvir rádio francês (ex: **France Inter**).|Acostumar o ouvido ao sotaque e velocidade.|
|**Vídeos/Filmes**|Assistir filmes ou vídeos em francês.|Conectar o áudio com o contexto visual.|
|**Leitura**|Ler notícias e textos simples.|Aumentar vocabulário e familiaridade com a escrita.|

---

## 📚 Tópicos Gramaticais Chave

### Substantivos (_Les Noms_)

|Palavra|Significado (PT-BR)|Categoria|Observação|
|---|---|---|---|
|**Le jour**|O dia|Masculino|Usado para os dias da semana.|
|**Le mois**|O mês|Masculino||
|**Le weekend**|O fim de semana|Masculino||
|**La matinée**|A manhã|Feminino|_Bonne matinée!_|
|**La nuit**|A noite|Feminino||

### Adjetivos (_Les Adjectifs_)

|Palavra|Significado (PT-BR)|Aplicação no Contexto|
|---|---|---|
|**important(e)**|importante|Descrever a relevância do assunto ou atividade.|
|**étranger/étrangère**|estrangeiro(a)|Descrever a língua (_une langue étrangère_).|

### Preposições e Conectores (_Les Prépositions et Mots de Liaison_)

|Palavra|Significado (PT-BR)|Função no Contexto|
|---|---|---|
|**en**|em|Usado para indicar meses (_en octobre_, _en décembre_) e anos.|
|**à**|a, em|Indica local ou horário (_à la maison_, _à 5 heures_).|
|**chez**|na casa de|Indica a casa/local de uma pessoa (_chez moi_, _chez elle_).|
|**de**|de|Indica posse ou origem (_les jours **de** la semaine_).|