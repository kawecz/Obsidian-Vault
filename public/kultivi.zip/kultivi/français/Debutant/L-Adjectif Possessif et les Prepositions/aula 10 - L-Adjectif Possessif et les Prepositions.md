---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - L'adjectif Possessif et Les Prépositions | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/B6tQtWr2bGQ?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>


---
## 🇫🇷 Aula de Francês: Adjetivos Possessivos e Preposições de Lugar

---

### 🎯 Visão Geral da Aula

Esta aula de gramática, a décima do curso, abrange dois tópicos fundamentais: **Adjetivos Possessivos (_Adjectifs Possessifs_)** e as principais **Preposições de Lugar (_Prépositions de Lieu_)**. Os adjetivos possessivos variam em gênero e número de acordo com o objeto possuído. As preposições de lugar são essenciais para indicar a localização de algo ou alguém no espaço.

### [[aula10.pdf]]
---

### 📝 Conteúdo Organizado em Formato Obsidian (Markdown)

## 👑 Adjetivos Possessivos (_Les Adjectifs Possessifs_)

Os adjetivos possessivos concordam em **gênero (masculino/feminino)** e **número (singular/plural)** com o **substantivo que é possuído**, e não com o possuidor.

|Pronome Pessoal|Masc. Singular|Fem. Singular|Plural (Masc. e Fem.)|
|---|---|---|---|
|**Je** (Eu)|**Mon**|**Ma**|**Mes**|
|**Tu** (Tu/Você)|**Ton**|**Ta**|**Tes**|
|**Il/Elle/On** (Ele/Ela/A gente)|**Son**|**Sa**|**Ses**|
|**Nous** (Nós)|**Notre**|**Notre**|**Nos**|
|**Vous** (Vós/Vocês)|**Votre**|**Votre**|**Vos**|
|**Ils/Elles** (Eles/Elas)|**Leur**|**Leur**|**Leurs**|

**Regra de Ouro (Exceção de Pronúncia):**

- Se um substantivo **feminino singular** começar com **vogal** ou **'h' mudo**, usa-se a forma **masculina** do possessivo (_mon_, _ton_, _son_) para evitar um encontro de vogais de pronúncia desagradável.
    
    - Ex: _Mon amie_ (Minha amiga), _Son école_ (A escola dele/dela).
        

|Exemplo com Gênero|Exemplo com Número|
|---|---|
|_Mon **voiture**_ (Meu carro, **masculino**)|_Mes **voitures**_ (Meus carros, **plural**)|
|_Ma **maison**_ (Minha casa, **feminino**)|_Nos **maisons**_ (Nossas casas, **plural**)|

## 🌎 Preposições de País (_Les Prépositions de Pays_)

O uso de preposições antes de nomes de países depende do gênero do país e da sua letra inicial. Estas preposições significam "em", "no", "na", "nos", "nas".

|Gênero do País|Preposição|Exemplo|
|---|---|---|
|**Feminino** ou **Começa por Vogal**|**En**|_En France_ (Na França), _En Italie_ (Na Itália)|
|**Masculino Singular**|**Au**|_Au Brésil_ (No Brasil), _Au Canada_ (No Canadá)|
|**Plural**|**Aux**|_Aux États-Unis_ (Nos Estados Unidos), _Aux Pays-Bas_ (Nos Países Baixos)|

## 📍 Preposições de Lugar (_Les Prépositions de Lieu_)

Estas preposições são usadas para indicar a posição de um objeto ou pessoa em relação a outro. Muitas delas exigem a preposição **de** após o advérbio, que pode levar a um artigo contraído (Du, De la, Des).

|Preposição|Tradução (PT-BR)|Exemplo de Uso|
|---|---|---|
|**À gauche de**|À esquerda de|_À gauche de la table._|
|**À droite de**|À direita de|_À droite du musée._|
|**Devant**|Em frente de|_Devant la porte._|
|**Derrière**|Atrás de|_Derrière le mur._|
|**Près de / À côté de**|Perto de / Ao lado de|_Près de l'ordinateur._|
|**Sous**|Embaixo de|_Sous la chaise._|
|**Sur**|Sobre, em cima de|_Sur le bureau._|
|**Dans**|Dentro de|_Dans la boîte._|
|**En face de**|De frente para|_En face du parc._|
|**Entre**|Entre|_Entre la voiture et le vélo._|

**Dicas de Pronúncia:**

- **Sur** (_sobre_) tem a vogal mais fechada (quase um **û** em português).
    
- **Sous** (_embaixo_) tem a vogal mais aberta (como em **sou**).
    
- **Dans** (_dentro_) tem a vogal nasal (_dã_).
    

## 🏙️ Exemplo de Localização (Paris)

|Ponto de Referência|Estrutura|Tradução (PT-BR)|
|---|---|---|
|**Notre Dame**|_Notre Dame est **dans** l'île._|Notre Dame está **na** (dentro da) ilha.|
|**Jardin des Tuileries / Trocadéro**|_Le Jardin est **devant** le Trocadéro._|O Jardim está **em frente** ao Trocadéro.|
|**Arco do Triunfo / Place de la Concorde**|_La Concorde est **à droite de** l'Arc._|A Concorde está **à direita do** Arco.|

Para a prática, comece descrevendo a posição de objetos na sala onde você está, usando os possessivos e as preposições: "Mon livre est sur la table, derrière mon ordinateur."