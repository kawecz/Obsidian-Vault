---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Donner une Explication | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/6TZG7jRQG9o?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>


---
## 🇫🇷 Aula de Francês: Por Que? (Pourquoi?) e Perguntas

---

### 🎯 Visão Geral da Aula

Esta lição se concentra no uso do advérbio interrogativo **"Pourquoi"** (Por que?) e na estrutura das respostas com **"Parce que"** (Porque). O tópico principal é a formação de perguntas para obter explicações (_la cause_) e a conjugação do verbo **"Vouloir"** (Querer), um verbo irregular do Terceiro Grupo, essencial para expressar desejo.

### [[aula13.pdf]]

---

### ❓ Perguntas e Respostas de Causa (_La Cause_)

Em francês, a pergunta sobre a causa (**Por que?**) e a resposta (**Porque...**) são palavras distintas e devem ser usadas em conjunto.

|Função|Palavra em Francês|Pronúncia Aproximada|
|---|---|---|
|**Pergunta** (Por que?)|**Pourquoi?**|_Púrkua_|
|**Resposta** (Porque...)|**Parce que...** (ou _Parce qu'_ antes de vogal)|_Parskâ_|

**Estrutura da Pergunta:**

- **Simples:** _Pourquoi tu aimes le chocolat?_ (Por que você gosta de chocolate?)
    
- **Inversão (Formal):** _Pourquoi aimes-tu le chocolat?_
    

**Estrutura da Resposta:**

- _J'aime le chocolat **parce que** c'est bon._ (Eu gosto de chocolate **porque** é bom.)
    

**Observação:**

- **Car** (Pois, já que) também significa _porque_, mas é usado no **início da segunda frase** para dar uma explicação, e não como resposta direta a _Pourquoi_.
    

## 👑 Verbo Vouloir (Querer)

**Vouloir** é um verbo irregular do Terceiro Grupo e um dos verbos modais mais importantes em francês, usado para expressar desejo ou vontade.

|Pronome|Conjugação|Tradução|Observação|
|---|---|---|---|
|**Je**|**Je veux**|Eu quero|Base VEU|
|**Tu**|**Tu veux**|Tu queres / Você quer|Base VEU|
|**Il/Elle/On**|**Il/Elle veut**|Ele/Ela/A gente quer|Base VEU|
|**Nous**|**Nous voulons**|Nós queremos|Base VOUL|
|**Vous**|**Vous voulez**|Vocês querem|Base VOUL|
|**Ils/Elles**|**Ils/Elles veulent**|Eles/Elas querem|Base VEUL|

**Dica de Uso:**

- O uso de _Vouloir_ é direto e pode soar um pouco abrupto. Para ser mais educado (em um restaurante, por exemplo), usa-se o Condicional: **Je voudrais** (Eu gostaria).
    

## 🌎 Vocabulário: Guiana Francesa (_La Guyane Française_)

A **Guiana Francesa** é um departamento ultramarino da França, mantendo fortes laços com a metrópole.

|Item|Francês|Observação|
|---|---|---|
|**Língua Oficial**|Le français|O francês é a língua oficial.|
|**Moeda**|L'euro|A moeda oficial é o Euro.|
|**Nacionalidade**|Français(e)|Quem nasce lá é de nacionalidade francesa.|
|**Presidente**|Le Président Français|O chefe de Estado é o Presidente da França.|

## 📚 Tópicos Gramaticais Chave

### Pronomes Pessoais e Adjetivos (_Les Pronoms Personnels et Adjectifs_)

|Palavra|Categoria|Significado (PT-BR)|
|---|---|---|
|**Il**|Pronome Pessoal|Ele.|
|**Une passion**|Substantivo|Uma paixão.|
|**Basique**|Adjetivo|Básico.|
|**Régulier/Irrégulier**|Adjetivo|Regular/Irregular.|

### Advérbios (_Les Adverbes_)

|Palavra|Significado (PT-BR)|Função no Contexto|
|---|---|---|
|**Pourquoi**|Por que?|Advérbio interrogativo de causa.|
|**Parce que**|Porque...|Conjunção de resposta (causa).|
|**Aujourd'hui**|Hoje|Advérbio de tempo.|

Para praticar a causa, tente criar uma frase sobre um dos seus gostos usando _Pourquoi_ e _Parce que_:

**Exemplo:** _Pourquoi voulez-vous apprendre le français? Parce que c'est une belle langue._