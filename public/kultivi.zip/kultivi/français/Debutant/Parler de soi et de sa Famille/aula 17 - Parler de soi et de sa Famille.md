---
"banner ": https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - debutant
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Parler de Soi et de Sa Famille | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/-Q7lKnccVo0?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

---
## 🇫🇷 Aula de Francês: Descrevendo a Si Mesmo e a Família (_Parler de Soi et de sa Famille_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #17) é crucial para enriquecer o vocabulário e a comunicação interpessoal, pois foca na **descrição de pessoas**, abordando tanto características físicas quanto psicológicas (_qualités_ e _défauts_). O conteúdo é intensivo em vocabulário e regras de **concordância de gênero e número** dos adjetivos, além de apresentar os membros da família (_la famille_).

### [[aula17.pdf]]
---

### 📝 Estrutura de Descrição Pessoal e Profissional

Para descrever a si mesmo ou a outros, usa-se a estrutura do verbo **Être** (Ser) + Profissão/Adjetivo/Nacionalidade.

|Tema|Estrutura em Francês|Significado (PT-BR)|
|---|---|---|
|**Profissão**|**Je suis avocate.**|Eu sou advogada.|
|**Nacionalidade**|**Je suis brésilien.**|Eu sou brasileiro.|
|**Gostos/Paixões**|**Mes passions sont lire et danser.**|Minhas paixões são ler e dançar.|
|**Medos**|**J'ai peur de rien.**|Eu não tenho medo de nada.|

---

### 🏡 Membros da Família (_Les Membres de la Famille_)

|Relação|Francês (Singular)|Observação|
|---|---|---|
|**Pais**|**Les parents**|Cuidado: Não significa "parentes". Parente é **relatif/relative**.|
|**Avós**|**Les grands-parents**||
|Avô / Avó|**Le grand-père / La grand-mère**||
|**Pais**|**Le père / La mère**||
|Tio / Tia|**L'oncle / La tante**||
|Primo / Prima|**Le cousin / La cousine**||
|**Irmão / Irmã**|**Le frère / La sœur**|O ditongo **œu** em _sœur_ é a grafia correta.|
|**Filhos (em geral)**|**Les enfants**||
|Filho / Filha|**Le fils / La fille**|_Fille_ também significa "menina".|
|**Netos**|**Les petits-enfants**||
|Neto / Neta|**Le petit-fils / La petite-fille**|Uso obrigatório do hífen **(-)**: _Petit-fils_ (Neto), _petit fils_ (filho pequeno).|
|**Padrasto / Sogro**|**Le beau-père**|A palavra é a mesma, o contexto define a relação.|
|**Madrasta / Sogra**|**La belle-mère**|A palavra é a mesma.|
|**Cunhado / Cunhada**|**Le beau-frère / La belle-sœur**||

---

### 🌟 Adjetivos Qualificativos e Regras de Concordância

Os adjetivos em francês **concordam** em gênero (masculino/feminino) e número (singular/plural) com o substantivo que descrevem.

#### 1. Adjetivos Regulares (Adição de -e e -s)

A maioria dos adjetivos femininos é formada pela adição de **-e** ao masculino singular. O plural é formado pela adição de **-s**.

|Qualidade|Masc. Sing.|Fem. Sing.|Masc. Plural|Fem. Plural|
|---|---|---|---|---|
|**Paciente**|**Patient**|**Patiente**|**Patients**|**Patientes**|
|**Organizado**|**Organisé**|**Organisée**|**Organisés**|**Organisées**|
|**Superficial**|**Superficiel**|**Superficielle**|**Superficiels**|**Superficielles**|
|**Complicado**|**Compliqué**|**Compliquée**|**Compliqués**|**Compliquées**|
|**Gentil**|**Gentil**|**Gentille**|**Gentils**|**Gentilles**|
|**Responsável**|**Responsable**|**Responsable**|**Responsables**|**Responsables**|
|**Otimista**|**Optimiste**|**Optimiste**|**Optimistes**|**Optimistes**|

**Regra:** Adjetivos terminados em **-e** no masculino singular (_responsable, optimiste_) não mudam no feminino.

#### 2. Adjetivos Irregulares (Mudança na Terminação)

|Qualidade|Masc. Sing.|Fem. Sing.|Masc. Plural|Fem. Plural|Observação|
|---|---|---|---|---|---|
|**Mentiroso**|**Menteur**|**Menteuse**|**Menteurs**|**Menteuses**|**-eur** vira **-euse**.|
|**Bom**|**Bon**|**Bonne**|**Bons**|**Bonnes**|Duplicação do **n** no feminino.|
|**Bonito**|**Beau**|**Belle**|**Beaux**|**Belles**|**-eau** no plural vira **-eaux** (geralmente). **-eau** vira **-elle** no feminino.|
|**Sério**|**Sérieux**|**Sérieuse**|**Sérieux**|**Sérieuses**|Adjetivos terminados em **-x** são inalterados no plural masculino e trocam o **-x** por **-se** no feminino.|

---

### 🛠️ Vocabulário de Qualidades e Defeitos (Com Sinônimos)

|Qualidade/Defeito|Francês|Sinônimo (Francês)|
|---|---|---|
|**Tímido**|**Timide**|_Ne communique pas facilement._ (Não se comunica facilmente.)|
|**Generoso**|**Généreux**|_Donne beaucoup aux autres._ (Dá muito aos outros.)|
|**Sério**|**Sérieux**|_Ne rit pas souvent._ (Não ri frequentemente.)|
|**Curioso**|**Curieux**|_Aime savoir ce qui se passe._ (Gosta de saber o que acontece.)|
|**Fiel**|**Fidèle**|_Reste avec la même personne._ (Permanece com a mesma pessoa.)|
|**Mandão**|**Autoritaire**|_Aime décider de tout._ (Gosta de decidir tudo.)|

---

### 🗣️ Estruturas de Frases e Expressões

|Expressão|Significado (PT-BR)|
|---|---|
|**Détester quelqu'un/quelque chose**|Detestar alguém/algo.|
|**S'intéresser à...**|Interessar-se por... (Verbo pronominal).|
|**Regarder des films**|Assistir a filmes.|
|**Le feuilleton**|A novela.|
|**Parler des voyages**|Falar sobre viagens.|

---

### 📝 Devoir (Lição de Casa)

**Pratique a Descrição de Sua Família:**

1. Escolha pelo menos três membros da sua família (ou amigos).
    
2. Descreva-os em francês, utilizando o verbo **Être** (estar/ser) e os novos adjetivos desta aula, atentando-se à **concordância** de gênero e número.
    
3. Inclua as paixões e atividades deles, utilizando os verbos de movimento e as expressões de gosto (_aimer, adorer_).
    

**Exemplo:** _Ma mère est très **patiente** et **organisée**. Mon oncle est **sérieux** mais aussi **généreux**._ (Minha mãe é muito **paciente** e **organizada**. Meu tio é **sério**, mas também **generoso**.)