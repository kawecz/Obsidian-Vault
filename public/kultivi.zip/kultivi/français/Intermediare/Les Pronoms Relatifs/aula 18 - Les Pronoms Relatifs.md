---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Les Pronoms Relatifs: Que X Qui | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/CT1TZC85wZQ?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: O Pronome Relativo `Que`

**Visão Geral:** Esta aula explora o uso do pronome relativo `que`, um elemento fundamental para conectar ideias e evitar repetições, tornando a frase mais coesa e elegante. Ele pode funcionar como sujeito ou objeto direto na oração subordinada.

### [[aula18.pdf]]

---
### 1. O Que é o Pronome Relativo `Que`?
O `que` é um pronome relativo invariável (não muda em gênero ou número). Sua principal função é substituir um termo da oração principal (o antecedente) e introduzir uma oração subordinada que fornece mais informações sobre esse termo.

- **Exemplo Básico:** `J'ai lu le livre. + Le livre est sur la table.`
- **Com `que`:** `J'ai lu le livre **qui** est sur la table.` (Eu li o livro **que** está sobre a mesa.)

### 2. As Funções do `Que`

#### 2.1. `Que` como Sujeito
Quando `que` exerce a função de **sujeito** do verbo que o segue, ele **não pode ser omitido**.

- **Antecedente:** Pessoas ou Coisas.
- **Exemplo:**
    - `La femme **que** danse est ma sœur.` (A mulher **que** dança é minha irmã.)
    - `Le film **que** passe à la télé est bon.` (O filme **que** passa na TV é bom.)

#### 2.2. `Que` como Objeto Direto (COD)
Quando `que` exerce a função de **objeto direto** do verbo que o segue, ele também **não pode ser omitido**. O verbo da oração relativa concorda com o sujeito dela, não com o `que`.

- **Antecedente:** Pessoas ou Coisas.
- **Exemplo:**
    - `Le livre **que** je lis est passionnant.` (O livro **que** eu leio é fascinante.)
    - `Les amis **que** j'invite arrivent demain.` (Os amigos **que** eu convido chegam amanhã.)

### 3. `Que` vs. `Qui` - A Diferença Crucial
É essencial não confundir `que` com `qui`. Ambos são pronomes relativos, mas com funções diferentes.

| Pronome | Função na Oração Subordinada                  | Exemplo (Francês)                          | Tradução (Português)                 |
| ------- | --------------------------------------------- | ------------------------------------------ | ------------------------------------ |
| **QUI** | Atua como **SUJEITO** do verbo que o segue.   | `La femme **qui** parle.`                  | A mulher **que** fala.               |
| **QUE** | Atua como **OBJETO DIRETO (COD)** do verbo que o segue. | `Le livre **que** je lis.`                 | O livro **que** eu leio.             |
| **QUE** | (Menos comum) Atua como **SUJEITO** (geralmente com verbo `être`). | `Le livre **que** est sur la table.` (Mais comum: `qui est`) | O livro **que** está sobre a mesa.   |

### 4. Dica Prática: Como Identificar a Função
Para saber se usa `qui` ou `que`, faça a pergunta após o antecedente:

1.  **Para `QUI` (Sujeito):** O verbo que se segue já tem um sujeito? **NÃO**.
    - `La femme [sujeito?] parle.` → `La femme **qui** parle.`

2.  **Para `QUE` (Objeto Direto):** O verbo que se segue já tem um sujeito? **SIM**.
    - `Le livre [sujeito?] je lis.` → `Le livre **que** je lis.`

### 5. Exercícios Práticos

1.  **Complete com `qui` ou `que`:**
    - `La maison ____ j'habite est grande.`
    - *`que`* (A casa **que** eu habito é grande. - COD de "j'habite")
    - `L'homme ____ sonne à la porte est le facteur.`
    - *`qui`* (O homem **que** toca a porta é o carteiro. - Sujeito de "sonne")

2.  **Reescreva as frases usando `que`:**
    - `J'ai acheté des fruits. Ils sont sur la table.`
    - *`J'ai acheté des fruits **qui** sont sur la table.`* (Atenção: aqui é `qui` pois é sujeito de "sont".)
    - `Je regarde le film. Tu m'as recommandé le film.`
    - *`Je regarde le film **que** tu m'as recommandé.`* (`que` é COD de "as recommandé")

**Dica Final:** A leitura é a melhor maneira de internalizar o uso de `que` e `qui`. Leia textos em francês (notícias, contos) e preste atenção a como esses pronomes são usados. Pratique reescrevendo frases simples, combinando-as com `que`. A exposição constante ao idioma fará com que o uso correto se torne natural.