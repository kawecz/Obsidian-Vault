---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Les Verbes Cod Et Coi | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/K8TjxU5Mp5U?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Os Pronomes de Objeto Direto e Indireto

**Visão Geral:** Esta aula aborda um dos pilares da gramática francesa: os pronomes de objeto direto (COD) e indireto (COI). Entender sua função e colocação é essencial para construir frases corretas e evitar repetições, tornando a fala mais fluida.

### [[aula16.pdf]]

---
### 1. O que são Objetos Direto e Indireto?
- **Objeto Direto (COD):** Responde às perguntas "QUEM?" ou "QUE?". É o complemento que se liga **diretamente** ao verbo, sem preposição.
- **Objeto Indireto (COI):** Responde às perguntas "A QUEM?", "DE QUEM?", "PARA QUEM?". É o complemento que se liga ao verbo **através de uma preposição** (como `à`, `de`).

### 2. Tabela de Pronomes Pessoais

| Pessoa   | Pronome Sujeito | Pronome Objeto Direto (COD) | Pronome Objeto Indireto (COI) |
| -------- | --------------- | --------------------------- | ----------------------------- |
| 1ª (Eu)  | Je              | **me** (m')                 | **me** (m')                   |
| 2ª (Tu)  | Tu              | **te** (t')                 | **te** (t')                   |
| 3ª (Ele) | Il              | **le** (l')                 | **lui**                       |
| 3ª (Ela) | Elle            | **la** (l')                 | **lui**                       |
| 1ª (Nós) | Nous            | **nous**                    | **nous**                      |
| 2ª (Vós) | Vous            | **vous**                    | **vous**                      |
| 3ª (Eles/Elas) | Ils/Elles   | **les**                     | **leur**                      |

### 3. Como Identificar o Objeto na Frase

#### 3.1. Objeto Direto (COD)
- Pergunte: "O verbo + QUEM? / QUE?"
- **Exemplo:** `Je mange **une pomme**.` (Eu como **uma maçã**.)
    - Pergunta: Como **o quê**? → **Uma maçã** (COD).
    - Com pronome: `Je **la** mange.` (Eu **a** como.)

#### 3.2. Objeto Indireto (COI)
- Pergunte: "O verbo + **A** QUEM? / **DE** QUEM?"
- **Exemplo:** `Je téléphone **à ma mère**.` (Eu telefono **para a minha mãe**.)
    - Pergunta: Telefono **a quem**? → **À minha mãe** (COI).
    - Com pronome: `Je **lui** téléphone.` (Eu **lhe** telefono.)

### 4. Colocação dos Pronomes na Frase
Os pronomes COD e COI vêm **antes** do verbo, na seguinte ordem:

1.  **me, te, se, nous, vous**
2.  **le, la, les**
3.  **lui, leur**
4.  **y**
5.  **en**

**Exemplos:**
- `Je **te le** donne.` (Eu **to** dou.) - `te` (COI) + `le` (COD)
- `Il **nous la** présente.` (Ele **no-la** apresenta.) - `nous` (COI) + `la` (COD)

### 5. Verbos com Construção Direta e Indireta
Alguns verbos podem ter **dois complementos** ao mesmo tempo.

| Verbo     | Construção (Português) | Exemplo (Francês)                     | Tradução                     |
| --------- | ---------------------- | ------------------------------------- | ---------------------------- |
| **Donner** (Dar) | Dar **algo** **a alguém** | `Je donne **le livre** **à Paul**.`   | Dou **o livro** **ao Paulo**. |
|           |                        | `Je **le lui** donne.`                | Eu **lho** dou.              |
| **Dire** (Dizer) | Dizer **algo** **a alguém** | `Il dit **la vérité** **à son ami**.` | Ele diz **a verdade** **ao seu amigo**. |
|           |                        | `Il **la lui** dit.`                  | Ele **lha** diz.             |

### 6. Exercícios Práticos

1.  **Substitua o objeto destacado pelo pronome correto:**
    - `Je cherche **mes clés**.` (COD)
    - *`Je **les** cherche.`*
    - `Elle parle **à son professeur**.` (COI)
    - *`Elle **lui** parle.`*

2.  **Reescreva a frase usando os pronomes:**
    - `J'achète **des fleurs** **pour ma mère**.` (Comprar algo para alguém)
    - *`Je **lui en** achète.`* (`lui` = para ela, `en` = delas - flores)

3.  **Identifique se o objeto é direto (COD) ou indireto (COI):**
    - `Il écoute **de la musique**.`
    - *COD (Escutar **o quê**? → música)*
    - `Nous obéissons **à la loi**.`
    - *COI (Obedecemos **a quê**? → à lei)*

**Dica Final:** A prática é fundamental. Tente pegar frases simples e substituir os complementos por pronomes. Preste atenção aos verbos mais comuns (`donner`, `dire`, `parler`, `téléphoner`, `demander`) e em como eles se constroem. Revisite esta aula quantas vezes forem necessárias.