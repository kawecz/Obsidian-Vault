---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Perceptions et Sentiments | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/BrcjaT3ybzQ?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>


---
> [!abstract] Percepções e Sentimentos: Os Cinco Sentidos e Emoções
> Esta aula explora o vocabulário relacionado aos cinco sentidos e aos sentimentos em francês. Aprenderemos os verbos específicos para cada percepção sensorial (ver, ouvir, sentir, etc.) e como expressar emoções como alegria, tristeza e cansaço, incluindo a conjugação de verbos essenciais.

### [[aula5.pdf]]

---

### 📘 Tópicos da Aula
1.  Os Cinco Sentidos e Seus Verbos
2.  Expressando Sensações Físicas (Frio, Calor, Sono)
3.  Vocabulário de Sentimentos e Emoções
4.  Conjugação de Verbos Relacionados

### 📖 Conteúdo Detalhado

#### Os Cinco Sentidos (Les cinq sens)

| Sentido | Verbo em Francês | Pronúncia Aproximada | Exemplo de Uso |
| :--- | :--- | :--- | :--- |
| A Visão | **Voir** | (vuár) | Je **vois** un tableau. (Eu **vejo** um quadro.) |
| A Audição | **Entendre** | (ãtãdr) | J'**entends** un bruit. (Eu **ouço** um barulho.) |
| O Olfato | **Sentir** | (sãtir) | Je **sens** un parfum. (Eu **sinto** um perfume.) |
| O Paladar | **Goûter** | (gutê) | Je **goûte** le chocolat. (Eu **provo** o chocolate.) |
| O Tato | **Toucher** | (tuchê) | Je **touche** la table. (Eu **toco** a mesa.) |

**Observação:** `Écouter` (escutar) é usado quando se presta atenção a um som, enquanto `entendre` (ouvir) refere-se à percepção passiva do som.

#### Expressando Sensações Físicas

Para expressar sensações como frio, calor ou sono, usa-se a estrutura **`Avoir + [substantivo]`**.

| Sensação | Expressão em Francês | Tradução Literal | Significado |
| :--- | :--- | :--- | :--- |
| Frio | **Avoir froid** | Ter frio | Estar com frio |
| Calor | **Avoir chaud** | Ter calor | Estar com calor |
| Sono | **Avoir sommeil** | Ter sono | Estar com sono |
| Fome | **Avoir faim** | Ter fome | Estar com fome |
| Sede | **Avoir soif** | Ter sede | Estar com sede |
| Medo | **Avoir peur** | Ter medo | Estar com medo |

**Exemplos:**
*   `J'ai froid.` (Estou com frio.)
*   `Elle a sommeil.` (Ela está com sono.)
*   `Nous avons faim.` (Nós estamos com fome.)

#### Vocabulário de Sentimentos e Emoções

| Sentimento (Masculino) | Sentimento (Feminino) | Tradução |
| :--- | :--- | :--- |
| **Heureux** | **Heureuse** | Feliz / Contente |
| **Triste** | **Triste** | Triste |
| **Fatigué** | **Fatiguée** | Cansado / Cansada |
| **En colère** | **En colère** | Com raiva |
| **Étonné** | **Étonnée** | Surpreso / Surpresa |
| **Déçu** | **Déçue** | Decepcionado / Decepcionada |

**Verbos Relacionados a Emoções:**
*   **Sourire** (Sorrir) - Je **souris**, tu **souris**, il/elle **sourit**, nous **sourions**, vous **souriez**, ils/elles **sourient**.
*   **Rire** (Rir) - Je **ris**, tu **ris**, il/elle **rit**, nous **rions**, vous **riez**, ils/elles **rient**.
*   **Pleurer** (Chorar) - Je **pleure**, tu **pleures**, il/elle **pleure**, nous **pleurons**, vous **pleurez**, ils/elles **pleurent**.

#### Dica de Prática
Pratique no seu dia a dia. Ao sentir um cheiro, pense "Je sens...". Ao ouvir uma música, pense "J'entends...". Associe as sensações e emoções que você experiencia às palavras em francês para fixá-las naturalmente.

### 📚 Categorização de Palavras-Chave

#### Verbos dos Sentidos
*   **Voir** (ver)
*   **Entendre** (ouvir)
*   **Sentir** (sentir, cheirar)
*   **Goûter** (provar)
*   **Toucher** (tocar)

#### Substantivos para Sensações
*   **Le froid** (o frio)
*   **Le chaud** (o calor)
*   **Le sommeil** (o sono)
*   **La faim** (a fome)
*   **La soif** (a sede)
*   **La peur** (o medo)

#### Adjetivos para Sentimentos
*   **Heureux / Heureuse** (feliz)
*   **Triste** (triste)
*   **Fatigué(e)** (cansado/a)
*   **En colère** (com raiva)