---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Parties du Corps | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/9FQPS9Ndfpg?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>


---

> [!abstract] Partes do Corpo e Expressões com "Avoir Mal"
> Esta aula apresenta o vocabulário das principais partes do corpo em francês, com foco na pronúncia e na escrita. Além disso, ensina a estrutura essencial "avoir mal à/au" para expressar dores físicas, uma construção muito comum no dia a dia.

### [[aula3.pdf]]

---

### 📘 Tópicos da Aula
1.  Vocabulário das Partes do Corpo
2.  A Estrutura `Avoir mal à/au` (Expressar Dores)
3.  Dicas de Pronúncia e Prática

### 📖 Conteúdo Detalhado

#### Partes do Corpo (Parties du Corps)

| Parte do Corpo em Francês | Pronúncia Aproximada | Tradução para Português |
| :--- | :--- | :--- |
| **La tête** | (la tét) | a cabeça |
| **Le visage** | (le visáj) | o rosto |
| **Les cheveux** | (lê shevô) | o cabelo |
| **Les yeux** | (lêz iô) | os olhos |
| **Le nez** | (le nê) | o nariz |
| **La bouche** | (la buch) | a boca |
| **Les dents** | (lê dã) | os dentes |
| **La langue** | (la lãg) | a língua |
| **Le cou** | (le cu) | o pescoço |
| **L'épaule** (f.) | (lepól) | o ombro |
| **Le bras** | (le bra) | o braço |
| **Le coude** | (le cud) | o cotovelo |
| **La main** | (la mã) | a mão |
| **Les doigts** | (lê duá) | os dedos (da mão) |
| **Le ventre** | (le vãtr) | a barriga |
| **Le dos** | (le dô) | as costas |
| **La jambe** | (la jãb) | a perna |
| **Le genou** | (le jenú) | o joelho |
| **La cheville** | (la shevíe) | o tornozelo |
| **Le pied** | (le pié) | o pé |
| **Les orteils** | (lêz ortêi) | os dedos do pé |

#### Como Expressar Dores (`Avoir mal`)

Para dizer que está com dor em alguma parte do corpo, usa-se a estrutura **`Avoir mal + à/au`**.

| Estrutura | Uso | Exemplo em Francês | Tradução |
| :--- | :--- | :--- | :--- |
| **Avoir mal à + [parte feminina]** | Parte do corpo no feminino singular. | J'ai **mal à la tête**. | Estou com **dor de cabeça**. |
| **Avoir mal au + [parte masculina]** | Parte do corpo no masculino singular. | J'ai **mal au ventre**. | Estou com **dor de barriga**. |
| **Avoir mal aux + [parte no plural]** | Parte do corpo no plural (masculino ou feminino). | J'ai **mal aux jambes**. | Estou com **dor nas pernas**. |

**Exemplos Adicionais:**
*   `Il a mal au dos.` (Ele está com dor nas costas.)
*   `Nous avons mal aux dents.` (Nós estamos com dor de dente.)
*   `Je ne peux pas faire du sport, j'ai mal au genou.` (Não posso praticar esportes, estou com dor no joelho.)

### 📚 Categorização de Palavras-Chave

#### Substantivos (Partes do Corpo)
*   **La tête** (a cabeça)
*   **Le visage** (o rosto)
*   **Le ventre** (a barriga)
*   **Le dos** (as costas)
*   **La jambe** (a perna)
*   **Le bras** (o braço)
*   **La main** (a mão)
*   **Le pied** (o pé)

#### Verbo e Expressão
*   **Avoir mal** (estar com dor)
*   **Avoir** (ter)

#### Preposições e Artigos Contratados
*   **À** + **le** = **au**
*   **À** + **les** = **aux**
*   **À la** (não contrai)

#### Dica de Prática
Para memorizar, assista a vídeos de exercícios físicos em francês no YouTube. O instrutor dará comandos como "levez le bras" (levantem o braço) ou "pliez les genoux" (dobrem os joelhos), o que ajuda a associar a palavra à ação.