---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Le Pronom Y | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/KsQNIzYdhMw?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Os Pronomes `Y` e `EN`

**Visão Geral:** Esta aula foca nos pronomes adverbiais `y` e `en`, essenciais para evitar repetições e tornar a fala mais fluida. Eles substituem elementos introduzidos por preposições e são muito frequentes no francês cotidiano.

### [[aula17.pdf]]

---
### 1. O Pronome `Y`

#### 1.1. Uso Principal: Substituir um Lugar
Substitui um complemento de lugar introduzido por preposições como `à`, `chez`, `dans`, `en`, `sur`.

- **Exemplo:** `Je vais **à Paris**.` → `J'**y** vais.`
- (Eu vou **a Paris**.) → (Eu **lá** vou.)

#### 1.2. Outros Usos
Substitui um complemento introduzido por `à` que não seja de pessoa.

- **Exemplo:** `Je pense **à mon travail**.` → `J'**y** pense.`
- (Eu penso **no meu trabalho**.) → (Eu **nele** penso.)

### 2. O Pronome `EN`

#### 2.1. Uso Principal: Substituir uma Quantidade
Substitui um complemento introduzido por `de` (parte de um todo, quantidade indeterminada).

- **Exemplo:** `Je veux **du pain**.` → `J'**en** veux.`
- (Eu quero **pão**.) → (Eu **disso** quero.)

#### 2.2. Substituir `de + Lugar`
- **Exemplo:** `Je viens **de France**.` → `J'**en** viens.`
- (Eu venho **da França**.) → (Eu **de lá** venho.)

#### 2.3. Substituir `de + Coisa` em Expressões Verbais
- **Exemplo:** `Je parle **de mes vacances**.` → `J'**en** parle.`
- (Eu falo **das minhas férias**.) → (Eu **delas** falo.)

### 3. Colocação na Frase
`Y` e `EN` seguem a mesma regra de colocação dos outros pronomes, antes do verbo.

**Ordem de Colocação dos Pronomes:**
1.  **me, te, se, nous, vous**
2.  **le, la, les**
3.  **lui, leur**
4.  **y**
5.  **en**

**Exemplos:**
- `Je **vous y** emmène.` (Eu **vos levo lá**.)
- `Il **nous en** donne.` (Ele **no-los dá**.)

### 4. Tabela de Resumo

| Pronome | Substitui...                     | Preposição Chave | Exemplo (Antes/Depois)                     |
| ------- | -------------------------------- | ---------------- | ------------------------------------------ |
| **Y**   | Um **lugar** ou uma **coisa** (não-pessoa) | `à`, `chez`, `en`... | `Je vais **au marché**.` → `J'**y** vais.` |
| **EN**  | Uma **quantidade** ou uma **coisa** introduzida por `de` | `de`, `du`, `des`... | `Il a **des sœurs**.` → `Il **en** a.`     |
### 5. Exercícios Práticos

1.  **Substitua o elemento destacado por `y` ou `en`:**
    - `Elle rêve **de ses prochaines vacances**.`
    - *`Elle **en** rêve.`* (Ela sonha com elas.)
    - `Nous habitons **dans cette maison**.`
    - *`Nous **y** habitons.`* (Nós moramos nela.)

2.  **Reescreva a frase usando `y` e `en` juntos:**
    - `Tu penses **à ton travail** et tu parles **de ton travail** toute la journée.`
    - *`Tu **y** penses et tu **en** parles toute la journée.`*
    - (Tu pensas **nele** e falas **dele** o dia todo.)

3.  **Complete com `y` ou `en`:**
    - `- Tu as des frères ? - Oui, j'____ ai deux.`
    - *`en`* (Resposta: Sim, eu tenho dois.)
    - `- Tu vas à la piscine ? - Oui, j'____ vais.`
    - *`y`* (Resposta: Sim, eu vou lá.)

**Dica Final:** A prática constante é a chave. Tente reescrever frases simples do seu dia a dia, substituindo os complementos por `y` e `en`. Preste atenção aos verbos que comumente regem as preposições `à` (ex: `penser à`, `aller à`) e `de` (ex: `parler de`, `avoir besoin de`), pois eles frequentemente pedirão o uso desses pronomes.