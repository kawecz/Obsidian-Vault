---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Passé Composé II | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/plbYMfLDn-s?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: O Passado Composto (Le Passé Composé) - Parte 2

**Visão Geral:** Esta segunda parte aprofunda o passé composé, focando nos detalhes que causam mais confusão: a pronúncia, a formação dos particípios passados e as regras de acordo quando o auxiliar é `Être`.

### [[aula21.pdf]]

---

### 1. Revisão Rápida: Os Dois "Clubes" de Verbos

- **Clube Laranja (Verbos com `Avoir`):** A grande maioria dos verbos. O particípio passado **NÃO** varia.
- **Clube Azul (Verbos com `Être`):** Inclui os 16 verbos de movimento (DR & MRS VANDERTRAMP) e **todos os verbos pronominais** (reflexivos). O particípio passado **CONCORDA** com o sujeito.

### 2. Pronúncia do Auxiliar `Avoir`

É crucial diferenciar a pronúncia para não confundir com outras formas verbais.

| Pronome | Conjugação | Pronúncia Correta | Pronúncia Equivocada |
|---------|------------|-------------------|----------------------|
| J'      | **ai**     | **Jê**            | Jamais "Já" ou "Jé" |
| Tu      | **as**     | **Tü** (som fechado) | - |
| Il/Elle | **a**      | **A**             | - |
| Nous    | **avons**  | **A-von**         | - |
| Vous    | **avez**   | **A-vê**          | - |
| Ils/Elles | **ont**  | **On** (som nasal) | - |

### 3. Formação do Particípio Passado (Foco nos Irregulares)

#### 3.1. Verbos Terminados em `-er` (Regulares)
- Regra: `-er` → `-é`
- Ex: `manger` (comer) → `mangé`

#### 3.2. Verbos Terminados em `-ir` (Regulares)
- Regra: `-ir` → `-i`
- Ex: `finir` (terminar) → `fini`; `dormir` (dormir) → `dormi`

#### 3.3. Verbos Irregulares Comuns (Must-Know)
Estes devem ser memorizados, pois são muito frequentes.

| Verbo (Infinitivo) | Particípio Passado | Exemplo no Passé Composé |
| ------------------ | ------------------ | ------------------------ |
| **Prendre** (tomar/pegar) | **pris** | `J'ai **pris** le train.` (Peguei o trem.) |
| **Lire** (ler) | **lu** | `Tu as **lu** ce livre.` (Leste este livro.) |
| **Écrire** (escrever) | **écrit** | `Il a **écrit** une lettre.` (Ele escreveu uma carta.) |
| **Voir** (ver) | **vu** | `Nous avons **vu** un film.` (Vimos um filme.) |
| **Pouvoir** (poder) | **pu** | `J'ai **pu** le faire.` (Pude fazê-lo.) |
| **Devoir** (dever) | **dû** | `Elle a **dû** partir.` (Ela teve de partir.) |
| **Ouvrir** (abrir) | **ouvert** | `Ils ont **ouvert** la porte.` (Eles abriram a porta.) |
### 4. O Acordo do Particípio Passado com o Auxiliar `Être`

Quando o auxiliar é `Être`, o particípio passado funciona como um adjetivo e deve concordar com o sujeito.

| Sujeito | Acordo | Exemplo (Aller - Ir) |
|---------|--------|----------------------|
| Masculino Singular | Nenhum acréscimo | `Il **est allé**.` (Ele foi.) |
| Feminino Singular | + **e** | `Elle **est allée**.` (Ela foi.) |
| Masculino Plural | + **s** | `Ils **sont allés**.` (Eles foram.) |
| Feminino Plural | + **es** | `Elles **sont allées**.` (Elas foram.) |

**Exemplos com outros verbos:**
- `Je **suis arrivé(e)**.` (Eu cheguei.)
- `Nous **sommes parti(e)s**.` (Nós partimos.)
- `Elles **sont venues**.` (Elas vieram.)

### 5. A Posição dos Pronomes na Negação

A estrutura da negação `ne...pas` (não) envolve o verbo conjugado. No passé composé, o verbo conjugado é o **auxiliar** (`avoir` ou `être`).

**Fórmula: `ne` + Auxiliar + `pas` + Particípio Passado**

- Com `Avoir`: `Je **n'**ai **pas mangé**.` (Eu **não** comi.)
- Com `Être`: `Il **n'**est **pas arrivé**.` (Ele **não** chegou.)
- Com Verbo Pronominal: `Nous **ne nous sommes pas lavé(e)s**.` (Nós **não** nos lavámos.)

### 6. Dica Final de Pronúncia e Escrita

- Pratique a conjugação de `avoir` e `être` até a exaustão. Eles são a base.
- Ao escrever, preste atenção extra aos acordos quando usar `être`. Esquecer o `-e` ou `-s` é um erro muito comum, mas que chama a atenção na escrita formal.
- Na fala, os acordos não são ouvidos, mas na escrita, são obrigatórios.

**Próxima Etapa:** Na Parte 3, focaremos exclusivamente em exercícios práticos para consolidar todo o conhecimento sobre o passé composé.