---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - L'impératif | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/e0ueVq2GqHQ?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] O Imperativo em Francês: Ordens, Conselhos e Convites
> Esta aula aborda o modo imperativo em francês, utilizado para dar ordens, conselhos, instruções e fazer convites. Aprenderemos como formar o imperativo a partir do presente do indicativo, suas particularidades com os pronomes e as exceções dos verbos irregulares mais comuns.

### [[aula6.pdf]]

---
### 📘 Tópicos da Aula
1.  Usos do Imperativo (Ordens, Conselhos, Instruções, Convites)
2.  Formação do Imperativo a partir do Presente
3.  Imperativo com Verbos Pronominais
4.  Forma Negativa do Imperativo
5.  Verbos Irregulares no Imperativo

### 📖 Conteúdo Detalhado

#### Usos do Modo Imperativo

| Situação | Exemplo em Francês | Tradução para Português |
| :--- | :--- | :--- |
| **Dar uma ordem** | **Écoute** ta mère! | **Escute** sua mãe! |
| **Dar um conselho** | **Prends** ton parapluie. | **Leve** seu guarda-chuva. |
| **Fazer um convite** | **Viens** à ma fête! | **Venha** à minha festa! |
| **Dar instruções** | **Appuyez** sur le bouton. | **Aperte** o botão. |

#### Formação do Imperativo

O imperativo usa apenas três pessoas: **tu** (você informal), **nous** (nós) e **vous** (vocês/formal). Ele é formado a partir do presente do indicativo, retirando o pronome sujeito.

| Pronome | Regra Geral (Verbos em -er) | Exemplo: Parler (Falar) | Exemplo: Finir (Terminar) |
| :--- | :--- | :--- | :--- |
| **Tu** | Presente do "tu" **sem o "s" final** | **Parle**! (Fala!) | **Finis**! (Termina!) |
| **Nous** | Igual ao presente do "nous" | **Parlons**! (Falemos!) | **Finissons**! (Terminemos!) |
| **Vous** | Igual ao presente do "vous" | **Parlez**! (Falem!) | **Finssez**! (Terminem!) |

**Observação importante:** A maior exceção é para os verbos do 1º grupo (-er) na 2ª pessoa do singular ("tu"), onde o **"s" final some**. Ex: `Tu chantes` (presente) -> **Chante**! (imperativo).

#### Casos Especiais e Irregularidades

| Verbo | Imperativo (Tu / Nous / Vous) | Tradução |
| :--- | :--- | :--- |
| **Avoir** (ter) | **Aie** / **Ayons** / **Ayez** | Tem / Tenhamos / Tenham |
| **Être** (ser) | **Sois** / **Soyons** / **Soyez** | Seja / Sejamos / Sejam |
| **Savoir** (saber) | **Sache** / **Sachons** / **Sachez** | Saiba / Saibamos / Saibam |
| **Vouloir** (querer) | **Veuille** / *(usado raramente)* / **Veuillez** | Queira / Queiram (usado para cortesia, ex: `Veuillez patienter` - Queiram aguardar) |

#### Imperativo com Verbos Pronominais

Nos verbos pronominais (como `se lever` - levantar-se), o pronome reflexivo (`me`, `te`, `se`, `nous`, `vous`) permanece, mas **muda de posição**.

| Afirmativo | Tradução | Negativo | Tradução |
| :--- | :--- | :--- | :--- |
| **Lève-toi**! | Levanta-te! | **Ne te lève pas**! | Não te levantes! |
| **Réveillons-nous**! | Vamos acordar! | **Ne nous réveillons pas**! | Não vamos acordar! |
| **Dépêchez-vous**! | Apressem-se! | **Ne vous dépêchez pas**! | Não se apressem! |

#### Forma Negativa do Imperativo

A estrutura da negativa é: **Ne + verbo + pas** (ou outro termo de negacao como `jamais`).

| Afirmativo | Negativo | Tradução da Negativa |
| :--- | :--- | :--- |
| **Mange**! | **Ne mange pas**! | Não comas! |
| **Parlez**! | **Ne parlez pas**! | Não falem! |
| **Oublie**! | **N'oublie jamais**! | Nunca esqueças! |

### 📚 Categorização de Palavras-Chave

#### Pronomes do Imperativo
*   **Tu** (você informal - singular)
*   **Nous** (nós)
*   **Vous** (vocês / você formal)

#### Verbos Irregulares Chave no Imperativo
*   **Avoir** (ter)
*   **Être** (ser/estar)
*   **Savoir** (saber)
*   **Vouloir** (querer)

#### Partículas de Negação
*   **Ne... pas** (não)
*   **Ne... jamais** (nunca)

#### Dica de Prática
Para dominar o imperativo, é crucial conhecer bem a conjugação do presente do indicativo. Pratique criando ordens, conselhos e convites para situações do dia a dia, prestando atenção especial à remoção do "s" no "tu" para verbos em -er e às formas dos verbos irregulares.