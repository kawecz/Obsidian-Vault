---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Le Présent Continu | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/vo47SM9K3ZE?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: O Presente Contínuo (Le Présent Progressif) no Francês

**Visão Geral:** Esta aula aborda o **présent progressif** (presente contínuo), um tempo verbal usado para enfatizar uma ação que **está em andamento no momento da fala**. Diferente do português, onde o gerúndio ("estou fazendo") é comum, o francês prefere o presente simples. O presente contínuo é uma forma mais enfática, usada para ações de curta duração que logo serão concluídas.

### [[aula10.pdf]]

---

### 1. A Estrutura do Presente Contínuo
A estrutura é formada pela combinação do verbo `être` (no presente) + a preposição `en train de` + o verbo principal no infinitivo.

**Fórmula: `ÊTRE` (presente) + `EN TRAIN DE` + VERBO NO INFINITIVO**

| Português             | Francês (Verbo ÊTRE) | Exemplo (Verbo Comer/Manger)            |
| --------------------- | -------------------- | --------------------------------------- |
| Eu estou comendo...   | Je **suis** en train de... | Je **suis en train de** **manger**.     |
| Tu estás comendo...   | Tu **es** en train de...   | Tu **es en train de** **manger**.       |
| Ele/Ela está comendo... | Il/Elle **est** en train de... | Il **est en train de** **manger**.    |
| Nós estamos comendo... | Nous **sommes** en train de... | Nous **sommes en train de** **manger**. |
| Vós estais comendo... | Vous **êtes** en train de...  | Vous **êtes en train de** **manger**.   |
| Eles/Elas estão comendo... | Ils/Elles **sont** en train de... | Ils **sont en train de** **manger**. |
### 2. Uso e Aplicação
- **Ação em Curso:** Destaca uma ação que está acontecendo agora, no momento exato da fala.
    - Ex: `Il est en train de dormir` (Ele **está dormindo**/está a dormir).
- **Duração Limitada:** A ação é temporária e vai terminar em breve.
    - Ex: `Je suis en train de téléphoner` (Eu **estou no telefone**).
- **Ênfase:** É usado para realçar que a ação está ocorrendo AGORA, diferentemente do presente simples, que pode descrever um hábito ou estado.

### 3. A Negação no Presente Contínuo
A negação em francês envolve colocar `ne...pas` ao redor do verbo conjugado (o verbo `être`).

**Estrutura: `NE` + VERBO `ÊTRE` + `PAS` + `EN TRAIN DE` + VERBO INFINITIVO**

| Afirmativa                          | Negativa                                      |
| ----------------------------------- | --------------------------------------------- |
| Je **suis en train de** manger.     | Je **ne suis pas en train de** manger.       |
| (Eu estou comendo.)                 | (Eu **não** estou comendo.)                  |
| Ils **sont en train de** visiter.   | Ils **ne sont pas en train de** visiter.     |
| (Eles estão visitando.)             | (Eles **não** estão visitando.)              |
### 4. Comparação de Tempos Verbais Básicos
É crucial diferenciar os tempos verbais fundamentais.

| Tempo Verbal        | Estrutura                                  | Exemplo (Francês)          | Tradução (Português)       |
| ------------------- | ------------------------------------------ | -------------------------- | -------------------------- |
| **Presente Simples**  | Apenas o verbo conjugado                   | Je mange.                  | Eu como. (hábito/estado)   |
| **Futuro Próximo**    | `Aller` (presente) + Infinitivo            | Je vais manger.            | Eu vou comer.              |
| **Passado Recente**   | `Venir` (presente) + `de` + Infinitivo     | Je viens de manger.        | Eu acabei de comer.        |
| **Presente Contínuo** | `Être` (presente) + `en train de` + Infinitivo | Je suis en train de manger. | Eu estou comendo (agora). |
### 5. Exercício Prático de Diferenciação
Complete com o tempo verbal adequado (Presente Simples, Futuro Próximo, Passado Recente ou Presente Contínuo).

1.  (Ele/estudar) para a prova **neste momento**.
    - *Il **est en train d'étudier** pour l'examen.*
2.  (Eles/ler) um livro de Júlio Verne **ontem**.
    - *Ils **ont lu** un livre de Jules Verne.* (Passado Composto - visto depois)
3.  (Nós/ir) ao cinema **amanhã**.
    - *Nous **allons aller** au cinéma.*
4.  (Eu/comer) **agora mesmo**, espere um pouco.
    - *Je **suis en train de manger**, attends un peu.*
5.  (Tu/acabar de chegar) da escola?
    - *Tu **viens d'arriver** de l'école?*

**Dica Final:** O presente contínuo é menos frequente que o presente simples. Use-o para dar ênfase à ação em progresso. Domine bem estes quatro tempos verbais (Presente, Futuro Próximo, Passado Recente e Presente Contínuo) antes de avançar para estruturas mais complexas.