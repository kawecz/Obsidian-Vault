---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Situer un Lieu | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/Vvij88TBsD8?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Como Situar um Lugar em Francês: Localização Geográfica
> Esta aula ensina a descrever a localização geográfica de cidades, países e regiões em francês. Aprenderemos verbos específicos, pontos cardeais, preposições de lugar e como estruturar frases para indicar onde um lugar está situado, seja no mapa ou em relação a outros lugares.

### [[aula7.pdf]]

---
### 📘 Tópicos da Aula
1.  Verbos para Descrever Localização
2.  Pontos Cardeais
3.  Preposições de Lugar
4.  Estruturas para Falar de Distância e Fronteiras
5.  Diálogos Práticos

### 📖 Conteúdo Detalhado

#### Verbos para Situar um Lugar

| Verbo | Conjugação (Exemplo) | Tradução | Uso |
| :--- | :--- | :--- | :--- |
| **Se situer** | Paris **se situe** en France. | Localizar-se | Descreve a localização de um lugar. |
| **Se trouver** | Lyon **se trouve** au sud. | Encontrar-se | Sinônimo comum de "se situer". |
| **Être situé(e)** | Le Brésil **est situé** en Amérique du Sud. | Estar situado | Usado com o verbo "être". Concorda em gênero e número. |

#### Pontos Cardeais (Les points cardinaux)

| Ponto Cardeal | Pronúncia Aproximada | Exemplo de Uso |
| :--- | :--- | :--- |
| **le Nord** | (le nor) | Lille est dans **le nord** de la France. |
| **le Sud** | (le sud) | Marseille est dans **le sud** de la France. |
| **l'Est** (m.) | (lest) | Strasbourg est à **l'est** de Paris. |
| **l'Ouest** (m.) | (luest) | Brest est à **l'ouest** de Paris. |
| **le Nord-Est** | (le nor-est) | |
| **le Nord-Ouest** | (le nor-uést) | |
| **le Sud-Est** | (le sud-est) | |
| **le Sud-Ouest** | (le sud-uést) | |

#### Preposições e Estruturas de Localização

| Estrutura | Pronúncia Aproximada | Significado | Exemplo |
| :--- | :--- | :--- | :--- |
| **dans le/la** | (dã le/la) | no/na (região) | **dans le** sud (no sul) |
| **à** | (a) | a (distância) | **à** 500 km (a 500 km) |
| **de** | (de) | de (origem, distância) | **de** Paris (de Paris) |
| **entre** | (ãtr) | entre | **entre** Paris et Lyon |
| **faire frontière avec** | (fer frontiêr avék) | fazer fronteira com | L'Allemagne **fait frontière avec** la France. |

**Observação sobre Gênero:** A maioria das cidades em francês é feminina. Portanto, use "**située**" (ex: "Paris est **située**..."). Portugal é uma exceção e é masculino ("Le Portugal est **situé**...").

#### Diálogo de Exemplo

**Pessoa A:** Tu habites où en France? (Onde você mora na França?)
**Pessoa B:** J'habite à Marseille. (Moro em Marselha.)
**Pessoa A:** Où se trouve Marseille? (Onde fica Marselha?)
**Pessoa B:** Marseille se trouve dans le sud de la France. (Marselha fica no sul da França.)

### 📚 Categorização de Palavras-Chave

#### Substantivos
*   **La carte** (o mapa)
*   **Le pays** (o país)
*   **La ville** (a cidade)
*   **La région** (a região)
*   **La frontière** (a fronteira)
*   **La distance** (a distância)

#### Verbos
*   **Se situer** (localizar-se)
*   **Se trouver** (encontrar-se, estar localizado)
*   **Habiter** (morar)

#### Preposições e Locuções Prepositivas
*   **Dans** (em, no/na)
*   **À** (a, em)
*   **De** (de, do/da)
*   **Entre** (entre)
*   **Au nord de** (ao norte de)
*   **À l'est de** (a leste de)

#### Dica de Prática
Para praticar, pegue um mapa do Brasil e descreva a localização da sua cidade ou de outras cidades em francês. Use a estrutura: "[Nome da cidade] **se situe** [preposição + ponto cardeal] **du Brésil**." (Ex: "Fortaleza **se situe dans le nord-est du Brésil**.") Isso ajudará a fixar o vocabulário e as estruturas de forma contextualizada.