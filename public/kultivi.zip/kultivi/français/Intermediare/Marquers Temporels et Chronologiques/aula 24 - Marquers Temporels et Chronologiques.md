---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Marqueurs Temporels et Chronologiques | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/nSFhmjdMgZs?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Marcadores Temporais em Francês

**Visão Geral:** Esta aula foca nos marcadores temporais (les marqueurs temporels), palavras ou expressões essenciais para situar uma ação no tempo. Dominá-los é crucial para contar histórias, descrever rotinas e entender a relação entre diferentes eventos.

### [[aula24.pdf]]

---
### 1. A Linha do Tempo e os Marcadores

Para entender os marcadores, visualize uma linha do tempo:

**Passado <--- { PRESENTE } ---> Futuro**

Os marcadores nos dizem *quando* uma ação aconteceu em relação a este eixo.

### 2. Marcadores de Passado

Estes situam a ação inteiramente no passado.

| Marcador | Tradução | Uso / Exemplo |
| :--- | :--- | :--- |
| **Hier** | Ontem | `Je suis allé au cinéma **hier**.` (Fui ao cinema **ontem**.) |
| **Avant-hier** | Anteontem | `Il est arrivé **avant-hier**.` (Ele chegou **anteontem**.) |
| **La semaine dernière** | Na semana passada | `Nous avons travaillé **la semaine dernière**.` (Nós trabalhamos **na semana passada**.) |
| **L'année dernière** | No ano passado | `Ils ont voyagé **l'année dernière**.` (Eles viajaram **no ano passado**.) |
| **Il y a + [tempo]** | Há / Faz [tempo] | `Je l'ai vu **il y a deux jours**.` (Eu o vi **há dois dias**.) |
| **Pendant** | Durante | `J'ai habité en France **pendant** cinq ans.` (Morei na França **durante** cinco anos.) |
| **Après** | Depois | `**Après** le dîner, j'ai lu un livre.` (**Depois** do jantar, li um livro.) |
| **D'abord... puis...** | Primeiro... depois... | `**D'abord** il a mangé, **puis** il est sorti.` (**Primeiro** ele comeu, **depois** saiu.) |
| **Enfin** | Finalmente | `**Enfin**, il a réussi.` (**Finalmente**, ele conseguiu.) |

### 3. Marcadores de Presente

Estes situam a ação no momento atual ou em hábitos.

| Marcador | Tradução | Uso / Exemplo |
| :--- | :--- | :--- |
| **Aujourd'hui** | Hoje | `**Aujourd'hui**, il fait beau.` (**Hoje**, está bom tempo.) |
| **En ce moment** | Neste momento | `Je travaille **en ce moment**.` (Estou a trabalhar **neste momento**.) |
| **Maintenant** | Agora | `**Maintenant**, je comprends.` (**Agora**, entendo.) |
| **Tous les jours** | Todos os dias | `Elle se lève tôt **tous les jours**.` (Ela levanta-se cedo **todos os dias**.) |
| **D'habitude** | Habitualmente | `**D'habitude**, je prends un café.` (**Habitualmente**, tomo um café.) |

### 4. Marcadores de Futuro

Estes situam a ação no tempo que ainda vai acontecer.

| Marcador | Tradução | Uso / Exemplo |
| :--- | :--- | :--- |
| **Demain** | Amanhã | `Nous irons à la plage **demain**.` (Iremos à praia **amanhã**.) |
| **Après-demain** | Depois de amanhã | `Mon anniversaire est **après-demain**.` (O meu aniversário é **depois de amanhã**.) |
| **La semaine prochaine** | Na próxima semana | `Il partira **la semaine prochaine**.` (Ele partirá **na próxima semana**.) |
| **L'année prochaine** | No próximo ano | `J'apprendrai l'italien **l'année prochaine**.` (Aprenderei italiano **no próximo ano**.) |
| **Bientôt** | Em breve | `Le film commence **bientôt**.` (O filme começa **em breve**.) |
| **Dans + [tempo]** | Dentro de [tempo] | `Je pars **dans** dix minutes.` (Parto **dentro de** dez minutos.) |

### 5. Advérbios de Frequência

Estes indicam *com que frequência* uma ação ocorre. Colocam-se **após o verbo**.

| Advérbio | Tradução | Exemplo |
| :--- | :--- | :--- |
| **Toujours** | Sempre | `Je **toujours** me lève à 7h.` (Errado) <br> `Je me lève **toujours** à 7h.` (Correto) |
| **Souvent** | Frequentemente | `Il voyage **souvent**.` (Ele viaja **frequentemente**.) |
| **Parfois** | Às vezes | `Nous allons **parfois** au cinéma.` (Nós vamos **às vezes** ao cinema.) |
| **Rarement** | Raramente | `Tu **rarement** manges de la viande.` (Errado) <br> `Tu manges **rarement** de la viande.` (Correto) |
| **Ne... jamais** | Nunca | `Je **ne** voyage **jamais** en avion.` (Eu **nunca** viajo de avião.) |

### 6. Dica de Ouro: A Posição do Marcador

- **Marcadores de tempo (ex: hier, demain, la semaine dernière)** podem ficar no início ou no final da frase para dar ênfase.
    - `**Hier**, j'ai travaillé.` ou `J'ai travaillé **hier**.`
- **Advérbios de frequência (ex: souvent, toujours, rarement)** colocam-se **APÓS** o verbo.
    - `Il **écoute souvent** de la musique.` (Ele **escuta frequentemente** música.)

**Próximo Passo:** Pratique criando frases sobre a sua rotina e os seus planos, usando estes marcadores. Tente recontar um evento do seu passado, utilizando `d'abord`, `puis` e `enfin` para dar sequência à história.