---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Le Présent | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/WuDZxB1oYZw?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---

> [!abstract] Conjugação de Verbos no Presente em Francês
> Esta aula aborda os principais grupos de conjugação de verbos no presente do indicativo em francês. O foco é entender a lógica por trás das terminações e radicais, agrupando verbos com comportamentos semelhantes para facilitar o aprendizado, sem a necessidade de decorar cada verbo individualmente.

### [[aula1.pdf]]

---

### 📘 Tópicos da Aula
1.  Verbos Regulares do 1º Grupo (terminados em -er)
2.  Verbos do 2º Grupo (terminados em -ir, como `finir`)
3.  Verbos do 3º Grupo (irregulares, incluindo `partir`, `dormir`, `prendre`, `connaître`, etc.)
4.  Dicas para Identificar Padrões e Praticar

### 📖 Conteúdo Detalhado

#### Estrutura Básica da Conjugação
A conjugação é formada pelo **radical** (parte principal do verbo) + a **terminação** (que varia de acordo com o pronome pessoal). Entender essa construção é a chave para conjugar a maioria dos verbos.

#### Grupo 1: Verbos Regulares em -er (Exemplo: `Parler` - Falar)

| Pronome | Conjugação | Pronúncia Aproximada |
| :--- | :--- | :--- |
| Je | parl**e** | (parl) |
| Tu | parl**es** | (parl) |
| Il/Elle/On | parl**e** | (parl) |
| Nous | parl**ons** | (parl-on) |
| Vous | parl**ez** | (parl-ê) |
| Ils/Elles | parl**ent** | (parl) |

**Outros verbos deste grupo:** `danser` (dançar), `chanter` (cantar), `arriver` (chegar), `habiter` (morar), `trouver` (encontrar), `donner` (dar).

#### Grupo 2: Verbos em -ir (Exemplo: `Finir` - Terminar)

| Pronome | Conjugação | Observações |
| :--- | :--- | :--- |
| Je | fin**is** | |
| Tu | fin**is** | |
| Il/Elle/On | fin**it** | |
| Nous | fin**issons** | Atenção ao "ss" |
| Vous | fin**issez** | Atenção ao "ss" |
| Ils/Elles | fin**issent** | Atenção ao "ss" |

**Característica:** A terminação no plural (`nous`, `vous`, `ils/elles`) sempre inclui **"ss"**.
**Outros verbos deste grupo:** `choisir` (escolher), `réussir` (conseguir).

#### Grupo 3: Verbos Irregulares (Padrões Comuns)

Este grupo contém vários subgrupos de verbos que seguem padrões semelhantes.

**Subgrupo 3.1: Verbos como `Partir` (Sair) / `Dormir` (Dormir)**

| Pronome | Conjugação (`Partir`) | Conjugação (`Dormir`) |
| :--- | :--- | :--- |
| Je | pars | dors |
| Tu | pars | dors |
| Il/Elle/On | part | dort |
| Nous | part**ons** | dorm**ons** |
| Vous | part**ez** | dorm**ez** |
| Ils/Elles | part**ent** | dorm**ent** |

**Característica:** O radical muda nas três primeiras pessoas (`je`, `tu`, `il`), mas mantém as terminações regulares do plural.

**Subgrupo 3.2: Verbos como `Prendre` (Pegar/Tomar)**

| Pronome | Conjugação (`Prendre`) | Observações |
| :--- | :--- | :--- |
| Je | prends | |
| Tu | prends | |
| Il/Elle/On | prend | |
| Nous | pren**ons** | Radical muda para `pren-` |
| Vous | pren**ez** | Radical muda para `pren-` |
| Ils/Elles | prenn**ent** | Radical `prenn-` com "n" duplo |

**Outros verbos como `prendre`:** `apprendre` (aprender), `comprendre` (compreender).

**Subgrupo 3.3: Verbos como `Connaître` (Conhecer)**

| Pronome | Conjugação (`Connaître`) |
| :--- | :--- |
| Je | connais |
| Tu | connais |
| Il/Elle/On | connaît |
| Nous | connaiss**ons** |
| Vous | connaiss**ez** |
| Ils/Elles | connaiss**ent** |

**Característica:** O radical `connaiss-` é usado nos plurais.

**Subgrupo 3.4: Verbos como `Vouloir` (Querer) / `Pouvoir` (Poder)**

Estes são verbos altamente irregulares e essenciais.

| Pronome | Conjugação (`Vouloir`) | Conjugação (`Pouvoir`) |
| :--- | :--- | :--- |
| Je | veux | peux |
| Tu | veux | peux |
| Il/Elle/On | veut | peut |
| Nous | voul**ons** | pouv**ons** |
| Vous | voul**ez** | pouv**ez** |
| Ils/Elles | veul**ent** | peuv**ent** |

**Subgrupo 3.5: Verbos como `Devoir` (Dever)**

| Pronome | Conjugação (`Devoir`) |
| :--- | :--- |
| Je | dois |
| Tu | dois |
| Il/Elle/On | doit |
| Nous | dev**ons** |
| Vous | dev**ez** |
| Ils/Elles | doiv**ent** |

**Subgrupo 3.6: Verbos como `Écrire` (Escrever) / `Lire` (Ler)**

| Pronome | Conjugação (`Écrire`) | Conjugação (`Lire`) |
| :--- | :--- | :--- |
| Je | écris | lis |
| Tu | écris | lis |
| Il/Elle/On | écrit | lit |
| Nous | écriv**ons** | lis**ons** |
| Vous | écriv**ez** | lis**ez** |
| Ils/Elles | écriv**ent** | lis**ent** |

### 📚 Categorização de Palavras-Chave

#### Substantivos
*   **Le radical** (o radical)
*   **La terminaison** (a terminação)
*   **Le groupe de verbes** (o grupo de verbes)
*   **Le présent** (o presente)

#### Verbos (Exemplos Chave)
*   **Parler** (falar)
*   **Finir** (terminar)
*   **Partir** (sair)
*   **Prendre** (pegar, tomar)
*   **Vouloir** (querer)
*   **Pouvoir** (poder)
*   **Devoir** (dever)
*   **Connaître** (conhecer)
*   **Écrire** (escrever)

#### Dicas de Estudo
*   Pratique identificando o radical e a terminação.
*   Agrupe mentalmente os verbos que seguem o mesmo padrão de conjugação.
*   Use ferramentas como o dicionário online "Le Robert" para verificar conjugações.
*   Crie frases com os verbos aprendidos para fixar o contexto de uso.