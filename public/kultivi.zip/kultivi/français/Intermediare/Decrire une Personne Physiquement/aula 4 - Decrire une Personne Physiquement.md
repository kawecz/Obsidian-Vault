---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Décrire une Personne Physiquement | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/TUbitlwL6o4?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>


---
> [!abstract] Como Descrever uma Pessoa Fisicamente em Francês
> Esta aula ensina o vocabulário e as estruturas necessárias para descrever a aparência física de uma pessoa em francês. Aborda desde características gerais (altura, peso) até detalhes específicos (cor e tipo de cabelo, cor dos olhos, traços distintivos), incluindo a concordância de gênero e número dos adjetivos.

### [[aula4.pdf]]

---

### 📘 Tópicos da Aula
1.  Aparência Geral e Tipo de Corpo
2.  Altura e Estatura
3.  Cor e Estilo do Cabelo
4.  Cor dos Olhos e da Pele
5.  Traços Distintivos (sorriso, olhar)
6.  Estruturas para Comparações

### 📖 Conteúdo Detalhado

#### Aparência Geral e Tipo de Corpo

| Francês | Pronúncia Aproximada | Tradução / Uso |
| :--- | :--- | :--- |
| **Avoir l'air...** | (avuar lér) | Ter aparência de... / Parecer... |
| **Avoir l'air sportif/sportive** | | Parecer esportivo/esportiva |
| **Avoir l'air fatigué(e)** | | Parecer cansado/cansada |
| **Avoir l'air fragile** | | Parecer frágil |
| **Être mince** | (étr mîs) | Ser magro(a) / esbelto(a) |
| **Être fort(e)** | (étr for/fort) | Ser forte |
| **Être gros / grosse** | (étr gro/gross) | Ser gordo(a) |

#### Altura e Estatura

| Francês | Pronúncia Aproximada | Tradução |
| :--- | :--- | :--- |
| **Être grand(e)** | (étr grã/grãd) | Ser alto(a) |
| **Être de taille moyenne** | (étr de tái muián) | Ser de altura média |
| **Être petit(e)** | (étr peti/petit) | Ser baixo(a) / pequeno(a) |
| **Un grand** | (ã grã) | Uma pessoa alta (homem) |
| **Une grande** | (ün grãd) | Uma pessoa alta (mulher) |

**Importante:** Em francês, usa-se `grand(e)` para altura. "Alto" no sentido de volume sonoro é `fort`.

#### Cor e Estilo do Cabelo (Les cheveux)

| Característica | Francês (Masculino / Feminino) | Tradução |
| :--- | :--- | :--- |
| **Cor do Cabelo** | **Elle a les cheveux...** (Ela tem o cabelo...) | |
| | **blonds / blondes** | loiros |
| | **bruns / brunes** | castanhos |
| | **châtains** | castanho claro |
| | **roux / rousses** | ruivos |
| | **noirs / noires** | pretos |
| **Tipo de Cabelo** | **Elle a les cheveux...** | |
| | **raides** | lisos |
| | **frisés** | cacheados / frisados |
| | **bouclés** | cacheados (com cachos) |
| | **courts** | curtos |
| | **longs** | longos |

**Nota:** Ao descrever os cabelos, use sempre o verbo `avoir` (ter) e a estrutura no plural: `avoir les cheveux [adjetivo]`.

#### Cor dos Olhos (Les yeux) e da Pele (La peau)

| Característica | Francês | Tradução |
| :--- | :--- | :--- |
| **Cor dos Olhos** | **Elle a les yeux...** (Ela tem os olhos...) | |
| | **bleus** | azuis |
| | **verts** | verdes |
| | **marrons** | castanhos |
| | **noirs** | pretos |
| **Cor da Pele** | **Elle a la peau...** (Ela tem a pele...) | |
| | **blanche** | branca |
| | **noire** | negra |
| | **bronzée** | bronzeada |

#### Traços Distintivos e Estruturas de Comparação

| Francês | Pronúncia Aproximada | Tradução / Uso |
| :--- | :--- | :--- |
| **Avoir le sourire de...** | (avuar le surir de) | Ter o sorriso de... |
| **Avoir les yeux de...** | (avuar lêz iô de) | Ter os olhos de... |
| **Avoir le regard de...** | (avuar le regarde de) | Ter o olhar de... |
| **Ressembler à...** | (ressãblê a) | Parecer-se com... |
| **Ils se ressemblent beaucoup.** | (il se ressãblt boku) | Eles se parecem muito. |
| **Ils se ressemblent un peu.** | (il se ressãblt ã pô) | Eles se parecem um pouco. |
| **comme** | (com) | como (para comparações) |

### 📚 Categorização de Palavras-Chave

#### Adjetivos para Descrição Física
*   **Grand(e)** (alto/a)
*   **Petit(e)** (baixo/a, pequeno/a)
*   **Mince** (magro/a)
*   **Forte/Fort** (forte)
*   **Gros(se)** (gordo/a)
*   **Beau/Belle** (bonito/a)

#### Substantivos
*   **La taille** (a altura, o tamanho)
*   **Les cheveux** (o cabelo)
*   **Les yeux** (os olhos)
*   **La peau** (a pele)
*   **Le sourire** (o sorriso)
*   **Le regard** (o olhar)

#### Verbos e Estruturas
*   **Être** (ser/estar)
*   **Avoir** (ter)
*   **Avoir l'air** (parecer)
*   **Ressembler à** (parecer-se com)

#### Dica de Prática
Descreva três pessoas que você conhece (ou figuras públicas) por escrito, utilizando o vocabulário aprendido. Use a ferramenta online **Bon Patron** para verificar e corrigir possíveis erros de concordância e ortografia em seus textos.