---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - La Mode | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/J3oQmKNloEM?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Vocabulário de Moda e Acessórios em Francês

**Visão Geral:** Esta aula expande o vocabulário na área da moda, essencial para quem se interessa pelo tema ou pretende trabalhar na França. Cobrimos peças de roupa, acessórios, tecidos, padrões e expressões chave para descrever roupas e fazer compras.

### [[aula15.pdf]]

---
### 1. Peças de Roupa (Les Vêtements)

| Português     | Francês         | Pronúncia Aproximada |
| ------------- | --------------- | --------------------- |
| O chapéu      | **Le chapeau**  | (lë sha-pô)           |
| A camisa      | **La chemise**  | (la she-miz)          |
| A camiseta    | **Le t-shirt**  | (lë ti-cheurt)        |
| O brinco      | **Le bijou**    | (lë bi-ju)            |
| O colar       | **Le collier**  | (lë ko-liê)           |
| A pulseira    | **Le bracelet** | (lë bras-lê)          |
| O casaco      | **Le manteau**  | (lë man-tô)           |
| O casaco (curto) | **La veste** | (la vest)             |
| A saia        | **La jupe**     | (la jup)              |
| A calça       | **Le pantalon** | (lë pan-ta-lon)       |
| A bermuda     | **Le short**    | (lë short)            |
| O pijama      | **Le pyjama**   | (lë pi-ja-ma)         |
| A meia        | **La chaussette** | (la sho-set)        |
| O sapato      | **La chaussure** | (la sho-sür)         |
| A bota        | **La botte**    | (la bot)              |
| O suéter      | **Le pull**     | (lë pul)              |

### 2. Acessórios e Detalhes (Les Accessoires et les Détails)

| Português           | Francês              | Pronúncia Aproximada |
| ------------------- | -------------------- | --------------------- |
| O salto alto        | **Le talon**         | (lë ta-lon)           |
| Os óculos           | **Les lunettes**     | (lê lü-net)           |
| Estampado/Com desenho | **À carreaux**     | (a ka-rô)             |
| Com listras         | **À rayures**        | (a rai-ür)            |
| Com bolinhas        | **À pois**           | (a puá)               |
| Gola                | **Le col**           | (lë kol)              |
| Manga (curta/longa) | **Manche** (courte/longue) | (mànsh) (kurt/long) |

### 3. Tecidos (Les Tissus)

| Português | Francês      | Pronúncia Aproximada |
| --------- | ------------ | --------------------- |
| O algodão | **Le coton** | (lë ko-ton)           |
| A seda    | **La soie**  | (la sua)              |
| A lã      | **La laine** | (la len)              |
| O linho   | **Le lin**   | (lë lin)              |

### 4. Expressões Úteis para Compras

#### 4.1. Descrevendo Roupas
- `C'est à la mode.` (Está na moda.)
- `C'est confortable.` (É confortável.)
- `C'est original.` (É original.)
- `Je vais l'essayer.` (Vou experimentar.)

#### 4.2. Perguntas na Loja
- `Quelle est votre taille ?` (Qual é o seu tamanho?)
- `Quelle pointure faites-vous ?` (Que número você calça?)
- `Puis-je l'essayer ?` (Posso experimentar?)
- `Où est la cabine d'essayage ?` (Onde é o provador?)

#### 4.3. O Verbo "Vestir" (`Porter`)
Em francês, usa-se o verbo `porter` (carregar/usar) para "vestir".
- `Je porte une chemise.` (Eu visto/estou usando uma camisa.)
- `Il porte un manteau.` (Ele veste/está usando um casaco.)
- `Elle porte des lunettes.` (Ela usa óculos.)

### 5. Diálogo Exemplo em uma Loja

**Vendedor:** `Bonjour, puis-je vous aider ?` (Olá, posso ajudá-lo?)
**Cliente:** `Je cherche une robe.` (Estou procurando um vestido.)
**Vendedor:** `Quelle taille faites-vous ?` (Que tamanho você veste?)
**Cliente:** `Je fais du 38.` (Eu visto 38.)
**Vendedor:** `Et quelle couleur préférez-vous ?` (E qual cor você prefere?)
**Cliente:** `J'aime le rouge. Puis-je l'essayer ?` (Gosto do vermelho. Posso experimentar?)
**Vendedor:** `Bien sûr, la cabine d'essayage est là-bas.` (Claro, o provador é ali.)

### 6. Exercício Prático

1.  **Descreva a roupa que você está vestindo agora em francês, usando o verbo `porter`.**
    - *Exemplo: `Je porte un t-shirt noir et un jean bleu.`* (Estou vestindo uma camiseta preta e um jeans azul.)

2.  **Traduza para o francês:**
    - "Eu quero comprar um casaco confortável."
    - *`Je veux acheter un manteau confortable.`*
    - "Onde posso experimentar estas calças?"
    - *`Où puis-je essayer ce pantalon ?`*

**Dica Final:** Para se aprofundar, explore sites de marcas e magazines de moda franceses (como *Vogue Paris*, *Zara France*, *Galeries Lafayette*). Leia as descrições dos produtos para ver o vocabulário em contexto real.