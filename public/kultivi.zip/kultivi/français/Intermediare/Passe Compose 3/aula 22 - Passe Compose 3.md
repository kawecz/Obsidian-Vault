---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Passé Composé III - Exercices | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/MoIv5K-im3o?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Passé Composé - Parte 3 (Exercícios Práticos)

**Visão Geral:** Esta aula é dedicada exclusivamente à prática do passé composé através de exercícios. Usaremos frases simples e um trecho da obra "L'Étranger", de Albert Camus, para consolidar o uso deste tempo verbal crucial.

### 1. Exercícios de Conjugação Direta

Complete as frases com o passé composé do verbo indicado.

1.  Hier, je ______ (manger) une pizza.
    *   **Correção:** `ai mangé`
    *   *Explicação: Verbo `manger` (terminação `-er`) + auxiliar `avoir`.*

2.  Elle ______ (choisir) la robe bleue.
    *   **Correção:** `a choisi`
    *   *Explicação: Verbo `choisir` (terminação `-ir`) + auxiliar `avoir`.*

3.  Nous ______ (se réveiller) à 8 heures.
    *   **Correção:** `nous sommes réveillé(e)s`
    *   *Explicação: Verbo pronominal `se réveiller` + auxiliar `être`. O particípio (`réveillé`) concorda com o sujeito `nous`.*

4.  Vous ______ (apprendre) le français rapidement.
    *   **Correção:** `avez appris`
    *   *Explicação: Verbo irregular `apprendre` (`appris`) + auxiliar `avoir`.*

5.  Ils ______ (aller) au cinéma.
    *   **Correção:** `sont allés`
    *   *Explicação: Verbo de movimento `aller` + auxiliar `être`. O particípio (`allés`) concorda com o sujeito masculino plural `ils`.*

### 2. Análise de um Texto: "L'Étranger" de Albert Camus

Vamos analisar e traduzir as frases no passé composé do trecho.

**Texte Original:**
« Aujourd'hui, maman est morte. Ou peut-être hier, je ne sais pas. J'ai reçu un télégramme de l'asile : « Mère décédée. Enterrement demain. Sentiments distingués. » Cela ne veut rien dire. C'était peut-être hier.
... J'ai pris l'autobus à deux heures. ... Il faisait très chaud. J'ai mangé au restaurant chez Céleste, comme d'habitude. ... Céleste m'a dit : « On n'a qu'une mère. » Quand je suis parti, ils m'ont accompagné à la porte. ... Il a fallu que je monte chez Emmanuel pour lui emprunter une cravate noire et un brassard. Il a perdu son oncle, il y a quelques mois. »

**Análise e Tradução:**

| Frase em Francês (Passé Composé) | Verbo (Infinitivo) | Auxiliar | Particípio Passado | Tradução em Português |
| :--- | :--- | :--- | :--- | :--- |
| **maman est morte** | mourir | être | morte (acordo com "maman") | **mamãe morreu** |
| **J'ai reçu un télégramme** | recevoir | avoir | reçu (irregular) | **Eu recebi um telegrama** |
| **J'ai pris l'autobus** | prendre | avoir | pris (irregular) | **Eu peguei o ônibus** |
| **J'ai mangé au restaurant** | manger | avoir | mangé (regular -er) | **Eu comi no restaurante** |
| **Céleste m'a dit** | dire | avoir | dit (irregular) | **Céleste me disse** |
| **je suis parti** | partir | être | parti (acordo masc.) | **eu parti** |
| **ils m'ont accompagné** | accompagner | avoir | accompagné (regular -er) | **eles me acompanharam** |
| **Il a fallu** | falloir | avoir | fallu (irregular/impessoal) | **Foi preciso / Precisou** |
| **Il a perdu son oncle** | perdre | avoir | perdu (regular -re) | **Ele perdeu o tio** |

### 3. Dicas Finais para Dominar o Passé Composé

1.  **Decore os Auxiliares:** Saiba de cor a conjugação de `avoir` e `être` no presente.
2.  **Memorize os Irregulares:** Foque nos particípios passados irregulares mais comuns (`pris`, `fait`, `vu`, `eu`, `été`, etc.).
3.  **Atenção aos Acordos:** Lembre-se de que com `être`, o particípio concorda com o sujeito. Com `avoir`, não há acordo (a menos que o objeto direto venha antes do verbo).
4.  **Pratique a Pronúncia:** Treine a diferença entre `j'ai` (jê) e `je suis` (jê sui).
5.  **Leia e Ouça:** A exposição a textos e conversas em francês é a melhor maneira de internalizar as estruturas.

**Próximos Passos:** Continue praticando com outros textos e diálogos. Tente reescrever parágrafos curtos sobre o seu dia, transformando as ações para o passé composé.