---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - L'imparfait | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/4Y8qCAP9aG4?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: O Imperfeito (L'Imparfait)

**Visão Geral:** O imparfait (imperfeito) é um tempo verbal do passado usado para descrever ações contínuas, hábitos ou estados no passado, sem um início ou fim definidos. Diferente do passé composé (que descreve ações pontuais e concluídas), o imparfait pinta o cenário, descreve o contexto.

### [[aula19.pdf]]

---
### 1. Uso do Imparfait
- **Descrição no passado:** Descrever cenários, pessoas, situações.
- **Hábitos no passado:** Ações repetitivas ou costumes.
- **Ações contínuas:** Ações em progresso no passado, sem foco no término.
- **Ações simultâneas:** Duas ou mais ações ocorrendo ao mesmo tempo.

### 2. Formação do Imparfait
O radical é obtido a partir da 1ª pessoa do plural do presente do indicativo (nous). Remove-se a terminação `-ons` e adicionam-se as terminações do imparfait.

**Terminações do Imparfait: `-ais, -ais, -ait, -ions, -iez, -aient`**

| Pronome | Terminação | Exemplo: Parler (nous parl**ons**) | Exemplo: Finir (nous finiss**ons**) |
| ------- | ---------- | ---------------------------------- | ----------------------------------- |
| Je      | **-ais**   | je parl**ais**                     | je finiss**ais**                    |
| Tu      | **-ais**   | tu parl**ais**                     | tu finiss**ais**                    |
| Il/Elle | **-ait**  | il parl**ait**                     | il finiss**ait**                    |
| Nous    | **-ions**  | nous parl**ions**                  | nous finiss**ions**                 |
| Vous    | **-iez**   | vous parl**iez**                   | vous finiss**iez**                  |
| Ils/Elles | **-aient**| ils parl**aient**                  | ils finiss**aient**                 |

### 3. Verbos Irregulares no Imparfait
A maioria dos verbos irregulares segue a regra padrão de formação no imparfait.

| Verbo   | Radical (Nous) | Je        | Il/Elle   | Nous      |
| ------- | -------------- | --------- | --------- | --------- |
| **Être**| ét**-** (nous **sommes**) | j'**étais** | il **était** | nous **étions** |
| **Avoir**| av**-** (nous **avons**) | j'**avais** | il **avait** | nous **avions** |
| **Aller**| all**-** (nous **allons**) | j'**allais** | il **allait** | nous **allions** |
| **Faire**| fais**-** (nous **faisons**) | je **faisais** | il **faisait** | nous **faisions** |

### 4. Imparfait vs. Passé Composé
A escolha entre esses dois tempos é crucial.

| Contexto                   | Imparfait                          | Passé Composé                     |
| -------------------------- | ---------------------------------- | --------------------------------- |
| **Descrição / Cenário**    | `Il **faisait** beau.` (Estava bom tempo.) | ---                               |
| **Ação Contínua / Hábito** | `Je **mangeais** des fruits.` (Eu comia frutas.) | ---                               |
| **Ação Pontual / Concluída** | ---                              | `J'**ai mangé** une pomme.` (Eu comi uma maçã.) |
| **Ações Simultâneas**      | `Il **dormait** quand j'**arrivais**.` (Ele dormia quando eu chegava.) | ---                               |

### 5. Exercícios Práticos

1.  **Conjugue o verbo entre parênteses no imparfait:**
    - `Quand j'_____ (être) enfant, je _____ (jouer) au football.`
    - *`étais, jouais`* (Quando eu era criança, eu jogava futebol.)
    - `Nous _____ (habiter) en France et nous _____ (aller) à la plage.`
    - *`habitions, allions`* (Nós morávamos na França e íamos à praia.)

2.  **Traduza para o francês usando o imparfait:**
    - "Eu sempre comia pão com manteiga no café da manhã."
    - *`Je **mangeais** toujours du pain avec du beurre au petit déjeuner.`*
    - "Ela estava lendo um livro quando o telefone tocou."
    - *`Elle **lisait** un livre quand le téléphone a sonné.`* (Nota: "a sonné" é passé composé, ação pontual que interrompe a ação contínua.)

**Dica Final:** Para dominar o imparfait, pratique descrevendo cenas do passado, seus antigos hábitos ou rotinas. Preste atenção aos marcadores temporais que frequentemente acompanham o imparfait, como `chaque jour` (todos os dias), `toujours` (sempre), `souvent` (frequentemente), `quand j'étais enfant` (quando eu era criança).