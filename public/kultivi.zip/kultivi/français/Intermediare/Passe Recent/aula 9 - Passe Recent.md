---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Passé Récent | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/THg1xpdCNm4?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: O Passado Recente (Le Passé Immédiat) no Francês

**Visão Geral:** Esta aula introduz o **passé immédiat** (passado recente), um tempo verbal usado para descrever uma ação que **acabou de acontecer**. É o equivalente francês da expressão portuguesa "acabar de + verbo". Aprendemos sua estrutura, conjugação e aplicação em situações do cotidiano.

### [[aula9.pdf]]

---

### 1. A Linha do Tempo Verbal
- **Presente:** Ações que acontecem agora.
- **Futuro Próximo (Futur Proche):** Ações que vão acontecer daqui a pouco (`aller` + infinitivo). Ex: `Je vais manger` (Eu vou comer).
- **Passado Recente (Passé Immédiat):** Ações que **acabaram de acontecer**. É um passado "colado" ao presente.

### 2. Como Formar o Passé Recente
A estrutura é semelhante à do futuro próximo, mas usando o verbo `venir` no presente.

**Fórmula: `VENIR` (no presente) + `DE` + VERBO NO INFINITIVO**

| Português       | Francês (Verbo VENIR) | Exemplo (Verbo Chegar/Arriver) |
| --------------- | --------------------- | ------------------------------ |
| Eu acabei de... | Je **viens** de...    | Je **viens** d'**arriver**.    |
| Tu acabaste de... | Tu **viens** de...    | Tu **viens** d'**arriver**.    |
| Ele/Ela acabou de... | Il/Elle **vient** de... | Il **vient** d'**arriver**.    |
| Nós acabamos de... | Nous **venons** de...  | Nous **venons** d'**arriver**. |
| Vós acabastes de... | Vous **venez** de...   | Vous **venez** d'**arriver**.  |
| Eles/Elas acabaram de... | Ils/Elles **viennent** de... | Ils **viennent** d'**arriver**. |
### 3. Particularidades e Radicais Irregulares
- A maioria dos verbos segue a conjugação regular de `venir`.
- **Dois verbos têm radicais irregulares:**
    - `Être`: `je viens d'**être**`
    - `Avoir`: `je viens d'**avoir**`
- Para todos os outros verbos, usa-se o infinitivo normalmente após `de`.

### 4. Equivalente em Português e Uso
- A tradução natural é **"acabar de + verbo"**.
- **Exemplos:**
    - `Je viens de manger` = Eu **acabei de** comer.
    - `Il vient de dormir` = Ele **acabou de** dormir.
    - `Nous venons d'étudier` = Nós **acabamos de** estudar.

### 5. Expressões de Telefone (Contexto Prático)
No diálogo telefônico do transcript, surgem expressões úteis:

| Expressão (Francês)        | Tradução (Português)         | Contexto de Uso                                  |
| -------------------------- | ---------------------------- | ------------------------------------------------ |
| `laisser un message`       | deixar uma mensagem          | Pedir para deixar um recado.                     |
| `Ne quittez pas`           | Não desligue                 | Pedir para a pessoa esperar na linha.            |
| `Je vous le/la passe`      | Eu passo ele/ela para você   | Transferir a ligação para outra pessoa.          |
| `Qui est à l'appareil ?`   | Quem está falando?           | Perguntar quem é a pessoa na linha.              |
### 6. Exercício Prático
Tente traduzir e formar as frases em francês no passado recente.

1.  Eles **acabaram de ler** um livro de Júlio Verne.
    - *Ils **viennent de lire** un livre de Jules Verne.*
2.  Nós **acabamos de fazer** um tour de bicicleta.
    - *Nous **venons de faire** un tour à vélo.*
3.  Eu **acabo de chegar** em casa.
    - *Je **viens d'arriver** à la maison.*
4.  (Ela) **Acabou de sair**.
    - *Elle **vient de partir**.*

**Dica de Pronúncia:** A terminação `-s` em `viens` e `vient` **NÃO** é pronunciada. Soam como "vien".

---
**Próximos Passos:** Domine bem o passado recente, pois ele é a base para entender os outros tempos de passado do francês, que são mais complexos. Pratique criando frases sobre a sua rotina.