---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Raconter Une Histoire | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/QKskXimYFug?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Passé Composé vs. Imparfait na Prática

**Visão Geral:** Esta aula consolida o uso dos dois principais tempos do passado em francês através da análise de um texto narrativo. O objetivo é distinguir claramente quando usar o **Passé Composé** (ações pontuais, eventos específicos) e o **Imparfait** (descrições, hábitos, ações contínuas).

### [[aula25.pdf]]

---
### 1. Revisão Rápida: A Diferença Fundamental

| Passé Composé (PC) | Imparfait (IMP) |
| :--- | :--- |
| Ação única e concluída. | Ação habitual ou contínua no passado. |
| "Ponto" na linha do tempo. | "Duração" ou "cenário" no passado. |
| Muda o curso da narrativa. | Descreve o contexto da narrativa. |
| **Exemplo:** `J'ai mangé une pomme.` (Comi uma maçã.) | **Exemplo:** `Quand j'étais enfant, je mangeais des fruits.` (Quando era criança, comia frutas.) |

### 2. Análise de um Texto Narrativo

Vamos analisar um trecho de uma história para ver os dois tempos em ação.

**Texte :**
« Quand j'**étais** (IMP) petite, nous **habitions** (IMP) à la campagne. Mon frère et moi, nous **jouions** (IMP) toujours dans le jardin. Un jour, il **a trouvé** (PC) un petit oiseau blessé. Il **était** (IMP) très faible. Nous l'**avons ramené** (PC) à la maison et nous l'**avons soigné** (PC). Pendant une semaine, l'oiseau **mangeait** (IMP) et **dormait** (IMP) dans une petite boîte. Finalement, il **a repris** (PC) des forces et il **est parti** (PC). Nous **étions** (IMP) tristes, mais nous **savions** (IMP) que c'était mieux pour lui. »

### 3. Análise Detalhada dos Verbos

| Frase do Texto | Verbo e Tempo | Por que este tempo? | Tradução |
| :--- | :--- | :--- | :--- |
| **nous habitions** | IMP (habiter) | Descrição do cenário de vida no passado. | nós morávamos |
| **nous jouions** | IMP (jouer) | Ação habitual, que se repetia. | nós brincávamos |
| **il a trouvé** | PC (trouver) | Ação pontual e específica que aconteceu "um dia". | ele encontrou |
| **Il était** | IMP (être) | Descrição do estado do pássaro. | ele estava |
| **nous avons ramené** | PC (ramener) | Ação concreta e concluída. | nós trouxemos |
| **nous avons soigné** | PC (soigner) | Ação concreta e concluída. | nós cuidamos |
| **l'oiseau mangeait** | IMP (manger) | Ação contínua durante um período ("pendant une semaine"). | o pássaro comia |
| **il a repris** | PC (reprendre) | Ação pontual que marca uma mudança (a recuperação). | ele recuperou |
| **il est parti** | PC (partir) | Ação pontual e concluída (a partida). | ele partiu |
| **Nous étions** | IMP (être) | Descrição de um estado de espírito (tristeza). | nós estávamos |
| **nous savions** | IMP (savoir) | Estado mental, o que eles sabiam naquele contexto. | nós sabíamos |

### 4. Dica Prática: As Perguntas-Chave

Na hora de escrever, faça estas perguntas para escolher o tempo correto:

-   **Usa o IMPARFAIT se...**
    - A ação era uma **rotina/hábito**? (`tous les jours, toujours, souvent`)
    - Estou **descrevendo** algo (pessoas, lugares, estados físicos ou emocionais)?
    - A ação **estava em andamento** quando outra a interrompeu?

-   **Usa o PASSÉ COMPOSÉ se...**
    - A ação é **única e terminada**? (`un jour, soudain, finalement`)
    - Ela **muda a situação** ou avança a história?
    - A ação aconteceu um **número específico de vezes**?

### 5. Exercício de Aplicação

Complete o parágrafo abaixo com o passé composé ou o imparfait dos verbos entre parênteses.

Quand je _______ (être) enfant, je _______ (adorer) aller à la plage. Un été, mes parents me _______ (emmener) en vacances en Bretagne. Il _______ (faire) beau et le soleil _______ (briller). Un jour, je _______ (trouver) un coquillage magnifique. Je le _______ (rapporter) à la maison comme souvenir.

**Correção:**
-   `étais` (IMP - descrição de um estado no passado)
-   `adorais` (IMP - hábito no passado)
-   `ont emmené` (PC - ação pontual e concluída)
-   `faisait` (IMP - descrição do tempo)
-   `brillait` (IMP - descrição de uma ação contínua)
-   `ai trouvé` (PC - ação única e específica)
-   `ai rapporté` (PC - ação concluída que segue o evento anterior)

**Próximo Passo:** Para dominar, **escreva**. Tente redigir um pequeno parágrafo sobre uma lembrança da sua infância, usando ambos os tempos. Descreva o cenário (imparfait) e narre os eventos específicos que aconteceram (passé composé).