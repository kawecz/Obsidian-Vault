---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Le Pronom Tonique | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/ew2VPQdHEAA?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---

> [!abstract] Os Pronomes Tônicos em Francês
> Esta aula aborda os pronomes tônicos em francês, que são usados para dar ênfase, fazer oposição, após preposições e em respostas curtas. Eles não possuem um equivalente direto em português na maneira como são utilizados, sendo uma particularidade importante da língua francesa para soar mais natural.

### [[aula2.pdf]]

---
### 📘 Tópicos da Aula
1.  O que são os Pronomes Tônicos e sua lista.
2.  Aplicações: ênfase, oposição e após preposições.
3.  Uso em respostas curtas e com o verbo `être`.
4.  Diferença entre pronomes pessoais e pronomes tônicos.

### 📖 Conteúdo Detalhado

#### Lista dos Pronomes Tônicos

| Pronome Pessoal | Pronome Tônico | Exemplo de Uso (Com Tradução) |
| :--- | :--- | :--- |
| Je | **Moi** | **Moi**, j'aime danser. (**Eu**, gosto de dançar.) |
| Tu | **Toi** | Et **toi**? (E **você**?) |
| Il | **Lui** | **Lui**, il est professeur. (**Ele**, é professor.) |
| Elle | **Elle** | **Elle**, elle n'aime pas travailler. (**Ela**, ela não gosta de trabalhar.) |
| Nous | **Nous** | Ils vont au cinéma avec **nous**. (Eles vão ao cinema conosco.) |
| Vous | **Vous** | C'est pour **vous**. (Isto é para **vocês**/o senhor/a senhora.) |
| Ils/Elles | **Eux** / **Elles** | Mes parents? **Eux** sont gentils. (Meus pais? **Eles** são gentis.) |

#### Aplicações dos Pronomes Tônicos

| Contexto de Uso | Explicação | Exemplo em Francês | Tradução para Português |
| :--- | :--- | :--- | :--- |
| **Ênfase/Reforço** | Para reforçar ou destacar o sujeito da frase. | **Moi**, je déteste le froid. | **Eu** detesto o frio. |
| **Oposição** | Para contrastar ou opor duas pessoas ou coisas. | **Lui** aime les chiens, et **elle** aime les chats. | **Ele** gosta de cachorros, e **ela** gosta de gatos. |
| **Após Preposições** | São obrigatórios após preposições como `pour` (para), `avec` (com), `chez` (na casa de). | Ce cadeau est **pour toi**. | Este presente é **para você**. |
| | | Je vais au cinéma **avec lui**. | Eu vou ao cinema **com ele**. |
| | | Nous allons **chez elle**. | Nós vamos **para a casa dela**. |
| **Respostas Curtas** | Usados sozinhos para responder perguntas. | Qui a fait ça? - **Lui**. | Quem fez isso? - **Ele**. |
| **Com o Verbo `Être`** | Usados com `c'est` (é) para identificar pessoas. | C'est **moi**. | Sou **eu**. |

**Observação Importante:** O uso dos pronomes tônicos em francês é frequente e não tem uma tradução literal e direta para o português. Evite traduzir ao pé da letra. O objetivo principal é dar ênfase e clareza ao se referir a alguém.

### 📚 Categorização de Palavras-Chave

#### Pronomes Tônicos
*   **Moi** (eu)
*   **Toi** (tu/você)
*   **Lui** (ele)
*   **Elle** (ela)
*   **Nous** (nós)
*   **Vous** (vocês/o senhor/a senhora)
*   **Eux** (eles)
*   **Elles** (elas)

#### Preposições Comuns que Exigem o Tônico
*   **Pour** (para)
*   **Avec** (com)
*   **Chez** (na casa de)
*   **Sans** (sem)
*   **Devant** (na frente de)

#### Dica de Prática
Para praticar, crie frases fazendo oposições. Por exemplo: "Eu adoro dançar, ela adora cantar" (**Moi**, j'adore danser, **elle** adore chanter).