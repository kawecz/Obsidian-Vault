---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Courses Alimentaires | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/EATskS1_N_M?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Vocabulário de Compras e Alimentos em Francês

**Visão Geral:** Esta aula foca no vocabulário essencial para fazer compras em francês, abrangendo tipos de estabelecimentos, alimentos básicos, quantidades e como estruturar uma lista de compras. A pronúncia correta é crucial, pois muitas palavras diferem significativamente do português.

### [[aula13.pdf]]

---

### 1. Estabelecimentos Comerciais (Les Commerces)

| Francês          | Pronúncia Aproximada | Tradução         | Exemplo de Uso (Francês)      | Tradução do Exemplo            |
| ---------------- | --------------------- | ---------------- | ----------------------------- | ------------------------------ |
| **Le marché**    | (lë mar-chê)          | O mercado        | `Je vais au marché.`          | Vou ao mercado.                |
| **La boulangerie** | (la bu-lan-jer-ri)    | A padaria        | `Une baguette, s'il vous plaît.` | Uma baguete, por favor.        |
| **La pâtisserie** | (la pa-tis-ri)        | A confeitaria    | `J'aime la pâtisserie.`       | Gosto da confeitaria.          |
| **La boucherie** | (la bush-ri)          | O açougue        | `Je vais à la boucherie.`     | Vou ao açougue.                |
| **La charcuterie** | (la shar-ku-tri)      | A loja de frios  | `C'est une charcuterie.`      | É uma loja de frios.           |
| **Le supermarché** | (lë sü-per-mar-chê)   | O supermercado   | `Au supermarché`              | No supermercado                |

### 2. Alimentos Básicos (Les Aliments de Base)

#### 2.1. Frutas (Les Fruits)

| Francês        | Pronúncia Aproximada | Tradução     |
| -------------- | --------------------- | ------------ |
| **La pomme**   | (la pôm)              | A maçã       |
| **La banane**  | (la ba-nan)           | A banana     |
| **L'orange** (f) | (lo-ranj)             | A laranja    |
| **La cerise**  | (la se-riz)           | A cereja     |
| **L'ananas** (m) | (la-na-nas)           | O abacaxi    |

#### 2.2. Legumes (Les Légumes)

| Francês          | Pronúncia Aproximada | Tradução       |
| ---------------- | --------------------- | -------------- |
| **La carotte**   | (la ka-rot)           | A cenoura      |
| **La tomate**    | (la to-mat)           | O tomate       |
| **La pomme de terre** | (la pôm dë ter)   | A batata       |
| **L'oignon** (m) | (lo-nion)             | A cebola       |
| **Le haricot**   | (lë a-ri-ko)          | O feijão       |

#### 2.3. Laticínios e Outros (Les Produits Laitiers et Autres)

| Francês        | Pronúncia Aproximada | Tradução       |
| -------------- | --------------------- | ------------ |
| **Le lait**    | (lë lê)               | O leite      |
| **Le fromage** | (lë fro-maj)          | O queijo     |
| **Le beurre**  | (lë ber)              | A manteiga   |
| **Les œufs**   | (lë-zö)               | Os ovos      |
| **Le sucre**   | (lë sükr)             | O açúcar     |

### 3. Carnes (Les Viandes)

| Francês        | Pronúncia Aproximada | Tradução   |
| -------------- | --------------------- | ---------- |
| **Le poulet**  | (lë pu-lê)            | O frango   |
| **Le bœuf**    | (lë böf)              | A carne bovina |
| **Le poisson** | (lë pua-son)          | O peixe    |
| **Le jambon**  | (lë jam-bon)          | O presunto |

### 4. Quantidades e Embalagens (Les Quantités et Les Emballages)

| Francês          | Pronúncia Aproximada | Tradução           | Exemplo (Francês)            |
| ---------------- | --------------------- | ------------------ | ---------------------------- |
| **Un kilo**      | (an ki-lo)            | Um quilo           | `Un kilo de pommes`          |
| **Un litre**     | (an litr)             | Um litro           | `Un litre de lait`           |
| **Une bouteille** | (ün bu-têy)           | Uma garrafa        | `Une bouteille de vin`       |
| **Un paquet**    | (an pa-kê)            | Um pacote          | `Un paquet de pâtes`         |
| **Une boîte**    | (ün buat)             | Uma lata / Caixa   | `Une boîte de conserve`      |
| **Une tranche**  | (ün tranch)           | Uma fatia          | `Une tranche de jambon`      |
| **Un morceau**   | (an mor-so)           | Um pedaço          | `Un morceau de fromage`      |

### 5. Exemplos de Listas de Compras (Exemples de Listes de Courses)

#### 5.1. Para uma Família (Pour une Famille)
- `Un kilo de riz` (Um quilo de arroz)
- `Un kilo de haricots` (Um quilo de feijão)
- `Deux litres de lait` (Dois litros de leite)
- `Une douzaine d'œufs` (Uma dúzia de ovos)

#### 5.2. Para um Casal (Pour un Couple)
- `Un paquet de riz` (Um pacote de arroz)
- `Un bouquet de brocoli` (Um maço de brócolis)
- `Un litre de lait de soja` (Um litro de leite de soja)

#### 5.3. Para uma Pessoa Solteira (Pour une Personne Célibataire)
- `Un sachet de pâtes` (Um saquinho de massa)
- `Des surgelés` (Alimentos congelados)
- `Une tablette de chocolat` (Uma barra de chocolate)

### 6. Dicas de Pronúncia e Estudo
- Pratique a pronúncia das palavras, prestando atenção aos sons nasais (ex: `an`, `on`, `in`).
- Use sites de supermercados franceses (como Carrefour ou Intermarché) para praticar o vocabulário em contexto real.
- Crie sua própria lista de compras em francês para consolidar o aprendizado.