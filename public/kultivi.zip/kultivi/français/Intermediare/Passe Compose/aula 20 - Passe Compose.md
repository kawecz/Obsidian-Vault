---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Passé Composé I | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/eOWJgt5yY3w?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>


---
## Aula: O Passado Composto (Le Passé Composé) - Parte 1

**Visão Geral:** O passé composé é o tempo verbal mais usado pelos franceses para falar de ações passadas, concluídas e pontuais. É um tempo "composto" porque é formado por um verbo auxiliar e um verbo principal no particípio passado. Dominá-lo é essencial para a comunicação no dia a dia.

### [[aula20.pdf]]

---
### 1. O Que é o Passé Composé?
- **Ação Pontual e Concluída:** Descreve uma ação específica que aconteceu e terminou no passado.
- **Uso Frequente:** É o tempo de passado mais comum na língua falada, substituindo muitas vezes o passé simple (passado simples) na linguagem informal.

### 2. Como Formar o Passé Composé
A estrutura é sempre a mesma: **Verbo Auxiliar (no presente) + Particípio Passado (Verbo Principal)**

Existem **dois verbos auxiliares**: `Avoir` (ter) e `Être` (ser/estar). A escolha do auxiliar é a primeira regra a decorar.

### 3. O Auxiliar `Avoir` (Ter)
A **maioria dos verbos** usa `Avoir` como auxiliar.

#### 3.1. Conjugação de `Avoir` no Presente
| Pronome | Conjugação |
|---------|------------|
| J'      | **ai**     |
| Tu      | **as**     |
| Il/Elle | **a**      |
| Nous    | **avons**  |
| Vous    | **avez**   |
| Ils/Elles | **ont**  |

#### 3.2. Formação do Particípio Passado (com `Avoir`)
- **Verbos terminados em `-er`:** `-er` → `-é`
  - Ex: `manger` → `mangé` (comido)
- **Verbos terminados em `-ir`:** `-ir` → `-i`
  - Ex: `finir` → `fini` (acabado/terminado)
- **Verbos Irregulares:** Devem ser decorados. São comuns.
  - Ex: `prendre` → `pris` (tomado/pego)
  - `lire` → `lu` (lido)
  - `pouvoir` → `pu` (podido)
  - `faire` → `fait` (feito)

#### 3.3. Exemplos com `Avoir`
- `J'**ai mangé** une pomme.` (Eu **comi** uma maçã.)
- `Nous **avons fini** notre travail.` (Nós **terminamos** nosso trabalho.)
- `Ils **ont pris** le train.` (Eles **pegaram** o trem.)

**Regra Importante:** Quando o auxiliar é `Avoir`, o particípio passado **NÃO** concorda em gênero e número com o sujeito. Permanece invariável.

### 4. O Auxiliar `Être` (Ser/Estar)
Um grupo específico de verbos usa `Être` como auxiliar. São, em sua maioria, verbos de movimento ou de mudança de estado.

#### 4.1. Conjugação de `Être` no Presente
| Pronome | Conjugação |
|---------|------------|
| Je      | **suis**   |
| Tu      | **es**     |
| Il/Elle | **est**    |
| Nous    | **sommes** |
| Vous    | **êtes**   |
| Ils/Elles | **sont** |

#### 4.2. A Lista dos Verbos que Usam `Être` (DR & MRS VANDERTRAMP)
Esta sigla ajuda a decorar os principais verbos:

- **D**evenir (tornar-se)
- **R**evenir (voltar)
- & **M**onter (subir)
- **R**ester (ficar/permanecer)
- **S**ortir (sair)
- **V**enir (vir)
- **A**ller (ir)
- **N**aître (nascer)
- **D**escendre (descer)
- **E**ntrer (entrar)
- **R**entrer (voltar para casa)
- **T**omber (cair)
- **R**etourner (retornar)
- **A**rriver (chegar)
- **M**ourir (morrer)
- **P**artir (partir)

#### 4.3. Exemplos com `Être`
- `Je **suis allé(e)** au marché.` (Eu **fui** ao mercado.)
- `Elle **est née** en juin.` (Ela **nasceu** em junho.)
- `Ils **sont partis** tôt.` (Eles **partiram** cedo.)

**Regra Crucial:** Quando o auxiliar é `Être`, o particípio passado **CONCORDA** em gênero e número com o sujeito.

| Gênero/Número | Acordo | Exemplo (Aller) |
|---------------|--------|-----------------|
| Masculino Singular | Sem acréscimo | `Il **est allé**.` |
| Feminino Singular | + **e** | `Elle **est allée**.` |
| Masculino Plural | + **s** | `Ils **sont allés**.` |
| Feminino Plural | + **es** | `Elles **sont allées**.` |

### 5. Verbos Pronominais (Reflexivos)
**Todos os verbos pronominais** (ex: se laver, se lever, s'habiller) usam `Être` como auxiliar no passé composé.

- `Je **me suis lavé(e)**.` (Eu **lavei-me**.)
- `Nous **nous sommes habillé(e)s**.` (Nós **vestimo-nos**.)

**O acordo** do particípio passado nos verbos pronominais segue regras específicas, mas de modo geral, concorda com o sujeito se o verbo for seguido de um complemento direto.

### 6. Dica de Pronúncia
- `J'ai` soa como "Jê".
- `Je suis` soa como "Jê sui".
- Pratique a conjugação de `avoir` e `être` até que se torne automática.