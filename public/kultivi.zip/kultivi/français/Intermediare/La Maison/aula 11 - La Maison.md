---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - La Maison | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/3DqmqkQ2uzo?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## 🇫🇷 Aula de Francês: Habitação e Aluguel (_L'habitation et le loyer_)

### 🎯 Visão Geral da Aula

Esta lição (Curso #28) foca em expandir o vocabulário essencial para descrever onde você mora, as divisões da casa (_les pièces de la maison_), os móveis (_les meubles_), e a linguagem básica para **alugar** um apartamento.

### [[aula11.pdf]]
---

### 1️⃣ Descrevendo Onde Você Mora

|Pergunta Comum|Resposta Comum|Tradução (PT-BR)|
|---|---|---|
|**Où habitez-vous ?**|**J'habite...**|Onde você mora?|
|**J'habite dans...**|**... une maison.**|Numa casa.|
||**... un appartement.**|Num apartamento.|
||**... une résidence universitaire.**|Numa residência universitária.|
|**Andares**|**Au rez-de-chaussée**|No térreo (andar de baixo).|
||**Au premier étage**|No primeiro andar.|
||**Au deuxième étage**|No segundo andar.|

---

### 2️⃣ As Peças da Casa (_Les Pièces de la Maison_)

#### Peças Essenciais

|Francês|Gênero|Tradução (PT-BR)|Função Principal|
|---|---|---|---|
|**La cuisine**|Fem.|Cozinha|Onde se cozinha e come.|
|**La chambre**|Fem.|Quarto|Onde se dorme.|
|**Le salon**|Masc.|Sala de estar|Onde se assiste TV/recebe.|
|**La salle de bains**|Fem.|Banheiro (completo)|Onde se toma banho.|
|**Les toilettes**|Fem. Pl.|Vaso sanitário|Apenas o cômodo com o vaso (diferente de _salle de bains_ na França).|
|**Le bureau**|Masc.|Escritório|Onde se estuda/trabalha.|
|**Le garage**|Masc.|Garagem|Onde se guarda o carro.|

#### Outras Peças Importantes

|Francês|Gênero|Tradução (PT-BR)|
|---|---|---|
|**La salle à manger**|Fem.|Sala de jantar|
|**Le balcon**|Masc.|Sacada|
|**La terrasse**|Fem.|Terraço|
|**Le couloir**|Masc.|Corredor|
|**L'escalier**|Masc.|Escada|
|**La cave**|Fem.|Porão, adega|
|**L'entrée**|Fem.|Entrada|

---

### 3️⃣ Móveis e Objetos (_Les Meubles et Objets_)

|Local|Francês|Tradução (PT-BR)|
|---|---|---|
|**Cozinha**|**Les placards**|Armários (de parede)|
||**Le micro-ondes**|Micro-ondas|
||**Le frigo** (ou _réfrigérateur_)|Geladeira|
||**La cuisinière**|Fogão|
||**Le four**|Forno|
||**La table à manger**|Mesa de jantar|
||**La casserole**|Panela|
|**Banheiro**|**La baignoire**|Banheira|
||**La douche**|Chuveiro|
||**Le lavabo**|Pia|
||**Le miroir**|Espelho|
|**Quarto**|**Le lit**|Cama|
||**La fenêtre**|Janela|
||**Le réveil**|Despertador|
||**L'armoire** (ou _placard_)|Armário (para roupas)|
||**Le tapis**|Tapete|
||**La lampe**|Abajur/Luminária|
||**La commode**|Cômoda|
|**Sala de Estar**|**Le canapé**|Sofá|
||**La télé** (ou _télévision_)|TV|
||**Le fauteuil**|Poltrona|
||**Les rideaux**|Cortinas|
|**Escritório**|**La bibliothèque**|Estante/Biblioteca|
||**La chaise**|Cadeira|
||**L'ordinateur**|Computador|

---

### 4️⃣ Simulação de Aluguel (_Louer un Appartement_)

|Pergunta/Frase (Francês)|Tradução (PT-BR)|Explicação do Termo|
|---|---|---|
|**Je voudrais visiter l'appartement que vous louez.**|Eu gostaria de visitar o apartamento que vocês alugam.|**Louer** (verbo: alugar)|
|**Combien coûte le loyer ?**|Quanto custa o aluguel?|**Le loyer** (substantivo: aluguel)|
|**C'est 300 euros, charges comprises.**|São 300 euros, taxas inclusas.|**Charges comprises:** Inclui condomínio, água, às vezes aquecimento.|
|**Exigez-vous une caution ?**|Vocês exigem um calção?|**Une caution:** Valor adiantado para segurança (geralmente um mês de aluguel).|
|**Quelle est la date pour payer le loyer ?**|Qual é a data para pagar o aluguel?||
|**Il doit être payé jusqu'au 5ème jour du mois.**|Ele deve ser pago até o 5º dia do mês.||
|**Cet appartement est-il meublé ?**|Este apartamento é mobiliado?|**Meublé:** Já contém móveis essenciais.|

---

### 5️⃣ Devoir (Lição de Casa)

Para fixar este vocabulário:

1. **Descreva seu local de residência:** Escreva 5 frases em francês descrevendo onde você mora, quantos andares tem, e quais são suas peças favoritas. (Ex: _J'habite dans une maison. Il y a un salon et une petite cuisine._)
    
2. **Explore sites de móveis:** Visite sites franceses como **IKEA France** ou **Conforama** para ver imagens e associar o vocabulário de móveis (_meubles_) diretamente com os objetos.
