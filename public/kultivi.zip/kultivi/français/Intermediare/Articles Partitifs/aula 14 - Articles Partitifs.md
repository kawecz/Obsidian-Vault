---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Articles Partitifs | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/k-I1Vrooapw?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Os Artigos Partitivos (Les Articles Partitifs)

**Visão Geral:** Esta aula introduz um conceito único do francês: os **artigos partitivos**. Eles são usados para expressar quantidades indeterminadas, especialmente com coisas que não podem ser contadas (como líquidos, conceitos abstratos ou massas). Não existe um equivalente direto em português, onde geralmente omitimos o artigo nesses casos.

### [[aula14.pdf]]

---
### 1. O Que São os Artigos Partitivos?
Usamos os artigos partitivos para nos referirmos a uma **parte** de um todo, uma **quantidade indeterminada** de algo.
- **Em Português:** "Eu bebo água", "Como pão".
- **Em Francês:** SEMPRE se usa o artigo: `Je bois **de l'eau**`, `Je mange **du pain**`.

### 2. Formas dos Artigos Partitivos
A forma muda de acordo com o gênero e número do substantivo, e também com a inicial da palavra que segue.

| Artigo Partitivo | Uso                                  | Exemplo (Francês)        | Tradução (Português)     |
| ---------------- | ------------------------------------ | ------------------------ | ------------------------ |
| **Du**           | Antes de substantivo **masculino singular** começando com consoante. | `Je mange **du** pain.`  | Eu como pão.             |
| **De la**        | Antes de substantivo **feminino singular** começando com consoante. | `Je bois **de la** soupe.` | Eu bebo sopa.            |
| **De l'**        | Antes de **qualquer substantivo singular** começando com vogal ou "H" mudo. | `Je bois **de l'**eau.`<br>`J'ai **de l'**argent.` | Eu bebo água.<br>Eu tenho dinheiro. |
| **Des**          | Antes de **qualquer substantivo no plural**. | `Je mange **des** légumes.` | Eu como legumes.         |
### 3. Casos de Uso dos Artigos Partitivos

#### 3.1. Com Alimentos e Bebidas (Quantidade Indeterminada)
- `Je veux **du** fromage.` (Eu quero queijo.)
- `Elle achète **de la** confiture.` (Ela compra geleia.)
- `Nous prenons **de l'**huile.` (Nós usamos azeite.)

#### 3.2. Com Conceitos Abstratos ou Coisas Incontáveis
- `Il faut **de la** patience.` (É preciso paciência.)
- `J'ai **de l'**énergie.` (Eu tenho energia.)
- `Elle a **du** courage.` (Ela tem coragem.)

#### 3.3. Para Expressar "Um Pouco de" (`un peu de`)
Para quantidades ainda mais vagas, usa-se `un peu de` (um pouco de). O artigo partitivo some.
- `Je veux **un peu de** fromage.` (Eu quero um pouco de queijo.)
- `Ajoute **un peu d'**huile.` (Adiciona um pouco de azeite.)

### 4. A Negação com Artigos Partitivos
Na negação, os artigos partitivos (`du, de la, de l', des`) são substituídos por **`de`** (ou **`d'`** antes de vogal).

| Afirmativa                          | Negativa                                |
| ----------------------------------- | --------------------------------------- |
| `Je mange **du** pain.`             | `Je **ne** mange **pas de** pain.`      |
| (Eu como pão.)                      | (Eu **não** como pão.)                  |
| `Il boit **de l'**eau.`             | `Il **ne** boit **pas d'**eau.`         |
| (Ele bebe água.)                    | (Ele **não** bebe água.)                |
| `Nous avons **des** amis.`          | `Nous **n'**avons **pas d'**amis.`      |
| (Nós temos amigos.)                 | (Nós **não** temos amigos.)             |

### 5. Artigo Partitivo vs. Artigo Indefinido
É crucial não confundir. O partitivo é para massas/incontáveis; o indefinido é para coisas contáveis.

| Artigo | Uso                          | Exemplo (Francês)      | Tradução (Português)       |
| ------ | ---------------------------- | ---------------------- | -------------------------- |
| **Partitivo (Du)** | Quantidade indeterminada de algo incontável. | `Je mange **du** poulet.` | Eu como (algum) frango.    |
| **Indefinido (Un)** | Um item específico e contável. | `Je mange **un** poulet.` | Eu como **um** frango (inteiro). |

### 6. Exemplo em uma Receita: Panquecas (Crêpes)
- `Mélangez **de la** farine et **des** œufs.` (Misture **a** farinha e **os** ovos.)
- `Ajoutez **du** sucre et **du** sel.` (Adicionem **o** açúcar e **o** sal.)
- `Versez **un peu d'**huile.` (Despejem **um pouco de** azeite.)
- `**Ne** mettez **pas de** beurre.` (**Não** coloquem manteiga.)

### 7. Exercícios Práticos

1.  **Complete com o artigo partitivo correto (`du`, `de la`, `de l'`, `des`):**
    - `Je veux _____ lait.` (Eu quero leite.)
    - *`du`* (`lait` é masculino singular)
    - `Elle écoute _____ musique.` (Ela escuta música.)
    - *`de la`* (`musique` é feminino singular)
    - `Nous achetons _____ fruits.` (Nós compramos frutas.)
    - *`des`* (`fruits` é plural)

2.  **Passe para a forma negativa:**
    - `Il fait du sport.`
    - *`Il **ne** fait **pas de** sport.`*
    - `J'ai de la chance.`
    - *`Je **n'**ai **pas de** chance.`*

**Dica Final:** A regra de ouro é: em frases afirmativas, para quantidades indeterminadas de coisas incontáveis, **sempre use o artigo partitivo**. Na negativa, ele se transforma em `de/d'`. Pratique criando listas de compras ou descrevendo suas refeições.