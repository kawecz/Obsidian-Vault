---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Poser des Questions | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/vrnYS6fPe1s?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: A Forma Interrogativa e Palavras Interrogativas em Francês

**Visão Geral:** Esta aula aborda a estrutura das perguntas (forma interrogativa) em francês, apresentando os diferentes estilos (formal, comum e informal) e as principais palavras interrogativas. Diferente do português, o francês possui estruturas específicas e variações de formalidade para fazer questionamentos.

### [[aula12.pdf]]

---

### 1. As Três Formas de Fazer Perguntas

#### 1.1. Forma Formal (Inversão Sujeito-Verbo)
- **Uso:** Linguagem escrita, situações formais.
- **Estrutura:** Verbo + hífen + pronome sujeito.
- **Exemplo:**
    - `Vous appelez` (Afirmativa) → `Appelez-vous ?` (Interrogativa)
    - Tradução: "Você se chama?" / "Como você se chama?"

#### 1.2. Forma Comum/Coloquial (``Est-ce que``)
- **Uso:** Forma mais frequente no dia a dia.
- **Estrutura:** `Est-ce que` + frase na ordem afirmativa.
- **Exemplo:**
    - `Est-ce que tu parles français ?`
    - Tradução: "Você fala francês?"

#### 1.3. Forma Informal (Entonação)
- **Uso:** Conversas informais.
- **Estrutura:** Ordem afirmativa da frase, mudando apenas a entonação para interrogativa.
- **Exemplo:**
    - `Tu viens ?`
    - Tradução: "Você vem?"

### 2. Palavras Interrogativas Principais (Pronoms Interrogatifs)

| Palavra   | Tradução        | Uso / Contexto                                 | Exemplo (Francês)                     | Tradução (Português)             |
| --------- | --------------- | ---------------------------------------------- | ------------------------------------- | -------------------------------- |
| **Qui**   | Quem            | Pergunta sobre pessoas.                        | `Qui est ta mère ?`                   | Quem é sua mãe?                  |
| **Que**   | O que           | Pergunta sobre coisas ou ações.                | `Que fais-tu ?`                       | O que você está fazendo?         |
| **Quoi**  | O que (informal) | Usado no final da frase, no registro informal. | `Tu fais quoi ?`                      | Você está fazendo o que?         |
| **Où**    | Onde            | Pergunta sobre lugares.                        | `Où est la bibliothèque ?`            | Onde é a biblioteca?             |
| **Quand** | Quando          | Pergunta sobre tempo.                          | `Quand partez-vous ?`                 | Quando vocês partem?             |
| **Pourquoi** | Por que        | Pergunta sobre razões ou causas.               | `Pourquoi riez-vous ?`                | Por que vocês riem?              |
| **Comment** | Como           | Pergunta sobre maneira ou estado.              | `Comment allez-vous ?`                | Como você está?                  |
| **Combien** | Quanto         | Pergunta sobre quantidade (incontável) ou preço. | `Combien ça coûte ?`                | Quanto custa isso?               |

### 3. Palavras Interrogativas com Preposições

| Combinação     | Tradução        | Uso / Contexto                                   | Exemplo (Francês)           | Tradução (Português)       |
| -------------- | --------------- | ------------------------------------------------ | --------------------------- | -------------------------- |
| **De qui**     | De quem         | Pergunta sobre posse ou origem (pessoa).         | `De qui est ce livre ?`     | De quem é este livro?      |
| **À qui**      | A quem          | Pergunta sobre destinatário.                     | `À qui parlez-vous ?`       | Com quem você está falando?|
| **Avec qui**   | Com quem        | Pergunta sobre companhia.                        | `Avec qui voyages-tu ?`     | Com quem você viaja?       |
| **Pour qui**   | Para quem       | Pergunta sobre destinatário de uma ação.         | `Pour qui est ce cadeau ?`  | Para quem é este presente? |

### 4. O Caso Especial de ``Quel`` (Qual)
- **Função:** Equivale a "Qual" ou "Quais" em português.
- **Característica:** Deve concordar em gênero e número com o substantivo a que se refere.

| Forma (m=f) | Tradução   | Exemplo (Francês)                  | Tradução (Português)        |
| ----------- | ---------- | ---------------------------------- | --------------------------- |
| **Quel**    | Qual (m.s.)| `Quel est ton problème ?`          | Qual é o seu problema?      |
| **Quelle**  | Qual (f.s.)| `Quelle est ta question ?`         | Qual é a sua pergunta?      |
| **Quels**   | Quais (m.p.)| `Quels sont tes hobbies ?`        | Quais são os seus hobbies?  |
| **Quelles** | Quais (f.p.)| `Quelles sont ces fleurs ?`       | Quais são estas flores?     |

### 5. Pontuação nas Interrogações
- No francês, sempre se coloca um **espaço** antes do ponto de interrogação (`?`) e de exclamação (`!`).
- **Exemplo:** `Comment ça va ?` (e não `Comment ça va?`)

### 6. Exercícios Práticos

1.  **Traduza para o francês (use a forma comum `Est-ce que`):**
    - "Onde você mora?"
    - *`Est-ce que tu habites où ?`*
2.  **Complete com a palavra interrogativa correta:**
    - `______ est ton anniversaire ?` (Quando é o seu aniversário?)
    - *`Quand`*
3.  **Escreva a pergunta usando a inversão formal:**
    - "Por que ele trabalha aqui?"
    - *`Pourquoi travaille-t-il ici ?`*
4.  **Escolha a forma correta de `Quel`:**
    - "Quais são os seus filmes favoritos?" (filmes = masculino plural)
    - *`Quels sont tes films préférés ?`*

**Dica Final:** A forma mais segura para iniciantes é usar `Est-ce que`. Pratique a inversão para a escrita formal e preste muita atenção à concordância de `Quel`.