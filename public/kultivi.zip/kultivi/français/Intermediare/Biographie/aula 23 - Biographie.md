---
banner: https://kultivi.com/wp-content/uploads/2018/12/pp.jpg
tags:
  - intermediare
  - kultivi-frances
---

---
<iframe title="Francês | Kultivi - Biographie | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/ZOfTeQJHhdo?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
## Aula: Como Escrever uma Biografia em Francês

**Visão Geral:** Esta aula ensina a estruturar uma biografia (biographie) em francês, utilizando os tempos verbais adequados para narrar a vida de uma pessoa, como o passé composé para ações pontuais e o imparfait para descrições e ações contínuas no passado.

### [[aula23.pdf]]

---
### 1. Elementos de uma Biografia
Uma biografia deve conter informações essenciais sobre a identidade, família, trajetória e eventos marcantes da pessoa.

### 2. Estrutura e Vocabulário Chave

#### 2.1. Identidade e Informações Pessoais
- **Nome e Profissão:**
    - `Victor Hugo est un écrivain français.` (Victor Hugo é um escritor francês.)
    - `Emmanuel Macron est un homme d'État français.` (Emmanuel Macron é um homem de estado francês.)
- **Nascimento e Morte:**
    - `Il est né le 26 février 1802 à Besançon, en France.` (Ele nasceu em 26 de fevereiro de 1802 em Besançon, na França.)
    - `Elle est morte le 15 septembre 2020.` (Ela morreu em 15 de setembro de 2020.)

#### 2.2. Família
- `Il est le fils de...` (Ele é filho de...)
- `Elle était la femme de...` (Ela era a esposa de...)
- `Il est le père de deux enfants.` (Ele é pai de dois filhos.)

#### 2.3. Trajetória e Formação (Parcours)
- **Formação Acadêmica:**
    - `Il a étudié la philosophie à l'université.` (Ele estudou filosofia na universidade.)
- **Carreira Profissional:**
    - `Il a travaillé comme haut fonctionnaire.` (Ele trabalhou como alto funcionário.)
    - `Il était professeur.` (Ele era professor.)

#### 2.4. Eventos Importantes (Événements Importants)
- `Il a publié son premier livre en 1952.` (Ele publicou seu primeiro livro em 1952.)
- `Il a fondé son parti politique en 2016.` (Ele fundou seu partido político em 2016.)
- `Ils ont rencontré l'amour de leur vie.` (Eles encontraram o amor da vida deles.)

### 3. Traços de Caráter (Traits de Caractère)
Descrever a personalidade é crucial para dar vida à biografia.

| Traço de Caráter (Masculino) | Traço de Caráter (Feminino) | Tradução |
| :--- | :--- | :--- |
| **Patient** | **Patiente** | Paciente |
| **Compétent** | **Compétente** | Competente |
| **Passionné** | **Passionnée** | Apaixonado |
| **Autoritaire** | **Autoritaire** | Autoritário |
| **Chaleureux** | **Chaleureuse** | Acolhedor/Afetuoso |
| **Curieux** | **Curieuse** | Curioso |
| **Heureux** | **Heureuse** | Feliz |
| **Froid** | **Froide** | Frio |
| **Égoïste** | **Égoïste** | Egoísta |

**Exemplos:**
- `Il était un homme passionné et compétent.` (Ele era um homem apaixonado e competente.)
- `Elle est une femme autoritaire et froide.` (Ela é uma mulher autoritária e fria.)

### 4. Uso dos Tempos Verbais na Biografia
A escolha do tempo verbal depende do contexto da ação.

| Tempo Verbal | Uso na Biografia | Exemplo |
| :--- | :--- | :--- |
| **Passé Composé** | Ações pontuais e concluídas no passado. | `Il **a publié** son livre.` (Ele publicou seu livro.) |
| **Imparfait** | Descrições, hábitos e ações contínuas no passado. | `Quand il était jeune, il **aimait** la musique.` (Quando era jovem, ele gostava de música.) |
| **Présent** | Fatos atuais ou estados permanentes (mesmo em vidas passadas). | `Ses romans **sont** célèbres.` (Seus romances são famosos.) |

### 5. Exemplo Prático: Biografia de Victor Hugo
**Texte:**
« Victor Hugo est un poète, romancier et dramaturge français. Il est né le 26 février 1802 à Besançon. Il est sans conteste un géant de la littérature française. Ses romans les plus connus sont *Notre-Dame de Paris* et *Les Misérables*. Il écrivait avec simplicité et puissance les bonheurs et malheurs de la vie. Il est mort à Paris le 23 mai 1885. Plus de trois millions de personnes ont assisté à ses funérailles. »

**Análise:**
- **Présent:** `est` (para estado permanente/fato histórico), `sont` (fato atual sobre sua obra).
- **Passé Composé:** `est né`, `est mort`, `ont assisté` (ações pontuais e concluídas).
- **Imparfait:** `écrivait` (ação contínua/no decorrer do tempo no passado, descrevendo seu estilo).

### 6. Exercício Prático
Escreva uma pequena biografia de uma pessoa famosa que você admira, usando o vocabulário e a estrutura aprendidos. Inclua:
1.  Identidade e nascimento.
2.  Trajetória profissional.
3.  Um evento importante.
4.  Um traço de caráter.

**Exemplo (Ronaldo Fenômeno):**
`Ronaldo Luís Nazário de Lima est un ancien footballeur brésilien. Il est né le 18 septembre 1976 à Rio de Janeiro. Il a joué pour des grands clubs comme le FC Barcelone et le Real Madrid. Il a gagné la Coupe du Monde en 2002 avec l'équipe du Brésil. Il était un joueur passionné et très compétent.`

**Dica Final:** Para praticar, leia biografias em sites franceses (como a Wikipédia em francês) e observe o uso dos tempos verbais. Isso ajudará a internalizar as estruturas corretas.