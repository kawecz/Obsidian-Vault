---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Alquilar un Piso II | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/CrR0Y7jKqEI?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

[[ALQUILARUNPISOII.pdf]]

---
# AULA DE ESPANHOL: ALUGAR UM APARTAMENTO (PARTE 2)

---

## Introdução da Aula

Esta segunda parte da aula sobre "Alugar um Apartamento" aprofunda o vocabulário e a gramática descritiva. O foco é a **descrição de uma moradia** (piso), a **concordância entre substantivos e adjetivos** e, crucialmente, o estudo dos **Artigos Determinados** (_el, la, los, las_) e suas **Contrações** com preposições (_al, del_).

---

## 1. Descrição de uma Moradia (Describir una Vivienda)

Um e-mail é usado como base para extrair características de um apartamento, introduzindo novos vocabulários e conceitos descritivos.

### A. Análise do Diálogo (E-mail de Pablo para Juan)

O e-mail descreve um apartamento em Barcelona, destacando:

|Característica|Espanhol|Tradução e Contexto|
|---|---|---|
|**Piso**|_Piso_|Usado como **andar** (primeiro piso) e **apartamento**.|
|**Ambiente**|_Ruidosos_|Barulhentos (os vizinhos).|
|**Estrutura**|_Paredes de papel_|Paredes finas (expressão idiomática, como "paredes de papel").|
|**Comodidade**|_Caluroso_|Quente, caloroso (relacionado à temperatura ou clima).|
|**Vantagem**|_El olor a pan_|O cheiro de pão (vantagem de ter uma padaria próxima).|
|**Despedida**|_Hasta pronto_|Até logo (usado ao se despedir de um amigo).|

### B. Concordância de Adjetivos (Masculino/Feminino, Singular/Plural)

Para descrever uma casa, o adjetivo deve **concordar** em **gênero** (masculino/feminino) e **número** (singular/plural) com o substantivo.

|Substantivo|Gênero e Número|Adjetivos Aplicáveis|
|---|---|---|
|**Piso / Apartamento**|Masculino, Singular|_Antiguo, grande, ruidoso, bonito, moderno, feo, caluroso._|
|**Casa / Vivienda**|Feminino, Singular|_Antigua, grande, ruidosa, bonita, moderna, fea, calurosa._|
|**Vecinos**|Masculino, Plural|_Ruidosos._|
|**Ventanas**|Feminino, Plural|_Grandes._|
|**Dormitorio**|Masculino, Singular|_Grande._|

---

## 2. Artigos Determinados e Contrações

Os artigos determinados são as palavras que vêm antes dos substantivos para especificar algo ("o", "a", "os", "as" em português).

### A. Artigos Determinados (El, La, Los, Las)

|Gênero|Singular|Plural|Exemplo de Uso|
|---|---|---|---|
|**Masculino** (O, Os)|**El**|**Los**|**El** profesor, **los** profesores|
|**Feminino** (A, As)|**La**|**Las**|**La** profesora, **las** profesoras|

> **Observação:** Não se deve confundir **"El"** (artigo, masculino, singular) com **"L"** (a letra) ou com **"él"** (pronome pessoal, com acento).

### B. Contrações com Preposições (Al e Del)

Em espanhol, a união de preposição + artigo ocorre **apenas** no caso do masculino singular (**A** + **EL** e **DE** + **EL**).

|Contração|Preposição + Artigo|Equivalente (Português)|Uso|
|---|---|---|---|
|**AL**|**A + EL**|Ao|_Voy **al** mercado._ (Eu vou ao mercado)|
|**DEL**|**DE + EL**|Do|_Al lado **del** mercado._ (Ao lado do mercado)|

> **Regra Crucial:** Em espanhol, **NÃO** existem contrações no feminino singular ou nos plurais (feminino e masculino). O artigo e a preposição permanecem **separados**.
> 
> - **Exemplo Feminino:** "Eu vou **à** padaria" ![](data:,) _Voy **a la** panadería._ (Não é "ala")
>     
> - **Exemplo Plural:** "Eu sou **dos** Estados Unidos" ![](data:,) _Soy **de los** Estados Unidos._ (Não é "delos")
>     

---

# VOCABULÁRIO E CLASSES GRAMATICAIS DA AULA

## Substantivos (Sustantivos / Nouns)

|Substantivo (Espanhol)|Tradução (Português)|
|---|---|
|**Clase / Curso**|Aula / Curso|
|**Piso / Apartamento**|Apartamento / Andar|
|**Correo Electrónico / Email**|Correio Eletrônico / Email|
|**Ciudad / Barcelona**|Cidade / Barcelona|
|**Foto / Dirección**|Foto / Endereço|
|**Vecinos / Ruido**|Vizinhos / Barulho|
|**Paredes / Papel**|Paredes / Papel|
|**Profesor / Panadería**|Professor / Padaria|
|**Habitación / Salón / Cocina**|Quarto / Sala / Cozinha|
|**Temperatura / Clima / Calor**|Temperatura / Clima / Calor|
|**Ventaja / Olor / Pan**|Vantagem / Cheiro / Pão|
|**Mañana**|Manhã|
|**Respuestas / Preguntas**|Respostas / Perguntas|
|**Ejercicios / Palabras**|Exercícios / Palavras|
|**Artículos Determinados**|Artigos Determinados|

## Adjetivos (Adjetivos / Adjectives)

|Adjetivo (Espanhol)|Tradução (Português)|
|---|---|
|**Ruidosos**|Barulhentos|
|**Antiguo / Antigua**|Antigo / Antiga|
|**Grande**|Grande|
|**Bonito / Bonita**|Bonito / Bonita|
|**Caluroso / Calurosa**|Quente / Caloroso|
|**Tranquila / Tranquilo**|Tranquila / Tranquilo|
|**Moderna / Feo**|Moderna / Feio|
|**Nueva**|Nova|

## Artigos, Preposições e Contrações

|Palavra (Espanhol)|Classificação|Tradução|
|---|---|---|
|**El / La / Los / Las**|Artigos Determinados|O / A / Os / As|
|**A**|Preposição|A|
|**De**|Preposição|De|
|**Con**|Preposição|Com|
|**Al**|Contração (A + El)|Ao|
|**Del**|Contração (De + El)|Do|
|**Hasta**|Preposição|Até|
|**Acerca de**|Locução Prepositiva|A respeito de|
|**Por eso**|Locução Adverbial|Por isso|
|**También**|Advérbio|Também|