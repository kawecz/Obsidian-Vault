---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Alquilar un Piso I | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/ZHa6MnjZghk?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

[[ALQUILARUNPISOI.pdf]]

---
# AULA DE ESPANHOL: ALUGAR UM APARTAMENTO (ALQUILAR UN PISO)

---

## Introdução da Aula

Nesta lição, o foco é o vocabulário e as estruturas gramaticais essenciais para **alugar um apartamento** (_alquilar un piso_) em espanhol. Vamos aprender a **localizar cômodos** usando o verbo **"estar"**, a perguntar e responder sobre **quantidades** utilizando **"haber"** (hay) e **"tener"**, e a dominar termos básicos de casa.

---

## Estruturas Gramaticais Chave

### 1. Localização (Verbo "Estar")

Para perguntar onde algo se encontra (posição), usa-se o verbo **"ESTAR"**. **Nunca** o verbo "SER" (como em português: "Onde _é_ a cozinha?").

|Uso|Estrutura da Pergunta|Estrutura da Resposta|
|---|---|---|
|**Perguntar**|**¿Dónde está + [o cômodo/objeto]?**|_¿Dónde **está** la cocina?_|
|**Responder**|**[O cômodo] está + [preposição de lugar]**|_La cocina **está** al lado del pasillo._|

#### Preposições e Contrações de Lugar

|Preposição de Lugar|Significado (Português)|Uso e Contração|
|---|---|---|
|**Al fondo de**|No fundo / No final de|Usa-se **"al fondo del"** (masculino) ou **"al fondo de la"** (feminino).|
|**Al lado de**|Ao lado de|Usa-se **"al lado del"** (masculino) ou **"al lado de la"** (feminino).|
|**A la izquierda de**|À esquerda de|Usa-se **"a la izquierda del"** ou **"a la izquierda de la"**.|
|**A la derecha de**|À direita de|Usa-se **"a la derecha del"** ou **"a la derecha de la"**.|

> **Contração Essencial:** A contração **"DEL"** (de + el) é obrigatória. **Não existe** contração para o feminino, mantendo-se **"DE LA"**.

### 2. Quantidade e Existência (Verbos "Haber" e "Tener")

Para perguntar sobre a quantidade de cômodos (existência) ou para expressar o que o apartamento **possui**.

|Uso|Verbo|Estrutura da Pergunta|Estrutura da Resposta|
|---|---|---|---|
|**Existência** (Há/Existe)|**Haber** (forma impessoal: **Hay**)|_¿**Cuántos** dormitorios **hay** en la casa?_|_En mi casa **hay** tres dormitorios._|
|**Possessão** (Ter)|**Tener** (conjugado)|_¿**Cuántos** dormitorios **tiene** tu piso?_|_Mi casa **tiene** tres dormitorios._|
|**Preço**|**Valer** ou **Ser**|_¿**Cuánto** **vale/es** el alquiler?_|_El alquiler **es** [valor]._|

> **Diferença:** Ao usar **"Tener"** (_Mi casa tiene..._), não se usa a preposição "en". Ao usar **"Hay"** (_En mi casa hay..._), a preposição "en" é necessária.

---

## Vocabulário do Tema

### 3. Substantivos (Sustantivos / Nouns)

|Substantivo (Espanhol)|Tradução (Português)|
|---|---|
|**Piso / Apartamento / Departamento**|Apartamento|
|**Dormitorio / Cuarto / Habitación**|Quarto / Cômodo|
|**Salón / Sala**|Sala de Estar|
|**Comedor**|Sala de Jantar|
|**Cocina**|Cozinha|
|**Baño / Cuarto de Baño / Lavabo**|Banheiro / Lavabo|
|**Pasillo**|Corredor|
|**Ventana**|Janela|
|**Fondo**|Fundo / Final|
|**Alquiler / Precio**|Aluguel / Preço|
|**Cama / Muebles**|Cama / Móveis|
|**Electrodomésticos**|Eletrodomésticos|
|**Agente Inmobiliario**|Agente Imobiliário|
|**Dueña**|Dona / Proprietária|

### 4. Adjetivos (Adjetivos / Adjectives)

|Adjetivo (Espanhol)|Tradução (Português)|
|---|---|
|**Grande / Amplio**|Grande / Amplo|
|**Pequeño**|Pequeno|
|**Derecho / Izquierdo**|Direito / Esquerdo|
|**Primero**|Primeiro|
|**Algunas**|Algumas|

### 5. Preposições e Advérbios (Preposiciones y Adverbios)

|Palavra (Espanhol)|Classificação|Tradução|
|---|---|---|
|**De**|Preposição|De|
|**A**|Preposição|A|
|**En**|Preposição|Em|
|**Con**|Preposição|Com|
|**Al / Del / De la**|Contrações / Preposição|Ao / Do / Da (fem.)|
|**Al lado de**|Locução Prepositiva|Ao lado de|
|**Al fondo de**|Locução Prepositiva|No fundo de|
|**Cuánto(s)/Cuánta(s)**|Advérbio / Adjetivo Interrogativo|Quanto(s)/Quanta(s)|
|**Donde**|Advérbio Interrogativo|Onde|