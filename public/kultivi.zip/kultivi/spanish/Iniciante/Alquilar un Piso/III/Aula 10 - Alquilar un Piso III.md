---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Alquilar un Piso III | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/I5xRtDccphE?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

[[ALQUILARUNPISOIII.pdf]]

---
# AULA DE ESPANHOL: VOCABULÁRIO DE CASA E NÚMEROS

---

## Introdução da Aula

Continuamos nossa jornada explorando o tema "Alugar um Apartamento" (_Alquilar un Piso_), com foco principal na expansão do **vocabulário de casa** e no estudo dos **números**. Trabalharemos a pronúncia de diversos cômodos, objetos e eletrodomésticos, além de estender a contagem até o número 20 e introduzir os **Números Ordinais** (_Ordinales_) com suas regras de apócope.

---

## 1. Vocabulário de Casa e Cômodos (Vocabulario de Casa y Habitaciones)

|Cômodo (Espanhol)|Tradução (Português)|Gênero|Notas Importantes|
|---|---|---|---|
|**Salón Comedor**|Sala de Estar e Jantar|Masculino (_el_)|Junção dos dois cômodos.|
|**Dormitorio / Habitación / Cuarto**|Quarto|Masculino (_el_) / Feminino (_la_)|_Habitación_ também pode significar _cômodo_.|
|**Balcón**|Sacada|Masculino (_el_)|Cuidado: não é "balcão".|
|**Terraza**|Terraço|Feminino (_la_)||
|**Despacho**|Escritório|Masculino (_el_)|Refere-se ao _cômodo_ escritório (o local de trabalho).|
|**Escalera**|Escada|Feminino (_la_)||
|**Planta**|Andar / Planta / Flor|Feminino (_la_)|Uma alternativa para _piso_ (andar).|
|**Jardín / Garage**|Jardim / Garagem|Masculino (_el_)||
|**Desván**|Sótão|Masculino (_el_)|Espaço no topo da casa (o que está _em cima_).|
|**Sótano**|Porão|Masculino (_el_)|**Falso Amigo!** É o que está _embaixo_ da casa (porão).|
|**Recibidor / Entrada**|Hall de Entrada / Entrada|Masculino (_el_) / Feminino (_la_)||
|**Planta Baja**|Térreo|Feminino (_la_)||
|**Chimenea**|Lareira|Feminino (_la_)||

---

## 2. Objetos e Móveis (Objetos y Muebles)

### A. Objetos de Quarto e Despacho

|Objeto (Espanhol)|Tradução (Português)|
|---|---|
|**Cama / Armario**|Cama / Armário|
|**Cómoda**|Cômoda|
|**Escritorio**|Escrivaninha|
|**Sábana**|Lençol|
|**Colcha / Edredón / Manta**|Colcha / Edredom / Coberta|
|**Almohada**|Travesseiro (Almofada)|
|**Percha**|Cabide|

### B. Objetos de Banheiro (Baño)

|Objeto (Espanhol)|Tradução (Português)|
|---|---|
|**Lavabo**|Pia do banheiro|
|**Ducha**|Chuveiro|
|**Bañera**|Banheira|
|**Inodoro**|Vaso sanitário|
|**Bidé**|Bidê|
|**Champú / Jabón / Crema**|Shampoo / Sabonete / Creme|
|**Toalla**|Toalha (para secar-se)|

### C. Objetos de Cozinha (Cocina)

|Objeto (Espanhol)|Tradução (Português)|
|---|---|
|**Horno / Horno Microondas**|Forno / Micro-ondas|
|**Nevera / Frigorífico**|Geladeira|
|**Fregadero**|Pia da cozinha|
|**Lavavajillas**|Máquina de lavar louça|
|**Basurero / Cubo**|Lixeira / Balde|
|**Lavadora / Secadora**|Máquina de lavar roupa / Secadora|
|**Delantal**|Avental|
|**Escoba / Plancha**|Vassoura / Ferro de passar|

### D. Objetos de Sala e Jantar (Salón y Comedor)

|Objeto (Espanhol)|Tradução (Português)|Falsos Amigos|
|---|---|---|
|**Sofá / Sillón**|Sofá / Poltrona||
|**Alfombra**|Tapete|Não é "alfombra" (tapete) em português.|
|**Cuadro / Televisión**|Quadro / Televisão||
|**Marco de foto**|Porta-retrato||
|**Equipo de música**|Equipamento de música||
|**Estantería / Teléfono**|Estante / Telefone||
|**Mesa centro / Consola**|Mesa de centro / Console||
|**Vaso**|Copo|**Falso Amigo!** Não é "vaso" sanitário.|
|**Copa**|Taça|**Falso Amigo!** Não é "copa" (armário) nem "copo".|
|**Taza / Botella**|Xícara / Garrafa||
|**Mantel**|Toalha de mesa|**Falso Amigo!** Toalha de banho é _toalla_.|
|**Servilleta**|Guardanapo||
|**Tenedor / Cuchara / Cuchillo**|Garfo / Colher / Faca||

---

## 3. Números e Ordinais

### A. Números Cardinais (10 a 20)

|Número|Espanhol|Pronúncia|
|---|---|---|
|**10**|**Diez**||
|**11-15**|Once, Doce, Trece, Catorce, Quince||
|**16-19**|Dieciséis, Diecisiete, Dieciocho, Diecinueve|Use o prefixo **"dieci-"** antes do número (Ex: _dieci_ + _seis_).|
|**20**|**Veinte**||

### B. Números Ordinais (Ordinales)

Os ordinais são usados para ordenar coisas (_primero, segundo..._) e têm regras de concordância e **apócope**.

|Número|Masculino|Feminino|
|---|---|---|
|**1º**|Primero|Primera|
|**2º**|Segundo|Segunda|
|**3º**|Tercero|Tercera|
|**4º-10º**|Cuarto a Décimo|Cuarta a Décima|

#### Regra de Apócope (Perda do "O")

Os ordinais **Primero** e **Tercero** perdem o **"-o"** final e viram **Primer** e **Tercer** quando vêm **imediatamente antes** de um substantivo **masculino singular**.

|Regra|Masculino Singular (Com Apócope)|Masculino Singular (Sem Apócope)|
|---|---|---|
|**Apócope**|**El primer** piloto / **El tercer** alumno|_Se a palavra **não** estiver logo depois:_ Juan fue **el tercero** en llegar.|
|**Feminino**|**NUNCA** muda!|**La primera** pilota (não é _primer_).|

---

## Vocabulário e Classes Gramaticais

### 4. Substantivos (Sustantivos / Nouns)

|Substantivo (Espanhol)|Tradução (Português)|
|---|---|
|**Salón Comedor / Dormitorio / Habitación / Cuarto / Balcón / Terraza / Despacho / Escalera / Planta / Jardín / Garage / Desván / Sótano / Recibidor / Entrada / Planta Baja / Chimenea / Ventana / Suelo / Pared**|Sala de Jantar / Quarto / Cômodo / Sacada / Terraço / Escritório / Escada / Andar / Jardim / Garagem / Sótão / Porão / Hall / Entrada / Térreo / Lareira / Janela / Chão / Parede|
|**Cama / Armario / Cómoda / Escritorio / Sábana / Colcha / Edredón / Manta / Almohada / Percha**|Cama / Armário / Cômoda / Escrivaninha / Lençol / Colcha / Edredom / Coberta / Travesseiro / Cabide|
|**Lavabo / Ducha / Bañera / Inodoro / Bidé / Champú / Jabón / Crema / Toalla**|Pia / Chuveiro / Banheira / Vaso sanitário / Bidê / Shampoo / Sabonete / Creme / Toalha|
|**Horno / Nevera / Fregadero / Lavavajillas / Basurero / Cubo / Lavadora / Secadora / Delantal / Escoba / Plancha**|Forno / Geladeira / Pia (cozinha) / Lava-louças / Lixeira / Balde / Lavadora / Secadora / Avental / Vassoura / Ferro de passar|
|**Sofá / Sillón / Alfombra / Cuadro / Televisión / Marco de foto / Estantería / Teléfono / Mesa centro / Consola**|Sofá / Poltrona / Tapete / Quadro / Televisão / Porta-retrato / Estante / Telefone / Mesa de centro / Console|
|**Tenedor / Cuchara / Cuchillo / Mantel / Servilleta / Vaso / Copa / Taza / Botella**|Garfo / Colher / Faca / Toalha de mesa / Guardanapo / Copo / Taça / Xícara / Garrafa|

### 5. Adjetivos e Numerais (Adjetivos y Numerales)

|Adjetivo / Numeral (Espanhol)|Tradução (Português)|
|---|---|
|**Primer / Primero / Primera**|Primeiro / Primeira|
|**Tercer / Tercero / Tercera**|Terceiro / Terceira|
|**Segundo / Cuarto... Décimo**|Segundo / Quarto... Décimo|
|**Ordinales**|Ordinais|
|**Masculino / Femenino**|Masculino / Feminino|

### 6. Preposições, Artigos e Verbos

| Palavra (Espanhol)           | Classificação        | Notas                                                |
| ---------------------------- | -------------------- | ---------------------------------------------------- |
| **El / La / Los / Las**      | Artigos Determinados | O, A, Os, As.                                        |
| **Al / Del**                 | Contrações           | Ao, Do. (Apenas com masculino singular: A+EL, DE+EL) |
| **De / A / Con / En**        | Preposições          | De, A, Com, Em.                                      |
| **Decir / Repetir / Seguir** | Verbos (Infinitivo)  | Dizer / Repetir / Seguir.                            |
| **Estar**                    | Verbo                | Estar (Para localização: _¿Dónde está?_).            |
| **Haber**                    | Verbo                | Haver / Existir (Contagem: _Hay_).                   |
| **Traer / Entender**         | Verbos (Infinitivo)  | Trazer / Entender.                                   |
| **Hay**                      | Forma Impessoal      | Há / Existe.                                         |