---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Alquilar un Piso V | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/nUNtwCu5i2o?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

[[ALQUILARUNPISOV.pdf]]

---
# LA BOCA: UM BAIRRO COLORIDO EM BUENOS AIRES 🇦🇷

---

## Introdução: Conhecendo o Bairro de La Boca

Esta aula finaliza o tema da casa e apartamento com uma visão cultural sobre o bairro **La Boca**, um dos bairros mais turísticos e emblemáticos de **Buenos Aires**, capital da Argentina.

### Origem e Característica

- **Porto Natural e Imigração:** La Boca nasceu como um porto natural e foi povoado por muitos **imigrantes italianos**, por isso ainda há muitos descendentes italianos na Argentina, e a influência italiana é perceptível no ritmo da fala portenha.
    
- **Casas de Cores:** As famosas casas coloridas são feitas de **chapas de zinco** (_chapas de zinc_).
    
    - Os imigrantes as pintavam com as **tintas que sobravam** dos navios e dos estaleiros (_talleres del puerto_).
        
    - Como as sobras eram de cores diferentes, cada casa acabou ficando de uma cor, e a tradição se mantém até hoje.
        
- **Conventillos:** Antigamente, estas casas eram chamadas de **conventillos** e eram **moradias coletivas** (_viviendas colectivas_), onde mais de uma família vivia em cada casa.
    

---

## Atrações Principais de La Boca

O bairro é um polo cultural e turístico, oferecendo diversas atrações:

### 1. Caminito

- É a **rua principal** e mais famosa de La Boca, com cerca de **100 metros**.
    
- É uma **rua de pedestres** (_calle peatonal_).
    
- **Cultura e Arte:** É repleta de **construções de inúmeras cores** e serve de palco para **artistas de rua** (_artistas callejeros_).
    
    - É comum ver artistas **bailando o tango**, expondo pinturas, gravuras, distribuindo poesias e fazendo apresentações musicais.
        
- **Famoso Tango:** Existe um tango muito famoso chamado **"Caminito"**, composto por Juan de Dios Filiberto e Gabino Coria Peñaloza.
    

### 2. Museu de Bellas Artes de La Boca (Museo Benito Quinquela Martín)

- **Funcionamento:** Abre de terça a sexta (10:00 às 17:30) e sábados e domingos (11:00 às 17:00).
    
- **Origem:** O museu funciona na **casa** do famoso pintor argentino **Benito Quinquela Martín**, que dá nome ao museu.
    
- **Acervo:** Guarda grande parte da obra do próprio artista e também recebe **mostras temporárias** de artistas de todo o mundo.
    

### 3. Outros Pontos de Interesse

- **Teatro de la Ribera:** Um grande e famoso teatro de Buenos Aires, muito bonito.
    
- **Puente Nicolás Avellaneda:** Esta ponte **cruza o riacho** (_riachuelo_) e une os bairros de **La Boca** e **Isla Maciel**. Sua estrutura de ferro é um marco arquitetônico.
    
- **Estádio La Bombonera:** O famoso estádio do time de futebol **Boca Juniors** também está localizado no bairro de La Boca.
    

---

## Vocabulário e Classes Gramaticais

|Categoria|Palavra em Espanhol|Tradução (Português)|
|---|---|---|
|**Substantivos**|Barrio, La Boca, Buenos Aires, Capital, Inmigrantes, Descendientes, Argentinos, Italianos, Casas, Colores, Chapas de zinc, Pinturas, Puerto, Talleres, Conventillos, Viviendas, Familias, Calle, Caminito, Metros, Peatones, Artistas, Producciones, Espectáculos, Tango, Museo, Bellas Artes, Pintor, Obra, Muestras, Teatro, Puente, Riachuelo, Isla, Maciel, Esqueleto, Hierro, Estadio, Cancha, Fútbol, Bombonera|Bairro, Buenos Aires, Capital, Imigrantes, Descendentes, Argentinos, Italianos, Casas, Cores, Chapas de zinco, Tintas, Porto, Oficinas/Estaleiros, Moradias Coletivas, Famílias, Rua, Caminito, Metros, Pedestres, Artistas, Produções, Espetáculos, Tango, Museu, Belas Artes, Pintor, Obra, Exposições, Teatro, Ponte, Riacho, Ilha, Esqueleto, Ferro, Estádio, Campo, Futebol, Bombonera|
|**Adjetivos**|Turístico, Argentino, Natural, Diferente, Colectivas, Famosos, Principal, Peatonal, Innumerables, Musicales, Temporales, Bonita, Grande|Turístico, Argentino, Natural, Diferente, Coletivas, Famosos, Principal, Pedonal, Inúmeras, Musicais, Temporárias, Bonita, Grande|
|**Verbos**|Seguimos, Terminamos, Estamos hablando, Mirad, Nació, Construían, Pintaban, Sobraban, Llamaban, Viven, Dicho, Ofrecen, Exponen, Bailando, Abre, Funciona, Guarda, Hay, Cruzan, Une, Notar, Merece, Podáis, Visitarlo|Seguimos, Terminamos, Estamos falando, Olhem, Nasceu, Construíam, Pintavam, Sobravam, Chamavam, Vivem, Dito, Oferecem, Expõem, Dançando, Abre, Funciona, Guarda, Há/Existe, Cruzam, Une, Notar, Vale a pena, Possam, Visitar|
|**Advérbios/Locuções**|Hoy, Un poco, Por eso, Sobre todo, Así, Hasta hoy, Allí, Por toda la calle, Además de, De martes a viernes, Muy|Hoje, Um pouco, Por isso, Sobretudo, Assim, Até hoje, Lá/Ali, Por toda a rua, Além de, De terça a sexta, Muito|