---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Alquilar un Piso IV | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/raQJiDo5_z4?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>


[[ALQUILARUNPISOIV.pdf]]

---
# AULA DE ESPANHOL: LOCALIZAÇÃO, VERBOS IRREGULARES E PLANOS DE CASA

---

## Introdução da Aula

Continuamos o tema "Alugar um Apartamento" (_Alquilar un Piso_). Nesta aula, focaremos em estruturas gramaticais essenciais para descrever e **localizar** objetos e cômodos em uma casa. Estudaremos **Locuções Preposicionais** de lugar e a conjugação dos verbos irregulares **"Tener"** (Ter) e **"Poner"** (Pôr/Colocar), finalizando com exercícios de descrição de plantas de casa.

---

## 1. Locuções Preposicionais de Localização

Locuções preposicionais são frases que funcionam como preposições e nos ajudam a indicar a **posição exata** de algo. Elas sempre usam a preposição **"de"** no final (que pode se contrair para **"del"** se o substantivo for masculino singular).

|Locução (Espanhol)|Significado (Português)|Uso e Exemplo|
|---|---|---|
|**Al lado de**|Ao lado de|Indica proximidade. Ex: _Mi dormitorio está **al lado de** la cocina._|
|**Debajo de**|Debaixo de|Indica posição inferior. Ex: _El libro está **debajo del** teléfono._|
|**Delante de**|Em frente de|Indica posição anterior (em frente, mas na parte da frente). Ex: _El teléfono está **delante del** ordenador._|
|**Detrás de**|Atrás de|Indica posição posterior. Ex: _El cuadro está **detrás del** sofá._|
|**Encima de**|Em cima de|Indica posição superior. Ex: _Las llaves están **encima de** la mesa._|

> **Lembrete da Contração:**
> 
> - Use **DEL** (de + el) antes de palavras masculinas singulares (Ex: _del salón, del teléfono_).
>     
> - Use **DE LA** antes de palavras femininas (Ex: _de la cocina, de la revista_).
>     

---

## 2. Verbos Irregulares para Descrição e Posição

### A. Verbo "Tener" (Ter)

O verbo _Tener_ é irregular, mas sua irregularidade segue um padrão comum.

|Pessoa|Conjugação (Espanhol)|Irregularidade|
|---|---|---|
|**Yo**|**Tengo**|Mudança no radical (e em _tengo_).|
|**Tú**|**Tienes**|Mudança no radical: **E** ![](data:,) **IE**|
|**Usted / Él / Ella**|**Tiene**|Mudança no radical: **E** ![](data:,) **IE**|
|**Nosotros/as**|**Tenemos**|Regular (não muda o radical).|
|**Vosotros/as**|**Tenéis**|Regular (não muda o radical).|
|**Ustedes / Ellos/as**|**Tienen**|Mudança no radical: **E** ![](data:,) **IE**|

### B. Verbo "Poner" (Pôr/Colocar)

O verbo _Poner_ (colocar) é muito usado para indicar onde algo é colocado.

|Pessoa|Conjugação (Espanhol)|Irregularidade|
|---|---|---|
|**Yo**|**Pongo**|Irregular (somente na 1ª pessoa do singular).|
|**Tú**|**Pones**|Regular.|
|**Usted / Él / Ella**|**Pone**|Regular.|
|**Nosotros/as**|**Ponemos**|Regular.|
|**Vosotros/as**|**Ponéis**|Regular.|
|**Ustedes / Ellos/as**|**Ponen**|Regular.|

---

## 3. Exercício: Análise de Planta de Casa

Para descrever o que há em uma planta de casa, usa-se a combinação de verbos (Tener/Hay) e locuções preposicionais.

|Pergunta Típica|Resposta Padrão (Exemplo da Planta)|
|---|---|
|**¿Cuántos dormitorios tiene la casa?**|_La casa **tiene** dos dormitorios._ (Usando **Tener**)|
|**¿Dónde está [un objeto o cuarto]?**|_El dormitorio principal **está detrás de** la puerta de entrada._|
|**¿Dónde está la cocina?**|_La cocina **está a la izquierda del** recibidor._|

---

# VOCABULÁRIO E CLASSES GRAMATICAIS

## Substantivos (Sustantivos / Nouns)

|Substantivo (Espanhol)|Tradução (Português)|
|---|---|
|**Piso / Casa / Apartamento**|Apartamento / Casa|
|**Locuciones Preposicionales**|Locuções Preposicionais|
|**Dormitorio / Cocina / Salón**|Quarto / Cozinha / Sala|
|**Libro / Teléfono / Revista**|Livro / Telefone / Revista|
|**Ordenador / Tele / Televisión**|Computador / TV|
|**Cuadro / Sofá / Silla / Cadera**|Quadro / Sofá / Cadeira|
|**Llaves / Mesa / Banco**|Chaves / Mesa / Banco|
|**Lámpara / Mesilla de noche / Cama**|Luminária / Mesa de cabeceira / Cama|
|**Alfombra / Silla / Mesa de estudios / Escritorio / Ventana / Suelo / Paredes**|Tapete / Cadeira / Mesa de estudos / Escrivaninha / Janela / Chão / Paredes|
|**Estantería / Libros / Cortinas**|Estante / Livros / Cortinas|
|**Madre / Personas / Alquiler**|Mãe / Pessoas / Aluguel|
|**Recibidor / Cuarto de baño**|Hall de entrada / Banheiro|

## Adjetivos e Advérbios

|Adjetivo / Advérbio (Espanhol)|Tradução (Português)|
|---|---|
|**Muy cerca**|Muito perto|
|**Inferior / Anterior / Posterior**|Inferior / Anterior / Posterior|
|**Irregular / Común**|Irregular / Comum|
|**Grande**|Grande|
|**Todavía**|Ainda (Advérbio)|
|**Principal**|Principal|

## Preposições e Contrações

|Palavra (Espanhol)|Classificação|Notas|
|---|---|---|
|**De / A / Con**|Preposições|De / A / Com|
|**Al / Del / De la**|Contrações / Preposições|Ao / Do / Da (fem.)|
|**Al lado de / Debajo de / Delante de / Detrás de / Encima de**|Locuções Preposicionais|Ao lado de / Debaixo de / Em frente de / Atrás de / Em cima de|
|**Donde**|Advérbio Interrogativo|Onde|