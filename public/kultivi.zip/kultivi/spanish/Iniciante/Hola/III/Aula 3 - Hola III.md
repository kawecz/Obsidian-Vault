---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Hola III | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/t2cFLm-xehQ?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

[[Hola_III.pdf]]

---
# Aula de Espanhol: Gramática Essencial e Pontuação

## 1. Gramática: Conjugação Verbal

Nesta aula, vamos aprofundar a conjugação de verbos no presente do indicativo, que representam ações. Em espanhol, os verbos são classificados em três grupos principais com base em suas terminações no infinitivo: **-AR**, **-ER**, e **-IR**.

### Verbos Regulares

Verbos regulares seguem um padrão de conjugação. Para conjugá-los, você remove a terminação (-AR, -ER ou -IR) e adiciona a terminação correspondente a cada pronome.

|Pronome (Pessoa)|Terminações para -AR|Exemplo com **TRABAJAR**|Terminações para -ER|Exemplo com **COMER**|Terminações para -IR|Exemplo com **VIVIR**|
|---|---|---|---|---|---|---|
|**Yo**|**-o**|trabaj**o**|**-o**|com**o**|**-o**|viv**o**|
|**Tú**|**-as**|trabaj**as**|**-es**|com**es**|**-es**|viv**es**|
|**Él/Ella/Usted**|**-a**|trabaj**a**|**-e**|com**e**|**-e**|viv**e**|
|**Nosotros/Nosotras**|**-amos**|trabaj**amos**|**-emos**|com**emos**|**-imos**|viv**imos**|
|**Vosotros/Vosotras**|**-áis**|trabaj**áis**|**-éis**|com**éis**|**-ís**|viv**ís**|
|**Ellos/Ellas/Ustedes**|**-an**|trabaj**an**|**-en**|com**en**|**-en**|viv**en**|

**Observações Importantes:**

- A conjugação para **tú** termina sempre com **-s**. Ex: _¿Cómo **estás**?_
    
- A conjugação para **usted** é a mesma que para **él/ella** e não termina com **-s**. Ex: _¿Cómo **está**?_
    
- O uso de **tú** é informal, enquanto **usted** é formal.
    

### Verbos Irregulares (Irregulares)

Verbos irregulares não seguem as regras de conjugação padrão. Um exemplo é o verbo **SER**.

|Pronome (Pessoa)|Verbo **SER**|Exemplo|
|---|---|---|
|**Yo**|soy|_Soy brasileño._|
|**Tú**|eres|_¿De dónde eres?_|
|**Él/Ella/Usted**|es|_Él es de Madrid._|
|**Nosotros/Nosotras**|somos|_Somos estudiantes._|
|**Vosotros/Vosotras**|sois|_Sois de España._|
|**Ellos/Ellas/Ustedes**|son|_Ellos son de Buenos Aires._|

### Verbos Reflexivos: O caso do verbo **llamarse** (chamar-se)

Verbos reflexivos, como **llamarse**, têm um "se" no final, que indica que a ação afeta a própria pessoa que a realiza. Você deve usar um pronome reflexivo antes do verbo ao conjugá-lo.

|Pronome (Pessoa)|Verbo **llamarse**|Exemplo|
|---|---|---|
|**Yo**|me llamo|_Me llamo Thaís._|
|**Tú**|te llamas|_¿Cómo te llamas?_|
|**Él/Ella/Usted**|se llama|_Él se llama Fernando._|
|**Nosotros/Nosotras**|nos llamamos|_Nos llamamos Paula y Pilar._|
|**Vosotros/Vosotras**|os llamáis|_¿Cómo os llamáis?_|
|**Ellos/Ellas/Ustedes**|se llaman|_Ellas se llaman María y Juana._|

---

## 2. Ortografia: Sinais de Pontuação (Signos de Puntuación)

A pontuação em espanhol possui algumas particularidades que são importantes na escrita e na leitura.

### Sinais de Interrogação e Exclamação (Signos de Interrogación y Exclamación)

Em espanhol, esses sinais são usados no início e no final da frase. Eles são invertidos no início da frase (**¿** e **¡**).

- **Onde usar:**
    
    - O sinal de interrogação invertido (¿) é usado no início de uma pergunta. Ex: _¿Qué tal?_
        
    - O sinal de exclamação invertido (¡) é usado no início de uma exclamação. Ex: _¡Hola!_
        
- **Vantagem:** Essa regra ajuda a saber o tom da frase desde o começo, facilitando a leitura em voz alta.
    

### Uso da Vírgula (Coma)

A vírgula (,) tem a mesma função do português: separar elementos, indicar pausas e isolar vocativos (chamar uma pessoa).

- **Em negações:** Se você nega algo e depois dá a informação correta, use uma vírgula depois do "no".
    
    - **Correto:** _No, soy de Brasil._ (Não, sou do Brasil.)
        
    - **Incorreto:** _No soy de Brasil._ (Estou negando que sou do Brasil.)
        

---