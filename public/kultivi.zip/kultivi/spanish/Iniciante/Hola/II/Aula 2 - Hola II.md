---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Hola II | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/BffY9Sd5x1g?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>


[[Hola_II.pdf]]

---
# Aula de Espanhol: Profissões e Gênero de Nomes

## 1. Falando sobre Profissões

Nesta aula, vamos aprender a perguntar e a responder sobre a profissão e o local de trabalho de alguém.

### Diálogo: Juan e María

- **Juan:** María, ¿tú a qué te dedicas?
    
- **María:** Soy banquera.
    
- **Juan:** ¿Dónde trabajas?
    
- **María:** Trabajo en un banco. ¿Y tú, Juan, a qué te dedicas?
    
- **Juan:** Yo soy banquero. Soy de Francia, trabajo en un banco francés.
    

### Perguntando a Profissão

Você pode usar duas formas para perguntar a alguém qual a profissão dela.

- **¿Qué haces?**
    
- **¿A qué te dedicas?**
    

### Respondendo sobre a Profissão

Para responder, use a seguinte estrutura:

- **Soy [profissão]**
    

**Exemplos:**

- _Soy profesora._ (Sou professora.)
    
- _Soy historiadora._ (Sou historiadora.)
    

### Dizendo onde você trabalha

Para dizer onde você trabalha, use a seguinte estrutura:

- **Trabajo en el/la...** (Trabalho no/na...)
    
- **Trabajo en un/una...** (Trabalho em um/uma...)
    

|Uso|Quando usar|Exemplo|
|---|---|---|
|**en el / en la**|Para se referir a um local específico, conhecido ou nomeado.|_Trabajo en el hospital._ (Trabalho no hospital que nós já conhecemos.)|
|**en un / en una**|Para se referir a um local de forma genérica.|_Trabajo en un hospital._ (Trabalho em um hospital qualquer.)|

## 2. Vocabulário de Profissões (Profundizando en el tema)

|Espanhol (Masculino)|Espanhol (Feminino)|Português|
|---|---|---|
|Estudiante|Estudiante|Estudante|
|Periodista|Periodista|Jornalista|
|Profesor|Profesora|Professor(a)|
|Abogado|Abogada|Advogado(a)|
|Locutor|Locutora|Locutor(a)|
|Arquitecto|Arquitecta|Arquiteto(a)|
|Piloto|Piloto|Piloto|
|Dentista|Dentista|Dentista|
|Taxista|Taxista|Taxista|
|Actor|Actriz|Ator/Atriz|
|Padeiro|Padeira|Padeiro(a)|
|Policía|Policía|Policial|
|Fotógrafo|Fotógrafa|Fotógrafo(a)|
|Pintor|Pintora|Pintor(a)|
|Camarero|Camarera|Garçom/Garçonete|
|Carnicero|Carnicera|Açougueiro(a)|
|Fontanero|Fontanera|Encanador(a)|
|Cajero|Cajera|Caixa|
|Barrendero|Barrendera|Gari|
|Carpintero|Carpintera|Carpinteiro(a)|
|Enfermero|Enfermera|Enfermeiro(a)|
|Conductor|Conductora|Motorista|

---

## 3. Gênero de Nomes e Adjetivos

Em espanhol, o gênero de nomes e adjetivos segue algumas regras que são parecidas com o português.

### Gênero Masculino e Feminino

A maioria dos nomes e adjetivos em espanhol têm uma forma masculina e uma feminina.

- **Regra Geral:** Palavras masculinas que terminam em **-o** mudam para **-a** no feminino.
    
    - Exemplo: _El banquero_ (o banqueiro) e _La banquera_ (a banqueira).
        
- **Outras Terminações:** Palavras masculinas que terminam em consoante (como **-r**) geralmente adicionam um **-a** para formar o feminino.
    
    - Exemplo: _El profesor_ (o professor) e _La profesora_ (a professora).
        

### Palavras com a mesma forma para ambos os gêneros

Algumas palavras têm a mesma forma para o masculino e o feminino. O gênero é indicado pelo artigo (**el** ou **la**) ou pelo adjetivo que a acompanha.

- **Terminadas em -ista:**
    
    - _El/La periodista_ (o/a jornalista)
        
    - _El/La taxista_ (o/a taxista)
        
- **Terminadas em -e:**
    
    - _El/La estudiante_ (o/a estudante)
        
    - _El/La cantante_ (o/a cantor/a)
        
- **Terminadas em vogais acentuadas (geralmente nacionalidades):**
    
    - _El marroquí / La marroquí_ (o/a marroquino/a)
        
    - _El iraní / La iraní_ (o/a iraniano/a)
        

Exceções:

Cargos de alta posição, como "presidente," podem ter duas formas femininas: la presidenta ou la presidente. A escolha depende da preferência da pessoa.

---
