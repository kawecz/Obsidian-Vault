---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Hola I | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/T0Xi5x025KU?feature=oembed" height="113" width="200" allowfullscreen="" allow="fullscreen" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;"></iframe>

[[Hola_I.pdf]]

---
# Aula de Espanhol: Primeiros Passos na Conversação

## 1. Saudações e Apresentações

Nesta primeira parte, vamos aprender a nos apresentar e a cumprimentar as pessoas em espanhol. Vamos começar com um diálogo básico.

### Diálogo: Fernando e Paula

- **Paula:** Olá! Me llamo Paula. ¿Y tú?
    
- **Fernando:** Me llamo Fernando.
    
- **Paula:** Mucho gusto. ¿Cómo estás?
    
- **Fernando:** Muy bien, gracias. ¿Y tú?
    
- **Paula:** Muy bien, gracias.
    

### Frases de Cumprimento e Apresentação

|Português|Espanhol|Notas|
|---|---|---|
|Olá|Hola|A pronúncia é com o H mudo, como em "ora" no português.|
|Meu nome é...|Me llamo...|A forma mais comum de se apresentar.|
|Prazer em conhecê-lo(a)|Mucho gusto.|Usado ao conhecer alguém.|
|Como você está?|¿Cómo estás?|Pergunta sobre o estado de alguém (informal).|
|Muito bem, obrigado(a).|Muy bien, gracias.|Resposta comum.|
|E você?|¿Y tú?|Para devolver a pergunta (informal).|

## 2. Perguntando Origem e Moradia

Depois de se apresentar, é natural querer saber de onde a pessoa é e onde ela mora.

### Diálogo: Pablo e Pilar

- **Pablo:** ¿De dónde eres, Pilar?
    
- **Pilar:** Soy mexicana, de Veracruz. ¿Y tú, Pablo?
    
- **Pablo:** Soy brasileño, de Río de Janeiro.
    
- **Pilar:** ¿Dónde vives?
    
- **Pablo:** Vivo en la Ciudad de México.
    

### Frases sobre Origem e Moradia

|Português|Espanhol|Notas|
|---|---|---|
|De onde você é?|¿De dónde eres?|Pergunta sobre nacionalidade ou origem.|
|Eu sou [nacionalidade].|Soy...|Para responder sua nacionalidade. Ex: _Soy brasileño/brasileña._|
|Eu moro em...|Vivo en...|Para dizer onde você mora.|
|Onde você mora?|¿Dónde vives?|Pergunta sobre o local de residência.|

## 3. Apresentando Outras Pessoas

Vamos aprender a apresentar um amigo ou amiga a outra pessoa.

|Português|Espanhol|Notas|
|---|---|---|
|Eu te apresento...|Te presento a...|O "a" é obrigatório ao apresentar alguém.|
|Este/Esta é...|Este/Esta es...|Para introduzir uma pessoa.|

**Exemplo:**

- **Fernando:** Pau, te presento a Fernando. (Paula, eu te apresento o Fernando.)
    
- **Paula:** Hola, Fernando, mucho gusto.
    

## 4. Saudando Formal e Informalmente

Em espanhol, existem diferentes formas de cumprimentar, dependendo do contexto.

|Português|Espanhol (formal/padrão)|Espanhol (coloquial/simplificado)|
|---|---|---|
|Bom dia|Buenos días|Buen día|
|Boa tarde|Buenas tardes|Buen tarde|
|Boa noite|Buenas noches|Buen noche|
|Olá|Hola|_H_ mudo.|
|Olá, tudo bem?|¿Qué tal?|Muito comum e informal.|
|Como vai?|¿Cómo le va?|Mais formal.|
|Como você está?|¿Cómo estás?|Informal.|

**Para responder:**

- _Estoy bien._ (Estou bem.)
    
- _Estoy fatal._ (Estou péssimo.)
    
- _Todo bien._ (Tudo bem.)
    

## 5. Expressões de Despedida

Despedir-se em espanhol pode ser simples ou com diferentes nuances.

|Português|Espanhol|Notas|
|---|---|---|
|Tchau|Adiós, chao|_Adiós_ não tem a conotação de despedida eterna do português.|
|Até logo|Hasta luego|Comum e usado quando se sabe que vai ver a pessoa em breve.|
|Até amanhã|Hasta mañana|Para se despedir no final do dia.|
|Até a próxima|Hasta la próxima||
|Até logo (incerto)|Hasta pronto|Usado quando você não tem certeza de quando vai ver a pessoa novamente.|
|Nos vemos|Nos vemos||

## 6. Gramática: Pronomes Pessoais

Os pronomes pessoais são essenciais para a conjugação de verbos. Eles são seis, assim como em português, divididos em singular e plural.

|Pronome em Português|Pronome em Espanhol|Observações|
|---|---|---|
|Eu|Yo|O "Y" tem um som de "j" ou "sh", dependendo do local.|
|Você (informal)|Tú|O mais comum em contextos informais.|
|Você (formal)|Usted|Traduz como "o senhor" ou "a senhora". A conjugação é a mesma que para **él/ella**.|
|Ele|Él||
|Ela|Ella||
|Nós|Nosotros/Nosotras|**Nosotros** para grupo misto ou masculino. **Nosotras** para grupo só de mulheres.|
|Vocês (informal)|Vosotros/Vosotras|Muito comum na Espanha.|
|Vocês (formal)|Ustedes|Mais usado em países da América Latina.|
|Eles/Elas|Ellos/Ellas|**Ellos** para grupo misto ou masculino. **Ellas** para grupo só de mulheres.|

## 7. Vocabulário: Países e Gentílicos

|País|Capital|Gentílico|
|---|---|---|
|México|Ciudad de México|mexicano|
|Guatemala|Ciudad de Guatemala|guatemalteco|
|Honduras|Tegucigalpa|hondureño|
|El Salvador|San Salvador|salvadoreño|
|Nicaragua|Managua|nicaragüense|
|Costa Rica|San José|costarricense|
|Panamá|Ciudad de Panamá|panameño|
|Puerto Rico|San Juan|puertorriqueño|
|República Dominicana|Santo Domingo|dominicano|
|Cuba|La Habana|cubano|
|Venezuela|Caracas|venezolano|
|Colombia|Bogotá|colombiano|
|Ecuador|Quito|ecuatoriano|
|Perú|Lima|peruano|
|Bolivia|La Paz / Sucre|boliviano|
|Chile|Santiago|chileno|
|Paraguay|Asunción|paraguayo|
|Uruguay|Montevideo|uruguayo|
|Argentina|Buenos Aires|argentino|
|España|Madrid|español|
|Guinea Ecuatorial|Malabo|ecuatoguineano|
|Brasil|Brasilia|brasileño|