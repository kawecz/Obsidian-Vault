---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Presentaciones IV | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/KZM4OFb2g1A?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

[[PRESENTACIONESIV.pdf]]

---
# AULA DE ESPANHOL: INTRODUÇÃO À ESPANHA 🇪🇸

---

## Introdução da Aula

Esta aula serve como uma breve, porém rica, introdução à **Espanha** (Reino de Espanha), o país de origem do idioma espanhol. Exploraremos sua estrutura política como uma **Monarquia Parlamentar**, sua localização geográfica na Península Ibérica, e as diversas **Comunidades Autónomas** que a compõem. O objetivo é fornecer um contexto cultural e geográfico essencial para o aprendizado da língua, destacando a diversidade regional do país.

---

## Estrutura Política e Geografia

|Tópico|Detalhe|Explicação Adicional|
|---|---|---|
|**Nome Oficial**|Reino de Espanha (_Reino de España_)|A Espanha é uma **Monarquia Parlamentar**, o que significa que, embora tenha um **Rei** como Chefe de Estado (com funções cerimoniais e representativas), o poder de decisão reside no **Parlamento** e no **Presidente do Governo** (Chefe de Governo).|
|**Monarca Atual**|**Felipe VI**|Possui o título de Capitão-Geral do Exército de Terra. O rei também possui o título de **Príncipe de Astúrias**.|
|**Chefe de Governo**|**Presidente do Governo** (Atualmente, **Mariano Rajoy** é citado no contexto da aula, mas a figura atual mudará ao longo do tempo).|É o equivalente a um Primeiro-Ministro ou Presidente Executivo em outros sistemas.|
|**Localização**|Sul da Europa, na **Península Ibérica**.|A Península Ibérica é formada apenas por **Espanha** e **Portugal**. A Espanha faz fronteira com a França (que não faz parte da Península Ibérica).|
|**Capitais**|• **Portugal:** Lisboa • **Espanha:** **Madrid**|Madrid está localizada exatamente no **centro** da Península Ibérica e no centro da Espanha. O **Quilômetro Zero** das estradas espanholas está em Madrid.|

---

## Divisão Territorial: Comunidades Autónomas

A Espanha é dividida em **Comunidades Autónomas** (_Comunidades Autónomas_). Elas são diferentes dos estados brasileiros, pois possuem um grau maior de **autonomia** (uma pode ter mais que a outra), daí o nome.

|Comunidade Autónoma|Localização / Detalhe|Línguas Faladas (Além do Espanhol/Castelhano)|
|---|---|---|
|**Galicia**|Próxima a Portugal. Famosa por **Santiago de Compostela**.|**Gallego** (_Gallego_). São bilíngues.|
|**Asturias**|Região de onde vêm os Reis de Espanha.|-|
|**Cantabria**|Ao lado de Astúrias.|-|
|**País Vasco**|Ao lado de Cantabria e Navarra.|**Euskera** (ou **Vasco**).|
|**Navarra**|Vizinha do País Basco.|-|
|**Aragón**|Próxima à Navarra e Catalunha.|**Aragonês** (_Aragonés_).|
|**Cataluña**|Faz fronteira com a França. Inclui a cidade de **Barcelona**.|**Catalán**.|
|**Comunidad Valenciana**|Abaixo de Aragón.|**Valenciano** (que é uma variedade do Catalão).|
|**Murcia**|Abaixo da Comunidade Valenciana.|-|
|**Andalucía**|Extremo sul. Região com muitos **ciganos** (_gitanos_).|O espanhol local tem um sotaque diferente, com influência do **Romaní** (idioma cigano).|
|**Castilla-La Mancha**|A "Terra do **Dom Quixote**" (_Quijote_).|-|
|**Extremadura**|Ao lado de Castilla-La Mancha.|-|
|**Madrid**|O centro do país. É uma **Comunidade Autónoma** e a **Capital**.|-|
|**Castilla y León**|Acima de Madrid. Inclui a cidade de **Valladolid**.|-|

---

## O Idioma: Espanhol vs. Castelhano

|Termo|Detalhe|
|---|---|
|**Espanhol** (_Español_)|E **Castelhano** (_Castellano_) são a **mesma coisa**; não há diferença de idioma.|
|**Origem do Nome**|O termo **Castelhano** provém de **Castilla** (o antigo Reino de Castela), que foi o reino que uniu os demais reinos na formação da Espanha moderna, tornando seu dialeto o idioma oficial.|

---

## Vocabulário e Classes Gramaticais

## Substantivos (Sustantivos / Nouns)

|Substantivo (Espanhol)|Substantivo (Português)|Notas de Contexto|
|---|---|---|
|**España / Reino**|Espanha / Reino|País de origem e estrutura política.|
|**Unión Europea**|União Europeia|Organização da qual a Espanha é membro.|
|**Península Ibérica**|Península Ibérica|Localização geográfica da Espanha e Portugal.|
|**Rey / Príncipe**|Rei / Príncipe|Títulos da monarquia (**Felipe VI**).|
|**Capitán General**|Capitão General|Título militar do Rei.|
|**Ejército / Tierra**|Exército / Terra|Componentes das forças armadas.|
|**Casa Real**|Casa Real|Sítio/site oficial da monarquia.|
|**Sistema político**|Sistema político|Tipo de governo (monarquia parlamentar).|
|**Parlamento / Poder Ejecutivo**|Parlamento / Poder Executivo|Órgãos de decisão do governo.|
|**Presidente / Gobierno**|Presidente / Governo|Chefe do poder executivo.|
|**Europa / Portugal / Francia**|Europa / Portugal / França|Localizações geográficas/países vizinhos.|
|**Lisboa / Madrid**|Lisboa / Madrid|Capitais de Portugal e Espanha.|
|**Kilómetro Cero**|Quilômetro Zero|Ponto de origem das estradas espanholas, em Madrid.|
|**Carreteras / Mapa**|Estradas / Mapa|Infraestrutura e representação gráfica.|
|**Comunidades Autónomas**|Comunidades Autónomas|Divisão administrativa da Espanha.|
|**Estados / Brasil / Autonomía**|Estados / Brasil / Autonomia|Comparação com o Brasil e característica da divisão.|
|**Galicia / Asturias / Cantabria / País Vasco / Navarra / Aragón / Cataluña / Comunidad Valenciana / Murcia / Andalucía / Castilla-La Mancha / Extremadura / Castilla y León**|Galiza / Astúrias / Cantábria / País Basco / Navarra / Aragão / Catalunha / Comunidade Valenciana / Múrcia / Andaluzia / Castela-Mancha / Estremadura / Castela e Leão|Nomes das 17 comunidades autónomas.|
|**Santiago de Compostela / Barcelona / Valladolid**|Santiago de Compostela / Barcelona / Valhadolid|Nomes de cidades importantes.|
|**Gallego / Euskera (Vasco) / Aragonés / Catalán / Valenciano / Romaní**|Galego / Basco / Aragonês / Catalão / Valenciano / Romaní|Nomes de idiomas regionais ou falados.|
|**Gitanos / Ciganos / Sotaque**|Ciganos / Ciganos / Sotaque|Palavras relacionadas à Andaluzia e sua cultura.|
|**Quijote**|Quixote|Personagem de obra literária (Dom Quixote).|
|**Castellano / Castilla / Idioma**|Castelhano / Castela / Idioma|Termos que se referem à língua espanhola e sua origem.|
|**Clases / Presentaciones**|Aulas / Apresentações|Termos do contexto da classe.|
|**Diversidad / Culturas**|Diversidade / Culturas|Conceitos sobre a riqueza cultural do país.|

---

## Adjetivos (Adjetivos / Adjectives)

|Adjetivo (Espanhol)|Adjetivo (Português)|
|---|---|
|**Muy buenas**|Muito boas|
|**Parlementaria**|Parlamentar|
|**Ejecutivo**|Executivo|
|**Ibérica**|Ibérica|
|**Central**|Central|
|**Españolas**|Espanholas|
|**Autónomas**|Autónomas|
|**Bilingües**|Bilíngues|
|**Oficial**|Oficial|
|**Valenciano**|Valenciano|
|**Diferente**|Diferente|
|**Mayor**|Maior|
|**Básicas**|Básicas|
|**Específicas**|Específicas|
|**Diferentes**|Diferentes|

---

## Preposições, Conjunções e Advérbios de Lugar (As que Mais Apareceram)

|Palavra (Espanhol)|Classificação|Tradução|Uso Principal no Texto|
|---|---|---|---|
|**Sobre**|Preposição|Sobre / A respeito de|Introduzir um tópico ("clases **sobre** presentaciones").|
|**A**|Preposição|A|Conectar verbos ou indicar movimento/destino ("hablaremos **a**lgo **a**cerca **de**").|
|**En**|Preposição|Em|Indicar lugar/localização ("está **en** la Península ibérica", "se habla **en** Galicia").|
|**De**|Preposição|De|Indicar origem, posse ou material ("el país **de** origen", "rey **de** España").|
|**Como**|Advérbio / Conjunção|Como|Usado para comparação ou explicação ("**como** vamos a ver", "vestido **como** capitán general").|
|**Por**|Preposição|Por|Indicar agente, causa ou meio ("formada **por** Portugal", "las decisiones son tomadas **por** el parlamento").|
|**Aunque**|Conjunção|Embora / Mesmo que|Expressar uma concessão (**"aunque** tenga un rey").|
|**Al lado (de)**|Locução Prepositiva|Ao lado (de)|Indicar proximidade espacial.|
|**Abajo (de)**|Advérbio de Lugar / Locução Prepositiva|Abaixo (de)|Indicar posição inferior.|
|**Arriba (de)**|Advérbio de Lugar / Locução Prepositiva|Acima (de)|Indicar posição superior.|