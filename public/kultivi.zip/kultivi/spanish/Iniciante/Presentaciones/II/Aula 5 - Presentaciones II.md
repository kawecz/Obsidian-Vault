---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

---
<iframe title="Espanhol | Kultivi - Presentaciones II | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/gjF6QYlmpJA?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

[[presentaciones.pdf]]

---

# AULA DE ESPANHOL: PLURAL E SINGULAR, ADJETIVOS POSSESSIVOS E PREPOSIÇÕES

---

## Introdução da Aula

Nesta aula, o foco é expandir o vocabulário e a gramática espanhola, aprofundando o que foi visto nas aulas anteriores. O professor aborda três tópicos principais: a formação do plural e do singular de nomes e adjetivos, o uso dos adjetivos possessivos (meu, teu, seu) e as preposições "de" e "en". A didática é comparativa com o português, destacando semelhanças e diferenças para facilitar o aprendizado.

---

## Plural e Singular de Nomes e Adjetivos

Em espanhol, a regra para a formação do plural é simples e, na maioria das vezes, similar ao português. A distinção principal se dá pela vogal ou consoante final da palavra no singular.

### Regras de Pluralização

|Terminação no Singular|Regra de Pluralização|Exemplos|
|---|---|---|
|**Vogal** (a, e, i, o, u)|Adiciona-se **-s**|• amigo -> amigos • alumna -> alumnas|
|**Consoante**, **vogal acentuada** ou **-y**|Adiciona-se **-es**|• profesor -> profesores • marroquí -> marroquíes • rey -> reyes|

> **Observação:** O som do 'y' no final da palavra, como em 'rey', não é como o som de 'i' em português, mas sim um som de consoante.

### Palavras e Seus Plurais

|Singular (Nome/Adjetivo)|Plural (Nome/Adjetivo)|
|---|---|
|**VOGAL FINAL**||
|periodista|periodistas|
|peruano|peruanos|
|estudiante|estudiantes|
|camarero|camareros|
|abogada|abogadas|
|alumno|alumnos|
|**CONSOANTE FINAL**||
|pintor|pintores|
|profesor|profesores|
|diseñador|diseñadores|
|inglés|ingleses|
|alemán|alemanes|

> **Atenção:** Palavras como **"inglés"** e **"alemán"** perdem o acento no plural, como em **"ingleses"** e **"alemanes"**. A acentuação em espanhol segue regras específicas, que serão vistas em uma aula futura.

---

## Adjetivos Possessivos

Os adjetivos possessivos indicam posse. Eles concordam em número (singular ou plural) com o substantivo que acompanham, mas **não em gênero** (masculino ou feminino).

|Pessoa (Pronome)|Adjetivo Possessivo (Singular)|Adjetivo Possessivo (Plural)|Exemplo de Uso|
|---|---|---|---|
|**Yo** (Eu)|**mi**|**mis**|• **Mi** libro (**meu** livro) • **Mis** revistas (**minhas** revistas)|
|**Tú** (Tu, você informal)|**tu**|**tus**|• **Tu** libro (**teu** livro) • **Tus** libros (**teus** livros)|
|**Él/Ella/Usted** (Ele/Ela/Você formal)|**su**|**sus**|• **Su** libro (**seu** livro) • **Sus** libros (**seus** livros)|

> Diferença importante:
> 
> • O adjetivo possessivo "tu" (sem acento) é usado para o tratamento informal ("tú", com acento).
> 
> • O adjetivo possessivo "su" é usado para o tratamento formal ("usted") e também significa o possessivo de "ele" e "ela" ("dele" e "dela").

### Exercício de Fixação

|Frase Original|Resposta Correta|Explicação|
|---|---|---|
|**A)** Pietro é italiano. (Terceira pessoa)|**Su** país es Italia.|**"Pietro"** é um nome próprio, que se refere à terceira pessoa. Portanto, o possessivo correto é **"su"**.|
|**B)** Eu sou nigeriano. (Primeira pessoa)|**Mi** país es Nigeria.|A frase é sobre a primeira pessoa (eu), logo o possessivo é **"mi"**.|
|**C)** Você é argentino? (Tratamento com **"tú"**)|**Tu** país es Argentina.|O verbo **"eres"** indica um tratamento informal (**"tú"**). Portanto, o possessivo correto é **"tu"** (sem acento).|
|**D)** David, qual é o [seu] número de telefone?|**¿Cuál es tu/su número de teléfono?**|Como não há indicação do tipo de tratamento (formal ou informal), ambas as opções são válidas.|
|**E)** Pedro, me dá o [teu] número de celular.|**Dame tu número de móvil.**|O verbo **"dame"** (do verbo **"dar"**) está conjugado para o tratamento informal (**"tú"**), então o possessivo é **"tu"**.|

---

## Preposições

As preposições são palavras invariáveis que ligam dois termos da oração. Em espanhol, algumas preposições têm usos que podem ser diferentes do português.

### Preposição **"de"**

|Uso|Explicação|Exemplo|
|---|---|---|
|**Procedência**|Indica a origem de algo ou alguém.|• Soy **de** Brasil. • El coche es **de** él.|
|**Assunto/conteúdo**|Indica o tema ou assunto.|• El libro **de** historias.|

### Preposição **"en"**

|Uso|Explicação|Exemplo|
|---|---|---|
|**Lugar**|Indica o lugar onde algo ou alguém está (permanência).|• Él vive **en** Madrid. • El libro está **en** la mesa.|
|**Meio de transporte**|Indica o meio pelo qual algo é transportado.|• Ir **en** coche.|

> **Diferença com o Português:** Em português, dizemos "eu vou trabalhar **de** carro". Em espanhol, o correto é **"voy a trabajar en coche"**. Fique atento a essas diferenças, pois o uso das preposições nem sempre é uma tradução literal.

---

## Vocabulário da Aula

### Nomes (Sustantivos)

- amigo/amiga
    
- alumno/alumna
    
- profesor
    
- periodista
    
- peruano
    
- estudiante
    
- camarero
    
- abogada
    
- pintor
    
- diseñador
    
- marroquí
    
- inglés
    
- alemán
    
- rey
    
- libro
    
- revista
    
- número
    
- teléfono
    
- móvil
    
- país
    
- centro
    

### Adjetivos (Adjetivos)

- bonito
    
- feo
    
- inteligente
    
- grande
    
- pequeño
    
- argentino
    
- italiano
    
- nigeriano
    

### Preposições (Preposiciones)

- de
    
- en