---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-spanish
  - iniciante
---

----
<iframe title="Espanhol | Kultivi - Presentaciones III | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/OeadRBjf9Ps?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>


[[PRESENTACIONESIII.pdf]]

---
# AULA DE ESPANHOL: NÚMEROS, ALFABETO E VOGAIS FORTES/FRACAS

---

## Introdução da Aula

Esta aula aprofunda o aprendizado do espanhol, focando em elementos fundamentais para a pronúncia e a comunicação. Abordaremos a pronúncia dos números de zero a nove, exploraremos o alfabeto espanhol com atenção especial às diferenças fonéticas em relação ao português, e entenderemos o conceito de vogais fortes e fracas e sua importância na separação silábica e acentuação. A compreensão desses tópicos é crucial para desenvolver uma pronúncia clara e correta em espanhol.

---

## Números de 0 a 9 (Cero a Nueve)

A pronúncia dos números em espanhol é geralmente direta. Em alguns casos, existem particularidades no uso dos números, como a concordância em gênero e a supressão de letras.

### Pronúncia e Uso

|Número|Espanhol|Observações|
|---|---|---|
|**0**|**Cero**|Escrito com 'c'.|
|**1**|**Uno / Un / Una**|• **Uno:** Usado para contar ou quando o substantivo não aparece logo depois do número. Ex: _¿Cuántos libros hay? Hay uno._ • **Un:** Usado para substantivos masculinos quando a palavra vem _imediatamente_ após o número. O 'o' final é suprimido. Ex: _Hay un libro._ • **Una:** Usado para substantivos femininos, independentemente da posição da palavra. Ex: _Hay una revista._|
|**2**|**Dos**|Invariável em gênero (masculino e feminino). Ex: _Dos mesas, dos sofás._|
|**3**|**Tres**|Não possui acento.|
|**4**|**Cuatro**||
|**5**|**Cinco**||
|**6**|**Seis**||
|**7**|**Siete**||
|**8**|**Ocho**||
|**9**|**Nueve**||

### Perguntando e Respondendo o Número de Telefone

Em espanhol, os falantes geralmente ditam os números de telefone algarismo por algarismo.

#### Para Pessoas

A forma de perguntar o número de telefone de uma pessoa depende do tratamento (formal ou informal):

| Tratamento         | Pergunta                                      | Resposta                                 |
| ------------------ | --------------------------------------------- | ---------------------------------------- |
| **Informal (Tú)**  | **¿Cuál es tu número de teléfono?**           | • Mi número de teléfono es... • Es el... |
| **Formal (Usted)** | **¿Cuál es su número de teléfono?**           | • Mi número de teléfono es... • Es el... |
| **Informal (Tú)**  | **¿ Puedes decirme tú número de teléfono ? ** |                                          |
| **Formal (Usted)** | **Puede decirme su número de teléfono?**      |                                          |

#### Para Estabelecimentos

| Pergunta                                         | Exemplo                                                       |
| ------------------------------------------------ | ------------------------------------------------------------- |
| **¿Cuál es el número de teléfono del/de la...?** | • **Del mercado** (masculino) • **De la farmacia** (feminino) |

---

## Alfabeto Espanhol (Abecedario)

O alfabeto espanhol possui 27 letras. É crucial prestar atenção à pronúncia de certas letras e suas combinações, que podem ser diferentes do português.

### Letras e Pronúncias Específicas

|Letra|Nome da Letra|Pronúncia e Observações|Exemplos|
|---|---|---|---|
|**A**|**A**|Como em português.|• **A**vión|
|**B**|**Be**|Como em português.|• **B**asurero|
|**C**|**Ce**|• Antes de **a, o, u**: som de 'k' (ca, co, cu). Ex: **C**asa • Antes de **e, i**: som de 's' (ce, ci). Em algumas regiões da Espanha, pode ter um som interdental (língua entre os dentes), como 'th' em inglês. Ex: **C**entro, **C**iclismo|• **C**asa, **C**entro, **C**iclismo|
|**D**|**De**|Som mais fechado, diferente do 'di' em português.|• **D**inero|
|**E**|**E**|Som sempre de 'e' (fechado), mesmo que acentuado.|• **E**lefante, Caf**é**|
|**F**|**Efe**|Como em português.|• **F**lauta|
|**G**|**Ge**|• Antes de **a, o, u**: som de 'g' (ga, go, gu). Ex: **G**ato • Antes de **e, i**: som de 'rr' forte, vindo da garganta (ge, gi). Ex: **G**ente, Ni**caraguense** • Para ter som de 'gue', 'gui', usa-se **"gu"** com **"u"** pronunciado apenas se tiver trema (**ü**). Ex: Ni**caraguense**|• **G**ato, **G**ente, Ni**caraguense**|
|**H**|**Hache**|**Não tem som**. É muda, mesmo no meio da palavra.|• **H**ombre, Ola, Prohi**b**ido|
|**I**|**I**|Como em português.|• **I**glesia|
|**J**|**Jota**|Som de 'rr' forte, vindo da garganta, com todas as vogais (ja, je, ji, jo, ju).|• Ra**b**ón (sabão)|
|**K**|**Ka**|Usada principalmente em palavras de origem estrangeira.|• **K**ilo|
|**L**|**Ele**|• Antes de vogal: como em português. Ex: **L**ápiz • Antes de consoante ou no final da palavra: a língua toca o céu da boca, sem som de 'u'. Ex: A**l**berto, Españo**l**|• **L**ápiz, A**l**berto, Españo**l**|
|**M**|**Eme**|Como em português.||
|**N**|**Ene**|• Em combinações **MN** (ex: alu**mn**a): ambas as letras são lidas. O 'm' fecha e o 'n' abre o som. • Em combinações **NM** (ex: co**nm**igo): abre-se e depois fecha-se o som. • Palavras terminadas em 'n' têm som aberto, diferente do 'm' em português. Ex: Esta**n**|• Alu**mn**a, Co**nm**igo, Esta**n**|
|**O**|**O**|Som sempre de 'o' (fechado), nunca de 'ó'.|• **O**reja, R**o**sa|
|**P**|**Pe**|Como em português.||
|**Q**|**Cu**|• Som de 'k' (que, qui). O 'u' é mudo. Ex: **Q**ueso • Para ter som de 'qüe', 'qüi', usa-se **"gü"** com **"u"** pronunciado se tiver trema (**ü**).|• **Q**ueso|
|**R**|**Erre**|• No início da palavra e com **"rr"**: som vibrante forte, língua vibra no céu da boca. Ex: **R**atón, Pe**rr**o • Sozinho no meio ou final da palavra: som brando, como em português "caro". Ex: Pe**r**o, Habla**r**, Come**r**|• **R**atón (rato), Pe**rr**o (cachorro), Pe**r**o (mas)|
|**S**|**Ese**|• Sempre tem som de 's' (sa, se, si, so, su). Não existe 'ss' em espanhol. • Nunca tem som de 'z'.|• **S**apo, Profe**s**ora, Ca**s**a|
|**T**|**Te**|Som fechado, diferente do 'ti' em português.|• **T**ierra, **T**iago|
|**U**|**U**|Como em português.|• **U**va, A**u**to|
|**V**|**Uve**|Som de 'b'. Escrito com 'v', mas lido como 'b'.|• **V**ale|
|**W**|**Uve doble**|Usada em palavras de origem estrangeira. A pronúncia depende do idioma de origem.|• **W**ater (inglês), **W**agner (alemão)|
|**X**|**Equis**|• Geralmente tem som de 'ks'. Ex: E**x**amen • Exceção: em algumas palavras de origem indígena ou nomes próprios, pode ter som de 'j' (rr forte). Ex: Mé**x**ico|• E**x**amen, Mé**x**ico|
|**Y**|**Ye / I griega**|• Sozinho ou no final da palavra: som de 'i'. Ex: Le**y**, **Y** • Seguido de vogal: som de 'dj' ou 'ch' (variável regionalmente). Ex: **Y**erno (genro), Me **ll**amo|• Le**y**, **Y**erno|
|**Z**|**Zeta**|• Som parecido com 's'. Nunca tem som de 'z'. • Em algumas regiões da Espanha, pode ter som interdental (como 'th' em inglês).|• Zapa**to**|

### Dígrafos (sons com mais de uma letra)

Antigamente, alguns dígrafos faziam parte do alfabeto oficial. Embora não sejam mais letras separadas, seus sons são importantes.

|Dígrafo|Pronúncia e Observações|Exemplos|
|---|---|---|
|**Ch**|Som de 'tch' ou 'x' (como em "chuva" em português).|• **Ch**ao, Mu**ch**o|
|**Ll**|Som de 'lh' ou 'dj'/'ch' (variável regionalmente, como o 'y' seguido de vogal).|• Ca**ll**e (rua), Me **ll**amo|
|**Ñ**|Som de 'nh' (como em "amanhã" em português), mas com a língua batendo no céu da boca com mais força.|• Ma**ñ**ana (amanhã/manhã)|

---

## Vogais Fortes e Fracas (Vocales Fuertes y Débiles)

A distinção entre vogais fortes e fracas é fundamental para a correta separação silábica e para a acentuação em espanhol.

### Classificação das Vogais

|Tipo de Vogal|Vogais|
|---|---|
|**Vogais Fortes**|A, E, O|
|**Vogais Fracas**|U, I|

### Regras de Separação Silábica e Acentuação

1. **Duas Vogais Fortes Juntas:**
    
    - Sempre são separadas em sílabas diferentes, pois ambas têm "força" própria e não se apoiam uma na outra.
        
    - Exemplos:
        
        - **I-dea** (o 'e' e o 'a' são vogais fortes)
            
        - **Ro-án** (o 'o' e o 'a' são vogais fortes)
            
2. **Vogal Fraca e Vogal Forte Juntas (Ditongo):**
    
    - A vogal fraca se apoia na forte, e elas ficam na mesma sílaba. A vogal forte tem o som mais proeminente.
        
    - Exemplos:
        
        - **Es-tu-dian-te** (o 'i' é fraco e o 'a' é forte, ficam juntos)
            
        - **Juan** (o 'u' é fraco e o 'a' é forte, ficam juntos)
            
3. **Vogal Fraca Acentuada e Vogal Forte Juntas (Hiato):**
    
    - Uma vogal fraca só pode ser separada de uma vogal forte se ela estiver acentuada. O acento confere à vogal fraca uma "força" extra, permitindo que ela se separe da forte.
        
    - Exemplos:
        
        - **Pa-na-de-rí-a** (o 'i' fraco acentuado se separa do 'a' forte)
            
        - **Cafetería**, **Secretaría**
            

> **Impacto na Pronúncia de Palavras Similares ao Português:**
> 
> - **Democracia:** Em português, 'democracia' (com 'i' forte). Em espanhol, como o 'i' não tem acento, ele é fraco e se junta ao 'a'. A sílaba tônica recai antes: **De-mo-cra-cia**.
>     
> - **Academia:** Em português, 'academia'. Em espanhol, sem acento no 'i', pronuncia-se **A-ca-de-mia**.
>     

---

## Trava-Línguas (Trabalenguas)

Os trava-línguas são uma excelente ferramenta para praticar a pronúncia dos sons específicos do espanhol.

- **Trava-língua 1 (som de 'g' e 'j'):**
    
    > "El cangrejo se quedó perplejo al ver su reflejo en aquel espejo."
    
- **Trava-língua 2 (som de 'r' e 'rr'):**
    
    > "El perrito de Rita me irrita. Si el perrito de Rita te irrita, cambia el perrito por una perrita."
    
- **Trava-língua 3 (som de 'k' e 'c'):**
    
    > "Un chico checo se chocó con un coche sueco"
    

---

## Observações Gerais

|Tipo|Descrição|
|---|---|
|**Nouns**|amigo, alumna, profesor, periodista, peruano, estudiante, camarero, abogada, pintor, diseñador, marroquí, inglés, alemán, rey, libro, revista, número, teléfono, móvil, país, centro, dinero, elefante, flauta, gato, gente, hombre, iglesia, jabón, kilo, lápiz, Alberto, español, nube, oreja, queso, ratón, perro, sapo, profesora, casa, tierra, Tiago, uva, auto, vale, water, Wagner, examen, México, yerno, ley, zapato, mañana, chao, macho, calle|
|**Adjectives**|perplejo, irrita, mucho|
|**Prepositions**|en|