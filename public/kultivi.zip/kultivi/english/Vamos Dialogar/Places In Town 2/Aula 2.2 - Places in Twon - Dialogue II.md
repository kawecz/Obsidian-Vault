---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - dialogo
---

---
<iframe title="Inglês | Kultivi - Places in Town: Dialogue II | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/YbBGZY9my_w?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Diálogo - Planejando um Passeio pela Cidade
> Esta aula foca em um diálogo entre um casal (Carla e William) planejando um passeio turístico. O conteúdo revisa e expande o vocabulário de lugares na cidade, introduz verbos frasais (`phrasal verbs`) e expressões idiomáticas comuns em situações informais.

[[aula2.2.pdf]]

---

### 📝 **Visão Geral do Diálogo**

- **Situação:** Um casal, Carla e William, planeja um passeio turístico. Eles discutem os lugares que vão visitar (zoológico, museu, shopping) e têm uma conversa descontraída sobre finanças e gastos.
- **Estrutura do Diálogo:**
    1.  **Sugestão de Passeio:** A ideia de passar o dia no zoológico é proposta.
    2.  **Expandindo o Roteiro:** Sugestões de visitar outros lugares, como um museu histórico e um shopping center.
    3.  **Expressando Opinião:** Uso de expressões para concordar (`I see`, `That makes sense`).
    4.  **Humor e Expressões Idiomáticas:** Uma discussão brincalhona sobre cartão de crédito e gastos, introduzindo vocabulário informal.

---

### 🗣️ **Trechos Chave do Diálogo e Traduções**

| Diálogo em Inglês | Tradução para Português | Contexto/Análise |
| :--- | :--- | :--- |
| **Let's head to the zoo.** | Vamos rumar para o zoológico. | `Head to` é um *phrasal verb* que significa "ir em direção a", "rumar para". |
| **We can head back to the city on the way.** | Podemos voltar para a cidade no caminho. | `Head back` significa "voltar", "retornar". |
| **We are on the way.** | Estamos a caminho. | `On the way` é uma expressão fixa para "a caminho". |
| **The city hall, the art museum...** | A prefeitura, o museu de arte... | Revisão de vocabulário de lugares (`city hall`, `museum`). |
| **I see.** | Entendi. / Vejo. | Expressão usada para mostrar compreensão. |
| **That makes sense.** | Isso faz sentido. | Outra forma de expressar concordia e entendimento. |
| **The bus stop for the shopping mall is right there.** | A parada de ônibus para o shopping center é bem ali. | Vocabulário de transporte (`bus stop`) e lugares (`shopping mall`). |
| **It looks good to me.** | Parece bom para mim. | Estrutura para expressar aprovação. |
| **I think I'll leave my credit card in our room.** | Acho que vou deixar meu cartão de crédito no nosso quarto. | Introduz a ideia de controlar gastos. |
| **Just to be safe.** | Só por segurança. / Só para prevenir. | Expressão comum para indicar precaução. |
| **Don't be so stingy!** | Não seja tão pão-duro! | Vocabulário informal: `stingy` = mão-de-vaca, pão-duro. |
| **We are on vacation! Let's have fun!** | Estamos de férias! Vamos nos divertir! | `On vacation` = de férias. `Have fun` = se divertir. |
| **Let's forget the money issue.** | Vamos esquecer a questão financeira. | `Issue` = questão, problema. |
| **No way I'll let you have that credit card.** | De maneira nenhuma eu vou deixar você ficar com esse cartão de crédito. | `No way` = expressão idiomática forte para "de jeito nenhum", "sem chance". |
| **I would have to get two more jobs to recover.** | Eu teria que arranjar mais dois empregos para me recuperar. | Uso do condicional para uma situação hipotética. |

---

### 📚 **Análise do Conteúdo e Vocabulário**

#### **🧭 Substantivos (Nouns) - Novos Lugares**
- `Zoo`: Zoológico
- `City Hall`: Prefeitura
- `Art Museum`: Museu de Arte
- `Shopping Mall` / `Shopping Center`: Shopping Center
- `Bus Stop`: Ponto de Ônibus
- `Square`: Praça
- `Department Store`: Loja de Departamento
- `Credit Card`: Cartão de Crédito
- `Room` / `Hotel Room`: Quarto (de hotel)
- `Way`: Caminho, jeito, maneira
- `Issue`: Questão, problema

#### **📝 Adjetivos (Adjectives) & Advérbios (Adverbs)**
- `Stingy`: Pão-duro, mão-de-vaca
- `Safe`: Seguro
- `Historical`: Histórico

#### **📍 Preposições (Prepositions) & Partículas de *Phrasal Verbs***
- `To` (em `head to`): Indica direção.
- `Back` (em `head back`): Indica retorno.
- `On` (em `on the way`, `on vacation`): Faz parte de expressões fixas.

#### **🔁 Phrasal Verbs (Verbos Frasais)**
- **`Head to`**: Rumar para, ir em direção a. (*We will head to the museum*).
- **`Head back`**: Voltar, retornar. (*Let's head back to the hotel*).
- **`Leave (something)`**: Deixar (algo). (*I'll leave my bag here*).

#### **💡 Expressões e Estruturas Chave**
- **`On the way`**: A caminho.
- **`On vacation`**: De férias.
- **`I see`**: Entendo / Compreendo.
- **`That makes sense`**: Isso faz sentido.
- **`It looks good to me`**: Parece bom para mim.
- **`Just to be safe`**: Só por segurança / por precaução.
- **`No way`**: De jeito nenhum / Sem chance (expressa forte recusa ou negação).
- **`Have fun`**: Divertir-se.
- **`Let's forget the money issue`**: Vamos esquecer a questão do dinheiro.