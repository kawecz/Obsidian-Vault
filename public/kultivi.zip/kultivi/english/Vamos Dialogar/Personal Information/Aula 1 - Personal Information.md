---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - dialogo
---

---
<iframe title="Inglês | Kultivi - Personal Information: Dialogue | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/j5WCG4MhfHw?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Diálogo - Informações Pessoais (Personal Information)
> Esta aula prático reúne todo o vocabulário aprendido em lições anteriores (nomes, e-mail, nacionalidade, telefone, endereço) em um diálogo completo. O objetivo é simular uma situação real onde é necessário fornecer dados pessoais, como em uma matrícula escolar.

[[aula1.pdf]]

---

### **Diálogo Completo: Preenchendo um Formulário**

**Personagens:**
- **Secretária:** Quem faz as perguntas.
- **Você:** Quem fornece as informações.

| Secretária (Perguntas) | Você (Respostas - Modelo) | Tradução e Estrutura |
| :--- | :--- | :--- |
| **What's your first name?** | `My first name is [Seu Nome].` | **P:** Qual é o seu primeiro nome?<br>**R:** Meu primeiro nome é [Seu Nome]. |
| **What's your last name?** | `My last name is [Seu Sobrenome].` | **P:** Qual é o seu sobrenome?<br>**R:** Meu sobrenome é [Seu Sobrenome]. |
| **What's your email address?** | `It's [seu.email@provedor.com].` | **P:** Qual é o seu endereço de e-mail?<br>**R:** É [seu.email@provedor.com]. |
| **Where are you from?** | `I am from Brazil.` | **P:** De onde você é?<br>**R:** Eu sou do Brasil. |
| **What's your nationality?** | `I'm Brazilian.` | **P:** Qual é a sua nacionalidade?<br>**R:** Eu sou brasileiro(a). |
| **What's your phone number?** | `It's [DDD + Número].` | **P:** Qual é o seu número de telefone?<br>**R:** É [DDD + Número]. |
| **What's your address?** | `I live on [Nome da Rua] Street, number [Número].` | **P:** Qual é o seu endereço?<br>**R:** Eu moro na Rua [Nome da Rua], número [Número]. |

---

### **Estruturas Gramaticais e Vocabulário Chave**

#### **Perguntas Frequentes (Wh-Questions)**
- **What's your...?** (Qual é o seu/sua...?)
- **Where are you from?** (De onde você é?)

#### **Verbos (Verbs)**
- **To be** (Ser/Estar): `I am` (Eu sou/estou), `It is` (Ele/ela é/está)
- **To live** (Morar): `I live on...` (Eu moro na...)

#### **Substantivos (Nouns)**
- **First Name** (Primeiro Nome)
- **Last Name / Surname** (Sobrenome)
- **Email Address** (Endereço de E-mail)
- **Nationality** (Nacionalidade)
- **Phone Number** (Número de Telefone)
- **Address** (Endereço)
- **Street** (Rua)

#### **Preposições (Prepositions)**
- **On** (em/na): Usada com nomes de rua. `I live on Main Street.`
- **From** (de/de onde): `I am from Brazil.`

---

### **Atividade Prática**

1.  **Pause o vídeo.**
2.  **Copie o diálogo no seu caderno.**
3.  **Substitua as respostas do modelo pelas SUAS informações pessoais.**
4.  **Practice o diálogo em voz alta, fazendo o papel dos dois personagens.**

**Exemplo Prático com Dados Fictícios:**
- **Secretária:** What's your first name?
- **Você:** `My first name is Ana.`
- **Secretária:** What's your last name?
- **Você:** `My last name is Silva.`
- **Secretária:** What's your email address?
- **Você:** `It's ana.silva@email.com.`
- ...e assim por diante.