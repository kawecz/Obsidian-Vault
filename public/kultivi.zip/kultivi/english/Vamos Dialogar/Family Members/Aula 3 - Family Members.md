---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - dialogo
---

---
<iframe title="Inglês | Kultivi - Family Members: Sentences and Questions | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/PBHe5a4E7BQ?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Membros da Família - Frases e Perguntas
> Esta aula prática aplica o vocabulário de membros da família (visto em "Family Tree") em frases e perguntas do dia a dia. O foco está em estruturas para identificar relações familiares, usar o caso genitivo (possessivo 's) e praticar pronomes interrogativos como "Who".

[[aula3.pdf]]

---

### 👨‍👩‍👧‍👦 **Revisão de Vocabulário Chave**

| Português | Inglês (Singular) | Inglês (Plural) | Notas |
| :--- | :--- | :--- | :--- |
| Pais | Parents | - | `Parents` já é plural (pai E mãe). |
| Parentes | Relatives | - | Termo geral para familiares. |
| Irmão/Irmã | Sibling | Siblings | Termo neutro para irmão(s) e irmã(s). |
| Irmão | Brother | Brothers |  |
| Irmã | Sister | Sisters |  |
| Tio | Uncle | Uncles |  |
| Tia | Aunt | Aunts |  |
| Primo/Prima | Cousin | Cousins |  |
| Sobrinho | Nephew | Nephews |  |
| Sobrinha | Niece | Nieces |  |
| Filho | Son | Sons |  |
| Filha | Daughter | Daughters |  |
| Criança | Child / Kid | Children / Kids | `Children` é o plural irregular de `Child`. |
| Pessoa | Person | People | `People` é o plural irregular de `Person`. |
| Homem | Man | Men | Plural irregular. |
| Mulher | Woman | Women | Plural irregular. |

---

### ❓ **Estruturas de Perguntas com "Who" (Quem)**

| Pergunta | Tradução | Contexto de Uso |
| :--- | :--- | :--- |
| **Who is this/that [pessoa]?** | Quem é este/esta [pessoa]? | Para identificar alguém próximo (`this`) ou distante (`that`). |
| **Who are these/those [pessoas]?** | Quem são estes/estas [pessoas]? | Plural de "Who is". Para grupos próximos (`these`) ou distantes (`those`). |
| **How many siblings do you have?** | Quantos irmãos você tem? | Pergunta sobre a quantidade de irmãos. |

**Exemplos:**
- `Who is this man?` (Quem é este homem?)
- `Who is that woman?` (Quem é aquela mulher?)
- `Who are those people?` (Quem são aquelas pessoas?)
- `Who are these children?` (Quem são estas crianças?)

---

### 💬 **Frases Explicativas e Caso Genitivo ('s)**

| Frase em Inglês | Tradução | Análise Gramatical |
| :--- | :--- | :--- |
| **My father has three siblings.** | Meu pai tem três irmãos. | Uso de `siblings` para irmãos no geral. |
| **My father's sister is my aunt.** | A irmã do meu pai é minha tia. | **Caso Genitivo (`'s`):** Indica posse. "My father's sister" = A irmã **do meu pai**. |
| **My mother's sister has a daughter.** | A irmã da minha mãe tem uma filha. |  |
| **Julia is my mother's niece.** | A Júlia é sobrinha da minha mãe. |  |
| **My brother-in-law and my sister had a daughter.** | Meu cunhado e minha irmã tiveram uma filha. | `Had` é o passado do verbo `to have` (ter). |

---

### ✍️ **Demonstrativos: This, That, These, Those**

| Demonstrativo | Uso | Exemplo |
| :--- | :--- | :--- |
| **This** | Singular, próximo. | **This ball is black.** (Esta bola está perto.) |
| **That** | Singular, distante. | **That ball is black.** (Aquela bola está longe.) |
| **These** | Plural, próximo. | **These balls are black.** (Estas bolas estão perto.) |
| **Those** | Plural, distante. | **Those balls are black.** (Aquelas bolas estão longe.) |

**Aplicação em Perguntas:**
- `Who is this boy?` (Quem é este menino?) - Menino está perto.
- `Who is that girl?` (Quem é aquela menina?) - Menina está longe.
- `Who are these women?` (Quem são estas mulheres?) - Mulheres estão perto.
- `Who are those men?` (Quem são aqueles homens?) - Homens estão longe.

---

### 🗣️ **Padrões de Resposta**

| Pergunta | Respostas Possíveis | Tradução |
| :--- | :--- | :--- |
| **Who is this man?** | `He is my uncle Brad.` / `This is Brad, my uncle.` | Ele é meu tio Brad. / Este é o Brad, meu tio. |
| **Who are those women?** | `They are my aunts.` / `Those women are Becky and Rhonda.` | Elas são minhas tias. / Aquelas mulheres são Becky e Rhonda. |
| **Who are these children?** | `These children are Sam and Matt.` / `They are Sam and Matt.` | Estas crianças são Sam e Matt. / Eles são Sam e Matt. |

---

### 📝 **Notas Finais e Dicas**

- **Pronúncia:** Preste atenção aos plurais irregulares: `Man` -> `Men`; `Woman` -> `Women`; `Child` -> `Children`; `Person` -> `People`.
- **Flexibilidade:** As respostas podem ser dadas de diferentes formas. O importante é ser entendido.
- **Prática:** Troque os membros da família nas frases para criar novas sentenças e solidificar o vocabulário.