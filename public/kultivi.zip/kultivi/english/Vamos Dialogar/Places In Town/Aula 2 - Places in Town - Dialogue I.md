---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - dialogo
---

---
<iframe title="Inglês | Kultivi - Places in Town: Dialogue I | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/YLwGnQBWaq0?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Diálogo - Lugares na Cidade e Direções
> Esta aula consolida o vocabulário de lugares na cidade, preposições de lugar e frases para pedir e dar direções através de um diálogo situacional entre Peter (turista perdido) e Alice (local que ajuda). O foco está na aplicação prática do conteúdo das três aulas anteriores.

[[aula2.pdf]]

---

### 📝 **Visão Geral do Diálogo**

- **Situação:** Peter, um turista de Nova York, está perdido e pergunta a Alice por um bom restaurante para almoçar.
- **Estrutura do Diálogo:**
    1.  **Saudações e Apresentações.**
    2.  **Pedido de Ajuda:** Peter expressa que está perdido.
    3.  **Identificação da Necessidade:** Peter pergunta por restaurantes.
    4.  **Preferências:** Peter menciona seus tipos de comida favoritos.
    5.  **Dar Opções:** Alice sugere dois restaurantes.
    6.  **Pedir e Dar Direções:** Peter pergunta pela localização e como chegar ao restaurante japonês.
    7.  **Encerramento e Convite (Recusado):** Peter agradece, faz um convite e Alice recusa educadamente.

---

### 🗣️ **Diálogo Completo (Texto para Prática)**

| Personagem | Diálogo em Inglês | Tradução para Português |
| :--- | :--- | :--- |
| **Peter** | Hi, excuse me. What's your name? | Oi, com licença. Qual é o seu nome? |
| **Alice** | Hello. I'm Alice. Nice to meet you. | Olá. Eu sou a Alice. Prazer em conhecê-lo. |
| **Peter** | My name is Peter. Nice to meet you, Alice. So, I'm from New York and I am a little lost here. Can you help me? | Meu nome é Peter. Prazer em conhecê-la, Alice. Então, eu sou de Nova York e estou um pouco perdido aqui. Você pode me ajudar? |
| **Alice** | Sure. What do you need? | Claro. O que você precisa? |
| **Peter** | I want a good place to have lunch. Is there a good restaurant around? | Eu quero um bom lugar para almoçar. Existe um bom restaurante por perto? |
| **Alice** | Yes, there are some great restaurants in this neighborhood. | Sim, existem alguns ótimos restaurantes neste bairro. |
| **Peter** | Oh, that's amazing! What kind of food do you like? | Oh, isso é incrível! Que tipo de comida você gosta? |
| **Peter** | I like almost all kinds of food, but my favorites are Italian and Japanese food. | Eu gosto de quase todos os tipos de comida, mas as minhas favoritas são comida italiana e japonesa. |
| **Alice** | Well, there is a very good Italian restaurant just a few blocks away. | Bem, há um restaurante italiano muito bom a apenas algumas quadras de distância. |
| **Alice** | And there is also a fantastic Japanese restaurant that is not far as well. | E também há um restaurante japonês fantástico que não fica longe. |
| **Peter** | Right. Where is the Japanese restaurant? | Certo. Onde fica o restaurante japonês? |
| **Alice** | It's on Foster Street, next to a bank and just across the movie theater. | Fica na Foster Street, ao lado de um banco e bem em frente ao cinema. |
| **Peter** | I think I know this movie theater. It's between a pub and a flower shop, right? | Acho que conheço esse cinema. Fica entre um pub e uma floricultura, certo? |
| **Alice** | Yes, that's it. | Sim, é isso. |
| **Peter** | Great! But how can I get there from here? | Ótimo! Mas como posso chegar lá daqui? |
| **Alice** | Well, it's very easy. First, go down this street for five blocks. Then, turn left at the traffic light. | Bem, é muito fácil. Primeiro, desça esta rua por cinco quadras. Depois, vire à esquerda no semáforo. |
| **Alice** | Now, go ahead for two blocks and turn right on Virginia Avenue. | Agora, siga em frente por duas quadras e vire à direita na Avenida Virginia. |
| **Alice** | On Virginia Avenue, go ahead for three blocks. The restaurant is on your left, just past the drugstore. | Na Avenida Virginia, siga em frente por três quadras. O restaurante ficará à sua esquerda, logo depois da farmácia. |
| **Peter** | Well, it looks simple. | Bem, parece simples. |
| **Alice** | And it is very easy. You can't miss it. | E é muito fácil. Você não pode errar. |
| **Peter** | Thank you very much, Alice. Well, maybe you could go have lunch with me. What do you say? | Muito obrigado, Alice. Bem, talvez você pudesse ir almoçar comigo. O que você acha? |
| **Alice** | Sorry, Peter, I can't. I'm waiting for my boyfriend. | Desculpe, Peter, não posso. Estou esperando pelo meu namorado. |
| **Peter** | Oh, I'm sorry. | Oh, sinto muito. |
| **Alice** | That's okay. I hope you like the restaurant. Goodbye and thanks again. | Tudo bem. Espero que você goste do restaurante. Tchau e obrigada novamente. |

---

### 📚 **Análise do Conteúdo e Vocabulário**

#### **🧭 Substantivos (Nouns)**
- **Lugares (Places):** `restaurant`, `neighborhood`, `bank`, `movie theater`, `pub`, `flower shop`, `traffic light`, `drugstore`/`pharmacy`, `bakery`, `street`, `avenue`, `block`, `corner`.
- **Pessoas:** `boyfriend`.
- **Coisas:** `lunch`, `food`, `snacks`, `soft drink`, `help`, `name`.

#### **📝 Adjetivos (Adjectives)**
- `good`, `great`, `fantastic`, `amazing`, `awesome`, `wonderful` (todos transmitem ideia de "excelente").
- `Italian`, `Japanese`.
- `lost` (perdido), `easy`/`simple` (fácil/simples), `far` (longe).

#### **📍 Preposições de Lugar (Prepositions of Place)**
- `on` (em, para ruas/avenidas): `on Foster Street`, `on Virginia Avenue`.
- `next to` / `beside` (ao lado de): `next to a bank`.
- `across from` (do outro lado da rua de): `across the movie theater`.
- `between` (entre dois elementos): `between a pub and a flower shop`.
- `at` (em, para pontos específicos): `at the traffic light`.
- `past` (depois de, após passar por): `just past the drugstore`.
- `on the corner of` (na esquina de): `on the corner of Number One Street and Number Three Avenue`.
- `around` (nas redondezas, por perto): `Is there a restaurant around?`.

#### **💡 Expressões e Estruturas Chave**
- **`Excuse me`**: Com licença (para iniciar um contato).
- **`Can you help me?`**: Você pode me ajudar? (`Can` é um verbo modal).
- **`Is there a...?`** / **`Are there some...?`**: Existe um...? / Existem alguns...? (para perguntar sobre existência).
- **`What kind of... do you like?`**: Que tipo de... você gosta?
- **`How can I get to...?`**: Como posso chegar ao/à...?
- **`Go down the street`**: Desça/Siga a rua.
- **`Turn left` / `Turn right`**: Vire à esquerda/direita.
- **`Go ahead`**: Siga em frente.
- **`You can't miss it`**: É impossível não achar / Você não vai errar.
- **`What do you say?`**: O que você acha? (fazendo um convite).
- **`I hope you like...`**: Eu espero que você goste de... (`hope` = ter esperança, esperançar).

---

### ✅ **Notas Finais e Dicas de Pronúncia**
- **Prática:** A chave é repetir o diálogo, assumindo os papéis de Peter e Alice.
- **Personalização:** Crie sua própria versão do diálogo, substituindo os lugares e as direções.
- ** Pronúncia:**
    - **`What's your`** soa como "wá-tchior".
    - **`Nice to meet you`** soa como "naiss tô mí-tchiu".
    - **`Kind of`** soa como "kain-dâv".
    - A entonação em perguntas (`Where is...?`, `How can I...?`) deve subir no final.