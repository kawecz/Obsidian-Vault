---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - dialogo
---

---
<iframe title="Inglês | Kultivi - Places in Town: Dialogue III | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/LfdNgrV01HU?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Prática de Diálogo - Revisão e Consolidação
> Este é um vídeo de prática pura. Após duas aulas anteriores de explicação detalhada, o foco aqui é na repetição, fluência e internalização do diálogo entre o casal (Carla e William) planejando um passeio. O objetivo é que o aluno participe ativamente, assumindo os papéis e desenvolvendo confiança na conversação.

[[aula2.3.pdf]]

---

### 🎯 **Objetivo e Estrutura da Aula de Prática**

- **Objetivo:** Desenvolver fluência e confiança através da repetição ativa e da simulação de conversação.
- **Não há** explicações de vocabulário ou gramática neste vídeo.
- **Metodologia em 3 Etapas:**
    1.  **Repetição Guiada:** O professor lê o diálogo completo, frase por frase, com pausas para o aluno repetir.
    2.  **Prática de Papéis (Role-play) - 1ª Rodada:** O aluno assume um personagem (William) e o professor faz o outro (Carla).
    3.  **Prática de Papéis (Role-play) - 2ª Rodada:** Os papéis são invertidos. O aluno agora é a Carla e o professor é o William.

---

### 📝 **Tema Central do Diálogo para Prática**

Um casal (Carla e William) planeja um passeio turístico. Eles discutem:
- Visitando o zoológico.
- Voltando para a cidade.
- Pegando um ônibus para o shopping.
- Visitando a prefeitura (`city hall`) e o museu de arte (`art museum`).
- Uma conversa descontraída sobre gastar dinheiro e cartão de crédito.

---

### 💡 **Instruções Finais para Estudo Avançado (Pós-Vídeo)**

- **Reescreva o Diálogo:** Copie o diálogo completo no seu caderno, corrigindo quaisquer erros de digitação que você notou durante as explicações nos vídeos anteriores.
- **Personalize o Diálogo (Atividade Chave):** Use a estrutura do diálogo como base, mas modifique os elementos. Isso força a aplicação criativa do idioma.
    - **Exemplo de Modificação:** Troque "zoológico" por "aquário", "prefeitura" por "estação de trem", "shopping" por "parque". Mude as direções e os meios de transporte.
- **Pratique com a Versão Personalizada:** Repita os exercícios de role-play do vídeo, mas usando o NOVO diálogo que você criou. Isso solidifica o aprendizado e vai além da memorização.

---
**Foco da Aula:** Pronúncia, entonação, ritmo de fala e confiança na conversação. A participação ativa do aluno é fundamental.