---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - partes_casa
---

---
<iframe title="Inglês | Kultivi Extra Class - Prepositions of Place II | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/rRpbz5Xipgo?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Preposições de Lugar e Movimento (Prepositions of Place and Movement) - Parte II
> Esta segunda parte foca em preposições que indicam movimento e direção, complementando o vocabulário de localização estática. A aula explora os pares de opostos (up/down, into/out of) e verbos associados a deslocamentos.

[[../aula1.pdf|aula1]]

---

### 🏃 **Preposições de Movimento e Direção**

| Preposição | Conceito | Uso e Exemplos |
| :--- | :--- | :--- |
| **Up** | Movimento para cima, ascensão. | `Go up the stairs.` (Suba as escadas.) |
| **Down** | Movimento para baixo, descida. | `Sit down.` (Sente-se.) / `The ball fell down.` (A bola caiu.) |
| **Into** | Movimento de entrada, para dentro de algo. | `Go into the house.` (Entre na casa.) / `Look into my eyes.` (Olhe dentro dos meus olhos.) |
| **Out of** | Movimento de saída, para fora de algo. | `Get out of the car.` (Saia do carro.) |
| **Onto** | Movimento para uma superfície, estabelecendo contato. | `The cat jumped onto the chair.` (O gato pulou para a cadeira.) |
| **Off** | Movimento para fora de uma superfície, removendo o contato. | `Take the picture off the wall.` (Tire o quadro da parede.) |
| **Through** | Movimento de atravessar, passar de um lado a outro através de algo. | `We went through many problems.` (Passamos por muitos problemas.) / `Walk through the park.` (Caminhe pelo parque.) |

---

### 🔄 **Pares de Opostos e Nuances**

| Conceito | Preposição (Movimento) | Exemplo |
| :--- | :--- | :--- |
| **Para Cima / Para Baixo** | **Up** / **Down** | `Go up the hill.` (Suba a colina.) / `Walk down the street.` (Desça a rua.) |
| **Entrada / Saída** | **Into** / **Out of** | `Come into the room.` (Entre no quarto.) / `Get out of the room.` (Saia do quarto.) |
| **Estabelecer Contato / Remover Contato** | **Onto** / **Off** | `Put the book onto the table.` (Coloque o livro na mesa.) / `The cat jumped off the roof.` (O gato pulou do telhado.) |

---

### 💡 **Verbos de Comando e Movimento**

| Comando (Inglês) | Tradução | Contexto de Uso |
| :--- | :--- | :--- |
| **Come up.** | Venha para cima. | Quando você está em um nível superior. |
| **Go up.** | Vá para cima. | Quando você está em um nível inferior. |
| **Come down.** | Venha para baixo. | Quando você está em um nível inferior. |
| **Go down.** | Vá para baixo. | Quando você está em um nível superior. |
| **Come in.** / **Go into...** | Venha para dentro. / Entre em... | Convite para entrar. |
| **Go out.** / **Get out of...** | Vá para fora. / Saia de... | Pedido para sair. |

---

### 📚 **Aplicação em Frases**

| Frase | Tradução | Preposição e Conceito |
| :--- | :--- | :--- |
| **The cat jumped through the window.** | O gato pulou através da janela. | **Through**: Movimento atravessando um espaço. |
| **He went into the store.** | Ele entrou na loja. | **Into**: Movimento de entrada. |
| **Please, take your shoes off.** | Por favor, tire seus sapatos. | **Off**: Remover algo de uma superfície (seus pés). |
| **She is walking up the stairs.** | Ela está subindo as escadas. | **Up**: Movimento de ascensão. |