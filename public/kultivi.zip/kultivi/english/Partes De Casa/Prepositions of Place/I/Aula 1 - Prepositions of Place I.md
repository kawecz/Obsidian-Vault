---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - partes_casa
---

---
<iframe title="Inglês | Kultivi Extra Class - Prepositions of Places I | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/oaXc-WspRvo?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Preposições de Lugar (Prepositions of Place) - Parte I
> Esta aula introduz preposições fundamentais para descrever a localização de pessoas e objetos no espaço. O foco está em compreender a relação espacial entre os elementos, indo além da simples tradução.

[[../aula1.pdf|aula1]]

---

### 🗺️ **Visão Geral das Preposições**

| Preposição | Conceito Central | Tradução Comum |
| :--- | :--- | :--- |
| **On** | Contato direto com uma superfície. | Sobre, em |
| **Under** | Posicionado abaixo, sem contato. | Embaixo de |
| **In Front Of** | À frente, na parte dianteira. | Na frente de |
| **Behind** | Na parte traseira, nas costas. | Atrás de |
| **Next To / Beside** | Adjacente, imediatamente ao lado. | Ao lado de, próximo a |
| **Below** | Em uma posição mais baixa (geralmente sem contato). | Abaixo de |
| **Over / Above** | Em uma posição mais alta, sem contato. | Acima de, por cima de |
| **In / Inside** | No interior, contido. | Dentro de |
| **Out / Outside** | Na parte externa, não contido. | Fora de |
| **Between** | No espaço que separa **dois** elementos. | Entre (dois) |
| **Among** | No meio de, cercado por **três ou mais** elementos. | Entre (vários) |
| **Around** | Formando um círculo ao redor. | Em volta de, ao redor de |
| **Near / Close To** | Proximidade, mas não necessariamente adjacente. | Perto de, próximo a |

---

### 📍 **Tabela de Uso e Aplicação**

| Preposição | Exemplo | Explicação Visual |
| :--- | :--- | :--- |
| **On** | `The book is on the table.` | Livro em contato com a superfície da mesa. |
| **Under** | `The cat is under the bed.` | Gato posicionado abaixo da cama. |
| **In Front Of** | `The car is in front of the house.` | Carro está à frente da casa. |
| **Behind** | `The garden is behind the house.` | Jardim localizado atrás da casa. |
| **Next To / Beside** | `The bank is next to the bakery.` | Banco imediatamente ao lado da padaria. |
| **Below** | `The fish are below the surface.` | Peixes estão em posição mais baixa que a superfície. |
| **Over / Above** | `The lamp is over the table.` | Lâmpada pendurada acima da mesa (sem contato). |
| **In / Inside** | `The keys are in the drawer.` | Chaves contidas dentro da gaveta. |
| **Out / Outside** | `The kids are playing outside.` | Crianças brincando do lado de fora (de casa). |
| **Between** | `The park is between the school and the mall.` | Parque no espaço que separa a escola do shopping. |
| **Among** | `She was among friends.` | Ela estava no meio de (cercada por) amigos. |
| **Around** | `They sat around the campfire.` | Eles sentaram formando um círculo em volta da fogueira. |
| **Near / Close To** | `I live near the airport.` | Moro perto do aeroporto (não necessariamente ao lado). |

---

### 💡 **Diferenças e Nuances Importantes**

- **On vs. Over/Above:**
    - `On`: Contato direto. (O livro está *sobre* a mesa).
    - `Over/Above**: Sem contato, em posição superior. (O avião voa *sobre* a cidade).

- **Next To/Beside vs. Near/Close To:**
    - `Next to/Beside**: Imediatamente adjacente. (Sento *ao lado* do João).
    - `Near/Close To**: Proximidade geral. (Moro *perto* do parque).

- **Between vs. Among:**
    - `Between`: Usado para **dois** elementos. (Entre a minha casa *e* a sua).
    - `Among`: Usado para **três ou mais** elementos. (Entre os convidados).

- **Below vs. Under:**
    - `Below`: Foca na posição mais baixa em uma hierarquia ou escala. (Temperatura *abaixo* de zero).
    - `Under`: Foca em estar coberto ou diretamente sob algo. (O gato está *embaixo* do cobertor).

---

### 📚 **Vocabulário de Suporte**

- **Objetos:** `box`, `ball`, `table`, `chair`, `wall`, `door`, `house`, `drawer`, `stapler`, `computer`.
- **Lugares:** `gas station`, `garage`, `police station`, `hospital`, `church`, `pub`, `bar`.
- **Pessoas/Animais:** `boy`, `dog`, `cat`, `mouse`, `bird`, `husband`.