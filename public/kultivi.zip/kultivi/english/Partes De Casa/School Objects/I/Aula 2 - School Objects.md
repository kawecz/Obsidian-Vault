---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - partes_casa
---

---
<iframe title="Inglês | Kultivi Extra Class - School Objects I | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/LcNthyAMpa8?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Objetos Escolares (School Objects) - Parte I
> Esta aula introduz vocabulário fundamental sobre objetos comuns em um ambiente escolar. O foco é na pronúncia correta e no uso dessas palavras em frases contextuais.

[[../aula2.pdf|aula2]]

---

### 🎒 **Vocabulário de Objetos Escolares**

| Objeto (Inglês) | Pronúncia | Tradução | Exemplo de Uso |
| :--- | :--- | :--- | :--- |
| **Attendance Sheet** | /əˈtendəns ʃiːt/ | Folha de Chamada | `There are many absences on the attendance sheet.` (Há muitas faltas na folha de chamada.) |
| **Backpack** | /ˈbækpæk/ | Mochila | `My backpack is full of school objects.` (Minha mochila está cheia de objetos escolares.) |
| **Chalkboard** | /ˈtʃɔːkbɔːrd/ | Quadro Negro / Lousa | `The teacher writes on the chalkboard.` (O professor escreve no quadro negro.) |
| **Book** | /bʊk/ | Livro | `This book is very expensive.` (Este livro é muito caro.) |
| **Calculator** | /ˈkælkjuleɪtər/ | Calculadora | `The calculator is out of battery.` (A calculadora está sem bateria.) |
| **Calendar** | /ˈkælɪndər/ | Calendário | `I need to schedule a meeting on the calendar.` (Preciso marcar uma reunião no calendário.) |
| **Eraser** | /ɪˈreɪsər/ | Borracha / Apagador | `If you make a mistake, you can erase it with an eraser.` (Se cometer um erro, pode apagá-lo com uma borracha.) |
| **Chalk** | /tʃɔːk/ | Giz | `We use chalk to write on the chalkboard.` (Usamos giz para escrever no quadro negro.) |
| **Clipboard** | /ˈklɪpbɔːrd/ | Prancheta | `I watch a play at the school theater and take a clipboard to jot things down.` (Assisto uma peça no teatro da escola e levo uma prancheta para anotar coisas.) |
| **Color Pencils** | /ˈkʌlər ˈpensəls/ | Lápis de Cor | `Every boy wants to have a big set of color pencils.` (Todo garoto quer ter um grande conjunto de lápis de cor.) |
| **Computer** | /kəmˈpjuːtər/ | Computador | `The school has a cyber lab with 10 computers.` (A escola tem um laboratório de informática com 10 computadores.) |

---

### 📝 **Notas de Pronúncia e Vocabulário**

- **The:** A pronúncia do artigo "the" muda.
    - `The school` → Pronúncia: /ðə skuːl/ (antes de consoantes).
    - `The apple` → Pronúncia: /ði ˈæp.əl/ (antes de vogais).

- **School:** Significa "escola", mas também significa "cardume" (de peixes).

- **Backpack:** Etimologia - "Back" (costas) + "Pack" (pacote) = Pacote para as costas.

- **Chalkboard vs. Board:**
    - `Chalkboard`: Quadro para escrever com **giz**.
    - `Board`: Quadro de forma geral (pode ser branco, de acrílico). Para quadros brancos, usa-se `marker` (canetão).

- **To Borrow vs. To Lend:**
    - **To Borrow:** Pegar emprestado. (`Can I borrow your pen?` - Posso pegar sua caneta emprestada?)
    - **To Lend:** Emprestar. (`Can you lend me your pen?` - Você pode me emprestar sua caneta?)

- **Jot Down:** Expressão idiomática que significa "anotar rapidamente", "tomar notas".

- **Crayon:** /ˈkreɪ.ən/ - Giz de cera.

---

### 🗣️ **Verbos e Expressões Úteis**

| Verbo/Expressão | Tradução | Uso |
| :--- | :--- | :--- |
| **To Write** | Escrever | `Write on the board.` (Escreva no quadro.) |
| **To Read** | Ler | `Read the book.` (Leia o livro.) |
| **To Need** | Precisar | `I need a calculator.` (Preciso de uma calculadora.) |
| **To Schedule / To Mark** | Marcar (no calendário) | `Schedule an appointment.` (Marque um compromisso.) |
| **To Make a Mistake** | Cometer um erro | `It's ok to make a mistake.` (Tudo bem cometer um erro.) |
| **To Erase** | Apagar | `Erase the mistake.` (Apague o erro.) |
| **To Watch** | Assistir (TV, peça) | `Watch a play.` (Assistir a uma peça.) |
| **To Take** | Levar | `Take a clipboard.` (Leve uma prancheta.) |
| **To Want** | Querer | `I want a new backpack.` (Quero uma mochila nova.) |