---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - moveis_objetos
---

---
<iframe title="Inglês | Kultivi Extra Class - Subject and Objetc Pronouns | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/8zOuHu8_bHE?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Pronomes Sujeito e Objeto (Subject and Object Pronouns)
> Esta aula de gramática explica a diferença fundamental entre os pronomes que funcionam como sujeito (quem pratica a ação) e os que funcionam como objeto (quem recebe a ação) na frase. Compreender essa distinção é crucial para a construção de frases corretas em inglês.

---

### 🧠 **Revisão de Conceitos Gramaticais**

- **Sujeito (Subject):** Quem pratica a ação do verbo. Responde à pergunta "Quem?".
- **Objeto (Object):** Quem ou o que recebe a ação do verbo.
- **Estrutura Básica da Frase:** `Sujeito + Verbo + Objeto`.

**Exemplo em Português:**
- **Frase:** "Paulo trabalhou com Ana."
- **Sujeito:** `Paulo` (pratica a ação).
- **Verbo:** `trabalhou`.
- **Objeto:** `Ana` (recebe a ação).

---

### 📚 **Pronomes Sujeito (Subject Pronouns)**

| Pessoa (Português) | Pronome Sujeito (Inglês) | Uso | Exemplo (Substituindo o Sujeito) |
| :--- | :--- | :--- | :--- |
| **1ª Singular (Eu)** | **I** | A pessoa que fala. | `Paulo is my friend.` -> **`He`** `is my friend.` |
| **2ª Singular (Você)** | **You** | A pessoa com quem se fala. | `You and Jack finished university.` -> **`You`** `finished university.` |
| **3ª Singular Masculino (Ele)** | **He** | Um homem/garoto. | `Selma works hard.` -> **`She`** `works hard.` |
| **3ª Singular Feminino (Ela)** | **She** | Uma mulher/garota. | `The bird sings.` -> **`It`** `sings.` |
| **3ª Singular Neutro (Ele/Ela para coisas/animais)** | **It** | Um objeto, animal ou ideia. | `Matt and I are working.` -> **`We`** `are working.` |
| **1ª Plural (Nós)** | **We** | O grupo que inclui "eu". | `You and Jack finished university.` -> **`You`** `finished university.` |
| **2ª Plural (Vocês)** | **You** | O grupo com quem se fala. | `Philip and Maggie are late.` -> **`They`** `are late.` |
| **3ª Plural (Eles/Elas)** | **They** | Um grupo de pessoas, animais ou coisas. | `Philip and Maggie are late.` -> **`They`** `are late.` |

**Nota sobre "It":** Usado para objetos, animais não humanizados (`the bird` -> `it`) e ideias abstratas. Animais de estimação com nome podem ser tratados como `he` ou `she`.

---

### 📝 **Pronomes Objeto (Object Pronouns)**

| Pessoa (Português) | Pronome Objeto (Inglês) | Equivalente Aproximado em Português | Exemplo (Substituindo o Objeto) |
| :--- | :--- | :--- | :--- |
| **1ª Singular (Me/Mim)** | **Me** | Me, mim, comigo | `I talk to my father.` -> `I talk to **him**.` |
| **2ª Singular (Você)** | **You** | Você, te, ti, contigo | `That game was hard for you.` -> `It was hard for **you**.` |
| **3ª Singular Masculino (Ele)** | **Him** | O, a, lhe, ele | `Peter visited Mrs. Taylor.` -> `Peter visited **her**.` |
| **3ª Singular Feminino (Ela)** | **Her** | A, lhe, ela | `Lily went with the dog.` -> `Lily went with **it**.` |
| **3ª Singular Neutro (Ele/Ela)** | **It** | O, a, lhe (para coisas) | `Emily told Matt and I.` -> `Emily told **us**.` |
| **1ª Plural (Nos)** | **Us** | Nos, conosco | `That game was hard for you and your dad.` -> `It was hard for **you**.` |
| **2ª Plural (Vocês)** | **You** | Vocês, lhes, com vocês | `I bought a gift for Mary and Paul.` -> `I bought a gift for **them**.` |
| **3ª Plural (Eles/Elas)** | **Them** | Os, as, lhes, eles, elas | `I bought a gift for Mary and Paul.` -> `I bought a gift for **them**.` |

---

### 🔁 **Tabela de Comparação: Sujeito vs. Objeto**

| Função | 1ª Pessoa | 2ª Pessoa | 3ª Pessoa (Masc.) | 3ª Pessoa (Fem.) | 3ª Pessoa (Neutro) | 1ª Pessoa Plural | 2ª Pessoa Plural | 3ª Pessoa Plural |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Sujeito** | I | You | He | She | It | We | You | They |
| **Objeto** | Me | You | Him | Her | It | Us | You | Them |

---

### 💡 **Exemplos Práticos de Substituição**

1.  **Sujeito:**
    - `Paulo is my friend.` -> **`He`** `is my friend.`
    - `Selma works hard.` -> **`She`** `works hard.`
    - `The bird sings.` -> **`It`** `sings.`

2.  **Objeto:**
    - `I talk to my father.` -> `I talk to **him**.`
    - `Peter visited Mrs. Taylor.` -> `Peter visited **her**.`
    - `Emily told Matt and I.` -> `Emily told **us**.`

3.  **Frase Completa com Ambos:**
    - `Peter visited Mrs. Taylor.` -> **`He`** `visited **her**.` (Ele visitou-a.)