---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - moveis_objetos
---

---
<iframe title="Inglês | Kultivi Extra Class - In The Bathroom II | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/mz4v7QgsuA0?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: No Banheiro (In The Bathroom) - Parte II
> Esta segunda parte expande o vocabulário do banheiro, focando em itens de higiene pessoal, cuidados com o cabelo e objetos de uso comum. A aula também introduz estruturas para descrever a utilidade desses itens.

---

### 🚰 **Objetos e Estruturas do Banheiro**

| Objeto (Inglês) | Pronúncia | Tradução | Contexto/Exemplo |
| :--- | :--- | :--- | :--- |
| **Sink** | /sɪŋk/ | Pia |  |
| **Tap / Faucet** | /tæp/ /ˈfɔː.sɪt/ | Torneira | `Some sinks have two taps: one for hot and one for cold water.` (Algumas pias têm duas torneiras: uma para água quente e outra para fria.) |
| **First Aid Kit** | /fɜːrst eɪd kɪt/ | Kit de Primeiros Socorros | `It's a great idea to have a first aid kit in the bathroom. It may come in handy anytime.` (É uma ótima ideia ter um kit de primeiros socorros no banheiro. Pode ser útil a qualquer hora.) |
| **Liquid Soap** | /ˈlɪk.wɪd səʊp/ | Sabão Líquido | `Liquid soap is commonly found by the sink.` (O sabão líquido é comumente encontrado perto da pia.) |
| **Medicine Cabinet** | /ˈmed.ɪ.sən ˈkæb.ɪ.nət/ | Armário de Banheiro | `You can keep many things in your medicine cabinet.` (Você pode guardar muitas coisas no seu armário de banheiro.) |
| **Mirror** | /ˈmɪr.ər/ | Espelho | `Sometimes people don't have a medicine cabinet, they only have a mirror hanging over the sink.` (Às vezes as pessoas não têm um armário, elas só têm um espelho pendurado sobre a pia.) |
| **Mouthwash** | /ˈmaʊθ.wɒʃ/ | Enxaguante Bucal | `After brushing your teeth and using dental floss, use mouthwash to finish the cleaning.` (Após escovar os dentes e usar fio dental, use enxaguante bucal para terminar a limpeza.) |
| **Toilet** | /ˈtɔɪ.lət/ | Vaso Sanitário / Privada |  |
| **Floor Drain** | /flɔːr dreɪn/ | Ralo | `If the toilet or floor drain gets clogged, use a plunger to make the water flow again.` (Se a privada ou o ralo entupir, use um desentupidor para fazer a água fluir novamente.) |
| **Razor** | /ˈreɪ.zər/ | Barbeador / Navalha | `There are lots of types of razors. Many barbers still use the old ones.` (Existem muitos tipos de barbeadores. Muitos barbeiros ainda usam os antigos.) |
| **Shampoo** | /ʃæmˈpuː/ | Shampoo |  |
| **Hair Conditioner** | /heər kənˈdɪʃ.ən.ər/ | Condicionador | `After shampooing your hair, use hair conditioner to make it smooth and easier to comb.` (Após lavar o cabelo com shampoo, use condicionador para deixá-lo liso e mais fácil de pentear.) |
| **Shower Brush** | /ˈʃaʊ.ər brʌʃ/ | Escova de Banho (para as costas) | `Often, it is hard to wash your back in the shower. That is why a shower brush is so important.` (Muitas vezes, é difícil lavar suas costas no chuveiro. É por isso que uma escova de banho é tão importante.) |
| **Shower** | /ˈʃaʊ.ər/ | Chuveiro / Ducha | `After a hard day of work, a hot shower works wonders.` (Após um dia duro de trabalho, um banho quente faz milagres.) |

---

### 💡 **Verbos e Expressões Úteis**

| Verbo/Expressão | Tradução | Uso |
| :--- | :--- | :--- |
| **To come in handy** | Ser útil, vir a calhar | `It may come in handy anytime.` (Pode ser útil a qualquer hora.) |
| **To hang (hung)** | Pendurar | `A mirror hanging over the sink.` (Um espelho pendurado sobre a pia.) |
| **To finish** | Terminar | `Use mouthwash to finish the cleaning.` (Use enxaguante bucal para terminar a limpeza.) |
| **To get clogged** | Entupir | `If the toilet gets clogged...` (Se a privada entupir...) |
| **To make** | Fazer | `...to make the water flow again.` (...para fazer a água fluir novamente.) |
| **To flow** | Fluir | `...to make the water flow again.` |
| **To shampoo** | Lavar o cabelo (com shampoo) | `After shampooing your hair...` (Após lavar seu cabelo...) |
| **To work wonders** | Fazer milagres | `A hot shower works wonders.` (Um banho quente faz milagres.) |

---

### 📝 **Notas de Pronúncia e Vocabulário**

- **Soap** (sabão): Pronúncia /səʊp/ (soa como "soup"). ❌ Não confundir com **Soup** (/suːp/ - sopa).
- **Razor**: Barbeador ou navalha. A lâmina é chamada de **blade**.
- **Barber**: Barbeiro.
- **Smooth**: Liso, suave, sedoso.
- **Easier to comb**: Mais fácil de pentear.