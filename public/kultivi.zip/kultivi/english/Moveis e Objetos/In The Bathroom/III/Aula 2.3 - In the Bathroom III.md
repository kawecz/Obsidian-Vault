---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - moveis_objetos
---

---
<iframe title="Inglês | Kultivi Extra Class - In The Bathroom III | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/vhXfUfqj-HE?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: No Banheiro (In The Bathroom) - Parte III
> Este terceiro e último vídeo da série conclui o vocabulário essencial do banheiro, abordando itens de higiene, organização e verbos de ação fundamentais para descrever rotinas e situações neste cômodo.

---

### 🧴 **Itens de Higiene e Organização**

| Objeto (Inglês) | Pronúncia | Tradução | Contexto/Exemplo |
| :--- | :--- | :--- | :--- |
| **Bath Towel** | /bæθ taʊəl/ | Toalha de Banho | `Always hang your bath towel after the shower.` (Sempre pendure sua toalha de banho após o banho.) |
| **Face Towel** | /feɪs taʊəl/ | Toalha de Rosto |  |
| **Hand Towel** | /hænd taʊəl/ | Toalha de Mão |  |
| **Toilet Paper** | /ˈtɔɪ.lət ˈpeɪ.pər/ | Papel Higiênico | `Make sure you never run out of toilet paper.` (Certifique-se de nunca ficar sem papel higiênico.) |
| **Toilet Brush** | /ˈtɔɪ.lət brʌʃ/ | Escova de Vaso Sanitário | `You need a toilet brush to keep the toilet clean.` (Você precisa de uma escova de vaso para manter a privada limpa.) |
| **Toothbrush** | /ˈtuːθ.brʌʃ/ | Escova de Dentes | `Keep your toothbrush inside the medicine cabinet.` (Mantenha sua escova de dentes dentro do armário do banheiro.) |
| **Toothpaste** | /ˈtuːθ.peɪst/ | Pasta de Dente | `We need to buy more toothpaste.` (Precisamos comprar mais pasta de dente.) |
| **Towel Rack** | /ˈtaʊ.əl ræk/ | Cabideiro de Toalhas | `Hang the towels on the towel rack.` (Pendure as toalhas no cabideiro.) |
| **Cabinet** | /ˈkæb.ɪ.nət/ | Armário | `We store towels and toilet paper in the cabinet.` (Guardamos toalhas e papel higiênico no armário.) |

---

### 🧹 **Verbos de Ação no Banheiro**

| Verbo (Inglês) | Pronúncia | Tradução | Uso |
| :--- | :--- | :--- | :--- |
| **To hang (hung)** | /hæŋ/ (/hʌŋ/) | Pendurar | `Hang the towel on the rack.` (Pendure a toalha no cabideiro.) |
| **To flush** | /flʌʃ/ | Dar descarga | `Don't forget to flush the toilet.` (Não se esqueça de dar descarga.) |
| **To need** | /niːd/ | Precisar | `You need a toilet brush.` (Você precisa de uma escova de vaso.) |
| **To keep** | /kiːp/ | Manter, Guardar | `Keep your toothbrush inside the cabinet.` (Guarde sua escova de dentes dentro do armário.) |
| **To store** | /stɔːr/ | Armazenar, Guardar | `We store towels in the cabinet.` (Guardamos toalhas no armário.) |
| **To run out (of)** | /rʌn aʊt/ | Ficar sem | `We are running out of toilet paper.` (Estamos ficando sem papel higiênico.) |
| **To use** | /juːz/ | Usar | `After using the toilet...` (Após usar a privada...) |
| **To forget** | /fərˈɡet/ | Esquecer | `Don't forget to flush.` (Não se esqueça de dar descarga.) |

---

### 💡 **Expressões e Estruturas Úteis**

- **`Run out of`**: Ficar sem algo. (`We ran out of toilet paper.` - Ficamos sem papel higiênico.)
- **`Make sure...`**: Certificar-se de que... (`Make sure you never run out.` - Certifique-se de nunca ficar sem.)
- **`Don't forget to...`**: Não se esqueça de... (Usado para dar lembretes importantes).
- **Preposições de Lugar:**
    - `Inside the cabinet` (Dentro do armário)
    - `On the towel rack` (No cabideiro de toalhas)
    - `After the shower` (Após o banho)

---

### 🗣️ **Frases de Exemplo para Prática**

1.  **`Always hang your bath towel on the towel rack after the shower.`** (Sempre pendure sua toalha de banho no cabideiro após o banho.)
2.  **`Don't forget to flush the toilet after using it.`** (Não se esqueça de dar descarga após usar a privada.)
3.  **`We keep our toothbrushes and toothpaste inside the medicine cabinet.`** (Guardamos nossas escovas e pasta de dente dentro do armário do banheiro.)
4.  **`Make sure you never run out of toilet paper.`** (Certifique-se de nunca ficar sem papel higiênico.)
5.  **`You need a toilet brush to clean the toilet.`** (Você precisa de uma escova de vaso para limpar a privada.)