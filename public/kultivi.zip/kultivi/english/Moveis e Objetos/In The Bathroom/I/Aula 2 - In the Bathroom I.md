---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - moveis_objetos
---

---
<iframe title="Inglês | Kultivi Extra Class - In The Bathroom I | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/aZMQQVah_Ow?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: No Banheiro (In The Bathroom) - Parte I
> Esta aula introduz o vocabulário essencial de objetos e ações relacionadas ao banheiro. O foco está em itens de higiene pessoal e verbos de ação comuns nesse ambiente.


---

### 🛁 **Objetos no Banheiro (Objects in the Bathroom)**

| Objeto (Inglês) | Pronúncia | Tradução | Contexto/Exemplo |
| :--- | :--- | :--- | :--- |
| **Bathtub** | /ˈbæθ.tʌb/ | Banheira | `The best thing to do after a tiring day is to take a bath.` (A melhor coisa a fazer após um dia cansativo é tomar um banho de banheira.) |
| **Shower** | /ˈʃaʊ.ər/ | Chuveiro / Ducha |  |
| **Q-tips / Cotton Swabs**| /ˈkjuː.tɪps/ /ˈkɒt.ən swɒbz/ | Cotonetes | `Q-tips help you to dry the inside of your ears.` (Cotonetes ajudam a secar o interior das suas orelhas.) |

---

### 🚿 **Verbos e Ações (Verbs and Actions)**

| Verbo/Ação (Inglês) | Pronúncia | Tradução | Uso |
| :--- | :--- | :--- | :--- |
| **To take a bath** | /teɪk ə bæθ/ | Tomar banho (de banheira) |  |
| **To take a shower** | /teɪk ə ˈʃaʊ.ər/ | Tomar banho (de chuveiro) |  |
| **To dry** | /draɪ/ | Secar | `To dry the inside of your ears.` (Secar o interior das orelhas.) |
| **To help** | /help/ | Ajudar | `Q-tips help you to dry...` (Cotonetes ajudam você a secar...) |

---

### 💡 **Expressões e Notas de Vocabulário**

- **"After a tiring day"**: Após um dia cansativo.
- **"The inside of your ears"**: O interior das suas orelhas.
- **"Please, help!"**: Por favor, ajude! (Pedido de socorro ou auxílio).