---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - moveis_objetos
---

---
<iframe title="Inglês | Kultivi Extra Class - Bedroom II | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/cp5aCuRfurc?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: No Quarto (In The Bedroom) - Parte II
> Esta segunda parte aprofunda o vocabulário do quarto, explorando móveis específicos, objetos de uso pessoal e verbos para descrever hábitos e condições dos itens deste cômodo.

---

### 🪑 **Móveis e Objetos Específicos**

| Objeto (Inglês) | Pronúncia | Tradução | Contexto/Exemplo |
| :--- | :--- | :--- | :--- |
| **Dresser** | /ˈdres.ər/ | Penteadeira / Cômoda com espelho | `My grandma still has her old dresser with that mirror.` (Minha avó ainda tem sua velha penteadeira com aquele espelho.) |
| **Lamp** | /læmp/ | Abajur | `I leave the lamp on in my son's room. He is afraid of the dark.` (Deixo o abajur ligado no quarto do meu filho. Ele tem medo do escuro.) |
| **Light Bulb** | /laɪt bʌlb/ | Lâmpada (o bulbo) |  |
| **Mattress** | /ˈmæt.rəs/ | Colchão | `She sold her old mattress and bought a new one.` (Ela vendeu seu colchão velho e comprou um novo.) |
| **Nightstand** | /ˈnaɪt.stænd/ | Mesa de Cabeceira / Criado-mudo | `The nightstand is a good place to have a lamp, a book, and maybe a jug of water.` (A mesa de cabeceira é um bom lugar para ter um abajur, um livro e talvez uma jarra d'água.) |
| **Pillowcase** | /ˈpɪl.əʊ.keɪs/ | Fronha | `The pillowcase is stained because you sweat a lot at night.` (A fronha está manchada porque você sua muito à noite.) |
| **Pillow** | /ˈpɪl.əʊ/ | Travesseiro | `My wife sleeps with four pillows. I can hardly use two.` (Minha esposa dorme com quatro travesseiros. Eu mal consigo usar dois.) |
| **Sheet** | /ʃiːt/ | Lençol | `White sheets are beautiful, but they get yellow over time.` (Lençóis brancos são bonitos, mas ficam amarelos com o tempo.) |
| **Wardrobe** | /ˈwɔːr.drəʊb/ | Guarda-Roupa (móvel) | `The new wardrobe has no doors; it just stays open. That prevents the clothes from getting moldy.` (O novo guarda-roupa não tem portas; ele simplesmente fica aberto. Isso evita que as roupas fiquem mofadas.) |
| **Closet** | /ˈklɒz.ɪt/ | Armário Embutido / Cômodo |  |

---

### 🔌 **Estados e Condições (States and Conditions)**

| Palavra/Expressão | Pronúncia | Tradução |
| :--- | :--- | :--- |
| **On** | /ɒn/ | Ligado |
| **Off** | /ɒf/ | Desligado |
| **Switch** | /swɪtʃ/ | Interruptor |
| **Afraid of the dark** | /əˈfreɪd əv ðə dɑːrk/ | Com medo do escuro |
| **Old** | /əʊld/ | Velho |
| **New** | /njuː/ | Novo |
| **Young** | /jʌŋ/ | Jovem (para pessoas) |
| **Stained** | /steɪnd/ | Manchado |
| **Moldy** | /ˈməʊl.di/ | Mofado |

---

### 🛌 **Verbos e Expressões de Ação**

| Verbo/Expressão | Pronúncia | Tradução | Uso |
| :--- | :--- | :--- | :--- |
| **To leave (on/off)** | /liːv/ | Deixar (ligado/desligado) | `I leave the lamp on.` (Deixo o abajur ligado.) |
| **To be afraid of** | /bi əˈfreɪd ɒv/ | Ter medo de | `He is afraid of the dark.` (Ele tem medo do escuro.) |
| **To sell (sold)** | /sel/ (/səʊld/) | Vender | `She sold her old mattress.` (Ela vendeu seu colchão velho.) |
| **To buy (bought)** | /baɪ/ (/bɔːt/) | Comprar | `She bought a new one.` (Ela comprou um novo.) |
| **To sweat** | /swet/ | Suar | `You sweat a lot at night.` (Você sua muito à noite.) |
| **To get + adj.** | /ɡet/ | Ficar (ex: `get yellow` - ficar amarelo) | `Sheets get yellow over time.` (Lençóis ficam amarelos com o tempo.) |
| **To stay** | /steɪ/ | Ficar, Permanecer | `It just stays open.` (Ele simplesmente fica aberto.) |
| **To prevent from** | /prɪˈvent frəm/ | Prevenir de, Impedir de | `That prevents the clothes from getting moldy.` (Isso impede que as roupas fiquem mofadas.) |

---

### 💡 **Notas de Pronúncia e Vocabulário**

- **Dresser vs. Closet:** `Dresser` é um móvel (penteadeira/cômoda). `Closet` é um armário embutido ou um cômodo para roupas.
- **Maybe:** /ˈmeɪ.bi/ - Talvez.
- **Jug / Pitcher:** /dʒʌɡ/ /ˈpɪtʃ.ər/ - Jarra.
- **Hardly:** /ˈhɑːd.li/ - Dificilmente, mal.
- **Wife** (esposa) / **Husband** (marido).