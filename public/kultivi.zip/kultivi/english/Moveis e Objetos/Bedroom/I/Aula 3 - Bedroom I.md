---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - moveis_objetos
---

---
<iframe title="Inglês | Kultivi Extra Class - Bedroom I | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/nceaXNffdOg?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: No Quarto (In The Bedroom) - Parte I
> Esta aula introduz o vocabulário fundamental relacionado ao quarto, focando em móveis, objetos e expressões para descrever a rotina de sono e a organização do ambiente.

---

### 🛏️ **Móveis e Objetos do Quarto**

| Objeto (Inglês) | Pronúncia | Tradução | Contexto/Exemplo |
| :--- | :--- | :--- | :--- |
| **Alarm Clock** | /əˈlɑːrm klɒk/ | Despertador | `My alarm clock always wakes me up at 6 a.m.` (Meu despertador sempre me acorda às 6 da manhã.) |
| **Bed** | /bed/ | Cama |  |
| **Bedside Table** / **Nightstand** | /ˈbed.saɪd ˌteɪ.bəl/ /ˈnaɪt.stænd/ | Mesa de Cabeceira |  |
| **Pillow** | /ˈpɪl.əʊ/ | Travesseiro |  |
| **Blanket** | /ˈblæŋ.kɪt/ | Cobertor | `It's too cold tonight. I think I'll need an extra blanket.` (Está muito frio esta noite. Acho que vou precisar de um cobertor extra.) |
| **Sheet** | /ʃiːt/ | Lençol |  |
| **Wardrobe** / **Closet** | /ˈwɔːr.drəʊb/ /ˈklɒz.ɪt/ | Guarda-Roupa / Armário | `I have a small wardrobe to store some books.` (Eu tenho um pequeno guarda-roupa para guardar alguns livros.) |
| **Chest of Drawers** / **Dresser** | /tʃest əv drɔːrz/ /ˈdres.ər/ | Cômoda | `I keep all my socks in the bottom drawer.` (Guardo todas as minhas meias na gaveta de baixo.) |
| **Lamp** | /læmp/ | Abajur / Lâmpada |  |
| **Curtains** | /ˈkɜː.tənz/ | Cortinas |  |

---

### 🕒 **Horários e Momentos do Dia**

| Expressão (Inglês) | Pronúncia | Tradução |
| :--- | :--- | :--- |
| **6 a.m.** | /sɪks eɪ ˈem/ | 6 horas da manhã |
| **Noon** / **Midday** | /nuːn/ /ˈmɪd.deɪ/ | Meio-dia |
| **p.m.** | /piː ˈem/ | Da tarde/noite (após o meio-dia) |
| **Tonight** | /təˈnaɪt/ | Esta noite |

---

### 💤 **Verbos e Expressões para Dormir**

| Verbo/Expressão | Pronúncia | Tradução | Uso |
| :--- | :--- | :--- | :--- |
| **To wake up** | /weɪk ʌp/ | Acordar | `My alarm clock wakes me up.` (Meu despertador me acorda.) |
| **To lie down** | /laɪ daʊn/ | Deitar-se | `I lie down on the bed and fall asleep immediately.` (Eu me deito na cama e pego no sono imediatamente.) |
| **To fall asleep** | /fɔːl əˈsliːp/ | Pegar no Sono / Adormecer |  |
| **To sleep** | /sliːp/ | Dormir |  |

---

### 💡 **Notas de Vocabulário e Uso**

- **`Too + adjetivo`**: Significa "muito" ou "demais" em sentido negativo. (`It's too cold` - Está muito frio).
- **`I think I'll need...`**: "Acho que vou precisar de...". Estrutura para expressar uma necessidade futura.
- **`Bottom drawer`**: A gaveta de baixo. (`Top drawer` seria a gaveta de cima).
- **`Small` / `Big`**: Pequeno / Grande.