---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - mais_conversacao
---

---
<iframe title="Inglês | Kultivi - How Does He Look Like I | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/xXUC1t6cVpQ?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Descrições Físicas - Tipos de Corpo e Cor dos Olhos
> Esta aula ensina vocabulário e estruturas para descrever o tipo de corpo (body types) e a cor dos olhos (eye color) de uma pessoa, habilidades essenciais para identificar ou descrever alguém em inglês.


[[../aula2.pdf|aula2]]

---

### 👤 **Tipos de Corpo (Body Types) - Tamanho e Constituição**

#### **Altura (Height):**
| Inglês | Pronúncia | Tradução |
| :--- | :--- | :--- |
| **Tall** | /tɔːl/ | Alto(a) |
| **Medium height** | /ˈmiː.diəm haɪt/ | Altura média |
| **Short** | /ʃɔːrt/ | Baixo(a) |

**Pergunta:** `Are you tall?` (Você é alto?)
**Resposta:** `Yes, I am.` / `No, I'm not.`

#### **Constituição Física (Build):**
| Inglês | Pronúncia | Tradução | Nuance |
| :--- | :--- | :--- | :--- |
| **Thin** | /θɪn/ | Magro(a) | Neutro. |
| **Skinny** | /ˈskɪn.i/ | Magrelo(a), seco(a) | Magreza extrema. |
| **Slim** / **Fit** | /slɪm/ /fɪt/ | Esbelto(a), em forma | Forma física saudável. |
| **In shape** | /ɪn ʃeɪp/ | Em forma | Expressão comum para boa forma. |
| **Chubby** | /ˈtʃʌb.i/ | Fofinho(a), acima do peso | Carinhoso ou estágio antes de "gordo". |
| **Fat** | /fæt/ | Gordo(a) | Termo direto, pode ser ofensivo. |
| **Well-built** | /ˌwel ˈbɪlt/ | Bem construído | Musculoso, forte. |
| **Bodybuilder** | /ˈbɒd.iˌbɪl.dər/ | Fisiculturista | Pratica musculação intensa. |

**Exemplos:**
- `She is not thin, she is skinny.` (Ela não é magra, ela é magrela.)
- `If you take good care of your nutrition, it is easy to be slim.` (Se você cuidar da sua nutrição, é fácil estar em forma.)
- `Well, I know you're not fat, but watch out, you're getting chubby.` (Bem, eu sei que você não está gordo, mas cuidado, você está ficando fofinho.)

---

### 👀 **Cor dos Olhos (Eye Color)**

| Cor (Inglês) | Pronúncia | Tradução | Exemplo |
| :--- | :--- | :--- | :--- |
| **Black eyes** | /blæk aɪz/ | Olhos negros | `Black eyes are very rare.` |
| **Blue eyes** | /bluː aɪz/ | Olhos azuis | `Those blue eyes are dazzling.` |
| **Brown eyes** | /braʊn aɪz/ | Olhos castanhos | `There is a big variety of brown eyes.` |
| **Hazel eyes** | /ˈheɪ.zəl aɪz/ | Olhos cor de mel | `Hazel eyes are similar to honey.` |
| **Green eyes** | /ɡriːn aɪz/ | Olhos verdes | `Green eyes are a great match with red hair.` |

#### **Nuances de Cor:**
- **Dark** + cor: Tom escuro. (Ex: `Dark brown eyes` - Olhos castanhos escuros)
- **Light** + cor: Tom claro. (Ex: `Light blue eyes` - Olhos azuis claros)

---

### 🔁 **Estruturas para Descrever Pessoas**

#### **Verbos Chave:**
- **To Be (ser/estar):** Usado para características **permanentes** ou de estado (altura, tipo de corpo).
    - `Mary is tall and thin.` (A Mary é alta e magra.)
    - `Peter is medium height and fit.` (O Peter é de altura média e está em forma.)
- **To Have (ter):** Usado para características que a pessoa **possui** (cor dos olhos, cabelo).
    - `She has blue eyes.` (Ela tem olhos azuis.)
    - `He has brown eyes.` (Ele tem olhos castanhos.)

#### **Frase Completa de Exemplo:**
`Paul is tall and slim. He has blue eyes.`
(O Paul é alto e esbelto. Ele tem olhos azuis.)

---

### 💡 **Vocabulário de Apoio e Expressões**

| Palavra/Expressão | Tradução |
| :--- | :--- |
| **To take care** | Cuidar |
| **Nutrition** | Nutrição |
| **Easy** / **Hard** | Fácil / Difícil |
| **To watch out** | Ficar esperto, tomar cuidado |
| **To get** (+ adjetivo) | Ficar (ex: `getting chubby` - ficando fofinho) |
| **To work out** / **To lift weights** | Malhar / Levantar pesos |
| **Weightlifter** | Levantador de pesos ("marombeiro") |
| **Rare** | Raro |
| **Variety** | Variedade |
| **Match** | Combinação |

---

### 📝 **Notas de Pronúncia**

- **Tall:** Soa como "tól", evitando "táu".
- **Height:** Pronúncia: /haɪt/ (soa como "ráit"). A escrita é enganosa.
- **Love:** Pronúncia correta: /lʌv/ (soa como "lâv").
- **Hazel:** Pronúncia: /ˈheɪ.zəl/ (soa como "rêi-zol").