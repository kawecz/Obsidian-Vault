---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - mais_conversacao
---

---
<iframe title="Inglês | Kultivi - How Does He Look Like II | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/DpEoMV7ZDN0?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Descrições Físicas - Cabelo e Características Especiais
> Esta segunda parte sobre descrições físicas foca no vocabulário para descrever tipos, cores e estilos de cabelo, além de características faciais como barba, óculos e sardas. O objetivo é capacitar o aluno a fazer descrições completas e detalhadas de pessoas.

[[../aula2.pdf|aula2]]

---

### 💇 **Cabelo (Hair) - Tipo, Cor e Estilo**

#### **Tipo de Cabelo (Hair Type):**
| Inglês | Pronúncia | Tradução |
| :--- | :--- | :--- |
| **Straight / Smooth Hair** | /streɪt/ /smuːð heər/ | Cabelo Liso |
| **Wavy Hair** | /ˈweɪ.vi heər/ | Cabelo Ondulado |
| **Curly Hair** | /ˈkɜː.li heər/ | Cabelo Encaracolado/Crespo |

#### **Cor do Cabelo (Hair Color):**
| Inglês | Pronúncia | Tradução | Notas |
| :--- | :--- | :--- | :--- |
| **Black Hair** | /blæk heər/ | Cabelo Preto |  |
| **Brown Hair** | /braʊn heər/ | Cabelo Castanho | Pode usar `Dark Brown` ou `Light Brown`. |
| **Red / Ginger Hair** | /red/ /ˈdʒɪn.dʒər heər/ | Cabelo Ruivo | `Ginger` é comum. |
| **Blond Hair** | /blɒnd heər/ | Cabelo Loiro |  |
| **Gray Hair** | /ɡreɪ heər/ | Cabelo Grisalho | Forma mais comum/educada para cabelos brancos. |
| **White Hair** | /waɪt heər/ | Cabelo Branco | Correto, mas menos comum. |

#### **Comprimento e Estilo (Length and Style):**
| Inglês | Pronúncia | Tradução |
| :--- | :--- | :--- |
| **Long Hair** | /lɒŋ heər/ | Cabelo Longo |
| **Short Hair** | /ʃɔːrt heər/ | Cabelo Curto |
| **Bun** | /bʌn/ | Coque |
| **Braids** | /breɪdz/ | Tranças |
| **Ponytail** | /ˈpəʊ.ni.teɪl/ | Rabo de Cavalo |
| **Bald** | /bɔːld/ | Careca | Usa o verbo **to be**: `He is bald`. |
| **Wig** | /wɪɡ/ | Peruca | Usa o verbo **to wear**: `He wears a wig`. |

---

### 🧔 **Características Faciais (Facial Features)**

| Característica (Inglês) | Pronúncia | Tradução | Verbo Usado |
| :--- | :--- | :--- | :--- |
| **Beard** | /bɪərd/ | Barba (Completa) | **To have** / **To wear** |
| **Goatee** | /ɡəʊˈtiː/ | Cavanhaque | **To have** / **To wear** |
| **Sideburns** | /ˈsaɪd.bɜːnz/ | Costeletas | **To have** |
| **Mustache** | /ˈmʌs.tæʃ/ | Bigode | **To have** / **To wear** |
| **Glasses** | /ˈɡlɑː.sɪz/ | Óculos | **To wear** |
| **Freckles** | /ˈfrek.əlz/ | Sardas | **To have** |

**Atenção à Pronúncia:**
- **Beard** (/bɪərd/) = Barba. ❌ Não confundir com **Bird** (/bɜːrd/) = Pássaro.
- **Bear** (/beər/) = Urso.

---

### 🧩 **Estruturas para Descrições Completas**

#### **Verbos Chave:**
- **To Be (ser/estar):** Para características de estado/constituição (altura, peso, ser careca).
    - `He is tall and chubby.` (Ele é alto e fofinho.)
    - `She is bald.` (Ela é careca.)
- **To Have (ter):** Para características que a pessoa possui (cor de olhos, cabelo, sardas, barba).
    - `He has green eyes and red hair.` (Ele tem olhos verdes e cabelo ruivo.)
    - `She has freckles.` (Ela tem sardas.)
- **To Wear (usar/vestir):** Para itens que a pessoa utiliza (óculos, peruca, às vezes barba/bigode).
    - `He wears glasses and a mustache.` (Ele usa óculos e um bigode.)

#### **Ordem na Descrição do Cabelo:**
A ordem natural para descrever o cabelo é: **Comprimento + Tipo + Cor**.
- `Long wavy black hair` (Cabelo longo, ondulado e preto)
- `Short curly blond hair` (Cabelo curto, encaracolado e loiro)

---

### 🎯 **Exemplos de Descrições Completas**

**Descrição 1 (John):**
`John is tall and slim. He has brown eyes and long wavy dark brown hair.`
(John é alto e em forma. Ele tem olhos castanhos e cabelo longo, ondulado e castanho escuro.)

**Descrição 2 (Mulher):**
`She is short and thin. She has hazel eyes and long blond straight hair.`
(Ela é baixa e magra. Ela tem olhos cor de mel e cabelo longo, loiro e liso.)

**Descrição 3 (Paul - Completa):**
`Paul is tall and chubby. He has green eyes and short curly red hair. He wears a mustache and glasses. He has freckles.`
(Paul é alto e fofinho. Ele tem olhos verdes e cabelo curto, encaracolado e ruivo. Ele usa um bigode e óculos. Ele tem sardas.)

---

### 💡 **Notas Finais**

- **Pelo vs. Cabelo:** Em inglês, tanto o cabelo da cabeça quanto os pelos do corpo são `hair`. A palavra específica para pelo de animal é `fur`.
- **"How does he look like?" vs. "What does he look like?":** Ambas as estruturas são usadas e compreendidas para perguntar sobre a aparência de alguém.