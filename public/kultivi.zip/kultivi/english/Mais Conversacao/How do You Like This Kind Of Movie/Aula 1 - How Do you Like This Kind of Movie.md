---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - mais_conversacao
---

---
<iframe title="Inglês | Kultivi - How Do You Like This Kind of Movie | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/qAoVQfWSR-4?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Conversação sobre Filmes e Preferências
> Esta aula foca em vocabulário e estruturas para conversar sobre filmes, gêneros cinematográficos, atores e expressar preferências e opiniões de forma variada.

[[aula1.pdf]]

---

### 🎬 **Gêneros Cinematográficos (Movie Genres)**

| Gênero (Inglês) | Pronúncia | Tradução | Exemplo Citado |
| :--- | :--- | :--- | :--- |
| **Action Movies** | /ˈæk.ʃən ˈmuː.viz/ | Filmes de Ação | Indiana Jones |
| **Cartoons / Animations** | /kɑːrˈtuːnz/ /ˌæn.ɪˈmeɪ.ʃənz/ | Desenhos Animados | Rio |
| **Drama Movies** | /ˈdrɑː.mə ˈmuː.viz/ | Filmes de Drama | (Love Stories) |
| **Horror Movies** | /ˈhɔːr.ər ˈmuː.viz/ | Filmes de Terror | - |
| **Love Stories** | /lʌv ˈstɔːr.iz/ | Histórias de Amor | Titanic |
| **Science Fiction (Sci-Fi)** | /ˈsaɪəns ˈfɪk.ʃən/ | Ficção Científica | Arnold Schwarzenegger |
| **Super Heroes Movies** | /ˈsuː.pər ˈhɪə.roʊz ˈmuː.viz/ | Filmes de Super-Heróis | - |
| **Suspense / Thriller Movies** | /səˈspens/ /ˈθrɪl.ər ˈmuː.viz/ | Filmes de Suspense | - |
| **War Movies** | /wɔːr ˈmuː.viz/ | Filmes de Guerra | Saving Private Ryan |
| **Western Movies** | /ˈwes.tərn ˈmuː.viz/ | Faroestes / Bang-Bang | - |
| **Comedy Movies** | /ˈkɒm.ə.di ˈmuː.viz/ | Filmes de Comédia | - |

---

### 💬 **Estruturas para Perguntar e Expressar Preferências**

#### **Perguntas Chave:**
- **`What's your favorite kind of movie?`** (Qual é o seu tipo de filme favorito?)
- **`Who is your favorite actor/actress?`** (Quem é o seu ator/atriz favorito(a)?)
- **`How do you like [tipo de filme]?`** (O que você acha de [tipo de filme]?)

#### **Escala de Gosto (Do Mais Forte ao Mais Fraco):**
| Expressão | Tradução | Intensidade |
| :--- | :--- | :--- |
| **`I adore`** | Eu adoro | ⭐⭐⭐⭐⭐ |
| **`I love`** | Eu amo | ⭐⭐⭐⭐ |
| **`I like`** | Eu gosto | ⭐⭐⭐ |
| **`I think... are ok`** | Eu acho... ok / mais ou menos | ⭐⭐ |
| **`I don't like`** | Eu não gosto | ⭐ |
| **`I hate`** | Eu odeio | 👎 |
| **`I can't stand`** | Eu não suporto | 💥 |

**Exemplos de Uso:**
- `I adore horror movies.` (Eu adoro filmes de terror.)
- `I love Angelina Jolie.` (Eu amo a Angelina Jolie.)
- `I don't like drama movies.` (Eu não gosto de filmes de drama.)
- `I can't stand war movies.` (Eu não suporto filmes de guerra.)

---

### 🗣️ **Vocabulário de Cinema e Crítica**

| Palavra/Expressão | Tradução |
| :--- | :--- |
| **To watch a movie** | Assistir a um filme |
| **To go to the movies** | Ir ao cinema |
| **Actor / Actress** | Ator / Atriz |
| **Director** | Diretor |
| **Writer / Screenwriter** | Roteirista / Escritor |
| **To star in a movie** | Estrelar um filme |
| **Famous** | Famoso |
| **Nowadays** | Hoje em dia |
| **To cry** | Chorar |
| **To smile** | Sorrir |
| **To laugh** | Rir |

---

### ✍️ **Dica de Pronúncia e Pronúncia**

- **Love:** Pronúncia correta é /lʌv/ (parecido com "lâvi"). Evite pronunciar como "lóvi".
- **Horror:** Pronúncia correta é /ˈhɔːr.ər/ (parecido com "rôrêr"). Evite pronunciar como "órror".
- **Actor / Actress:** Preste atenção ao usar `Who` para pessoas e `What` para coisas.

---

### 🎯 **Atividade Prática Final**

1.  **Grave um áudio ou vídeo** respondendo às perguntas:
    - `What's your favorite kind of movie?`
    - `Who is your favorite actor/actress?`
    - `How do you like [um gênero que você NÃO gosta]?`
2.  Use o máximo do vocabulário e das escalas de gosto aprendidas.
3.  Pratique a pronúncia das palavras-chave.