---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Inglês | Kultivi Extra Class - To Be: Simple Present | CURSO GRATUITO COMPLETO - Aula #13" src="https://www.youtube.com/embed/_92kfQ_K194?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula Extra 13: O Verbo "To Be" no Presente Simples
> Esta aula é um complemento gramatical focado no verbo mais fundamental do inglês: "To Be" (Ser ou Estar). Diferente das aulas de conversação, aqui o objetivo é entender a estrutura, as formas (afirmativa, negativa, interrogativa) e as contrações deste verbo irregular, que é a base para a construção de frases básicas.

[[aula9.pdf]]

---

### 📘 Tópicos da Aula
1.  **Introdução ao Verbo "To Be"**
2.  **Forma Afirmativa:** Pronomes e conjugação
3.  **Contrações na Afirmativa**
4.  **Forma Negativa**
5.  **Contrações na Negativa**
6.  **Forma Interrogativa**
7.  **Respostas Curtas (Short Answers)**

---

### 📖 Conteúdo Detalhado

#### 1. O Verbo "To Be" (Ser/Estar)
- **Significado:** Pode significar **"ser"** (estado permanente) ou **"estar"** (estado temporário).
- **Exemplos:**
    - `I am a teacher.` (Eu **sou** um professor.) -> "Ser"
    - `I am tired.` (Eu **estou** cansado.) -> "Estar"
- **Dica:** O contexto da frase define o significado. Aprenda com as frases das aulas de conversação.

#### 2. Pronomes Pessoais (Personal Pronouns)
| Inglês | Português | Uso |
| :--- | :--- | :--- |
| **I** | Eu | |
| **You** | Você / Tu | |
| **He** | Ele | Para homens |
| **She** | Ela | Para mulheres |
| **It** | Ele/Ela | Para animais, objetos e coisas |
| **We** | Nós | |
| **You** | Vocês | |
| **They** | Eles/Elas | |

**Observação sobre "It":** Usado para coisas, animais e objetos, mesmo que em português tenham gênero (ex: a mesa = `it`, o livro = `it`).

#### 3. Forma Afirmativa (Affirmative Form)
| Pronome | Verbo "To Be" | Forma Contraída | Exemplo (Tradução) |
| :--- | :--- | :--- | :--- |
| **I** | **am** | **I'm** | `I'm a student.` (Eu sou um estudante.) |
| **You** | **are** | **You're** | `You're Brazilian.` (Você é brasileiro.) |
| **He** | **is** | **He's** | `He's a doctor.` (Ele é um médico.) |
| **She** | **is** | **She's** | `She's from Japan.` (Ela é do Japão.) |
| **It** | **is** | **It's** | `It's a book.` (É um livro.) |
| **We** | **are** | **We're** | `We're friends.` (Nós somos amigos.) |
| **You** | **are** | **You're** | `You're students.` (Vocês são estudantes.) |
| **They** | **are** | **They're** | `They're teachers.` (Eles são professores.) |

#### 4. Forma Negativa (Negative Form)
Basta adicionar **`not`** após o verbo "to be".

| Pronome | Forma Negativa Completa | Contração Comum (Verbo + not) | Exemplo |
| :--- | :--- | :--- | :--- |
| **I** | `I am not` | --- | `I'm not tired.` |
| **You** | `You are not` | `You aren't` | `You aren't late.` |
| **He** | `He is not` | `He isn't` | `He isn't here.` |
| **She** | `She is not` | `She isn't` | `She isn't a teacher.` |
| **It** | `It is not` | `It isn't` | `It isn't my car.` |
| **We** | `We are not` | `We aren't` | `We aren't from Spain.` |
| **You** | `You are not` | `You aren't` | `You aren't ready.` |
| **They** | `They are not` | `They aren't` | `They aren't happy.` |

**Observação:** Para "I am not", a única contração possível é **`I'm not`**. `I amn't` NÃO existe.

#### 5. Forma Interrogativa (Interrogative Form)
Para fazer perguntas cuja resposta é "sim" ou "não" (Yes/No Questions), inverte-se a posição do verbo "to be" e do pronome.

- **Afirmativa:** `You are a teacher.`
- **Interrogativa:** `Are you a teacher?`

| Pronome | Forma Interrogativa | Exemplo |
| :--- | :--- | :--- |
| **Am I**...? | `Am I late?` (Eu estou atrasado?) |
| **Are you**...? | `Are you Brazilian?` (Você é brasileiro?) |
| **Is he**...? | `Is he a doctor?` (Ele é um médico?) |
| **Is she**...? | `Is she from Japan?` (Ela é do Japão?) |
| **Is it**...? | `Is it your book?` (É o seu livro?) |
| **Are we**...? | `Are we friends?` (Nós somos amigos?) |
| **Are you**...? | `Are you students?` (Vocês são estudantes?) |
| **Are they**...? | `Are they teachers?` (Eles são professores?) |

#### 6. Respostas Curtas (Short Answers)
São as respostas mais comuns para perguntas de "Sim" ou "Não".

| Pergunta | Resposta Afirmativa | Resposta Negativa |
| :--- | :--- | :--- |
| `Are you a teacher?` | **Yes, I am.** | **No, I'm not.** |
| `Is he Brazilian?` | **Yes, he is.** | **No, he isn't.** |
| `Is she tired?` | **Yes, she is.** | **No, she isn't.** |
| `Are we late?` | **Yes, we are.** | **No, we aren't.** |
| `Are they here?` | **Yes, they are.** | **No, they aren't.** |

**Regra das Respostas Curtas:** Nunca use a forma contraída na resposta afirmativa curta. Diga `Yes, I am`. (✅) e nunca `Yes, I'm`. (❌).

---

### 📚 Categorização de Palavras-Chave

**Verbos (Verbs):**
`to be` (ser/estar), `am`, `is`, `are`

**Pronomes (Pronouns):**
`I`, `you`, `he`, `she`, `it`, `we`, `they`

**Partículas de Negação:**
`not`, `n't` (contração)

**Advérbios de Afirmação/Negação:**
`yes`, `no`

---

### 💡 Dicas do Professor
- **Aprenda na Prática:** Esta aula gramatical é um suporte. O jeito mais fácil de aprender o "to be" é usando-o nas frases das aulas de conversação.
- **"It" é Neutro:** Treine seu cérebro para usar `it` para objetos e animais, abandonando a ideia de gênero gramatical do português.
- **Domine as Contrações:** `I'm`, `you're`, `he's`, `she's`, `it's`, `we're`, `they're`, `isn't` e `aren't` são extremamente comuns na fala do dia a dia.
- **Cuidado com "I am not":** A única forma correta e natural é `I'm not`. A forma `I amn't` não existe no inglês padrão.
- **Respostas Curtas:** Lembre-se da regra de ouro: na resposta afirmativa curta, não use contração (`Yes, I am`). Na negativa, use (`No, I'm not`).