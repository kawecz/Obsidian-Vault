---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Inglês | Kultivi - Numbers | CURSO GRATUITO COMPLETO - Aula #10" src="https://www.youtube.com/embed/hCzzjtyhy78?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 7: Números em Inglês (Numbers)
> Esta aula é dedicada aos números cardinais em inglês, do zero (zero) ao cem (one hundred). O professor Rui Ventura foca na pronúncia correta, destacando os sons que são mais desafiadores para falantes de português e ensinando a formação dos números compostos.

[[aula7.pdf]]

---

### 📘 Tópicos da Aula
1.  **Números de 0 a 12:** A base fundamental
2.  **Números de 13 a 19:** O sufixo "-teen"
3.  **Dezenas (20, 30, 40...):** O sufixo "-ty"
4.  **Números Compostos (21, 32, 45...):** Combinações
5.  **Pronúncia do "TH":** Essencial para "three", "thirty", etc.

---

### 📖 Conteúdo Detalhado

#### 1. Números de 0 a 12 (Base Fundamental)
| Número | Pronúncia (Fonética) | Número | Pronúncia (Fonética) |
| :--- | :--- | :--- | :--- |
| **0** | "zî-rou" | **7** | "sé-ven" |
| **1** | "uân" | **8** | "êit" |
| **2** | "tú" | **9** | "nâin" |
| **3** | "thrî" | **10** | "tên" |
| **4** | "fôr" | **11** | "i-lé-ven" |
| **5** | "fâiv" | **12** | "tu-élv" |
| **6** | "sîks" | | |

**Observações:**
- **`3` - Three:** O "th" requer que a ponta da língua fique entre os dentes. Soa como um "s" com a língua para fora.
- **`5` - Five:** Termina com som de "v", e não de "f".
- **`8` - Eight:** Soa como "êit". Cuidado para não pronunciar "êiti".

#### 2. Números de 13 a 19 (O Sufixo "-teen")
A partir do 13, os números são formados pela unidade + o sufixo **`-teen`**. A sílaba tônica (a mais forte) cima na terminação **`-teen`**.

| Número | Pronúncia (Fonética) | Número | Pronúncia (Fonética) |
| :--- | :--- | :--- | :--- |
| **13** | "thêr-tîn" | **17** | "sê-ven-tîn" |
| **14** | "fôr-tîn" | **18** | "êi-tîn" |
| **15** | "fif-tîn" | **19** | "nâin-tîn" |
| **16** | "sîx-tîn" | | |

#### 3. Dezenas (20, 30, 40...90) (O Sufixo "-ty")
As dezenas são formadas pela unidade + o sufixo **`-ty`**. A sílaba tônica cima na **primeira sílaba**.

| Número | Pronúncia (Fonética) | Número | Pronúncia (Fonética) |
| :--- | :--- | :--- | :--- |
| **20** | "tuên-ti" | **60** | "sîx-ti" |
| **30** | "thêr-ti" | **70** | "sê-ven-ti" |
| **40** | "fôr-ti" | **80** | "êi-ti" |
| **50** | "fif-ti" | **90** | "nâin-ti" |

**Diferença Crucial: "-teen" vs. "-ty"**
- **`-teen`:** Sílaba forte no final. Ex: thir**teen**.
- **`-ty`:** Sílaba forte no começo. Ex: **thir**ty.

#### 4. Formando Números Compostos (21, 32, 45...)
Para formar números entre 21 e 99, usa-se a dezena + a unidade, ligadas por um hífen.
**Estrutura:** `[dezena] - [unidade]`

| Número | Pronúncia (Fonética) |
| :--- | :--- |
| **21** | "tuên-ti uân" |
| **32** | "thêr-ti tú" |
| **45** | "fôr-ti fâiv" |
| **58** | "fif-ti êit" |
| **67** | "sîx-ti sé-ven" |
| **73** | "sê-ven-ti thrî" |
| **84** | "êi-ti fôr" |
| **99** | "nâin-ti nâin" |

#### 5. Pronúncia do "TH"
- **Como fazer:** Coloque a ponta da língua levemente entre os dentes da frente e sopre o ar.
- **Palavras Prática:** `three`, `thirty`, `thirteen`.
- **Dica:** Pratique com a palavra "paçoca". Diga "aço" e preste atenção na posição da língua. Esse é o som do "TH".

---

### 📚 Categorização de Palavras-Chave

**Números Cardinais (Cardinal Numbers):**
`zero`, `one`, `two`, `three`, `four`, `five`, `six`, `seven`, `eight`, `nine`, `ten`, `eleven`, `twelve`, `thirteen`, `fourteen`, `fifteen`, `sixteen`, `seventeen`, `eighteen`, `nineteen`, `twenty`, `thirty`, `forty`, `fifty`, `sixty`, `seventy`, `eighty`, `ninety`, `one hundred`

**Outros:**
`pronunciation`, `syllable`

---

### 💡 Dicas do Professor
- **Pratique a Diferença "-teen" / "-ty":** Este é um dos erros mais comuns. Grave: `-teen` = força no final; `-ty` = força no começo.
- **Domine o "TH":** Não ignore este som. Pratique com a língua entre os dentes até se acostumar. É crucial para soar natural.
- **Crie Suas Próprias Listas:** Escreva números aleatórios (ex: 47, 82, 16, 93) e pratique falá-los em voz alta.
- **Ouça e Repita:** Volte o vídeo e repita os trechos em que o professor pronuncia os números, imitando a entonação exata.
- **Contexto é Tudo:** Use os números no seu dia a dia. Conte coisas em inglês: degraus, carros, árvores, etc.