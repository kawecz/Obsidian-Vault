---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Ocupações e Profissões em Inglês II | Curso Completo - aula #06" src="https://www.youtube.com/embed/BECI2LvMZbk?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

----
> [!abstract] Aula 4.2: Ocupações e Profissões em Inglês (Occupations and Professions) - Parte 2
> Esta aula é a continuação direta do estudo sobre profissões. Aqui, o foco está em aprender a perguntar e responder sobre a ocupação de alguém, utilizando a estrutura "What do you do?" e expandindo o vocabulário com verbos de ação relacionados ao trabalho.

[[aula4.2.pdf]]

---

### 📘 Tópicos da Aula
1.  **Perguntando sobre a Profissão:** `What's your occupation?` e `What do you do?`
2.  **Estrutura de Resposta:** `I am a/an...` + Profissão
3.  **Descrevendo as Funções:** Verbos de ação específicos para cada profissão
4.  **Novo Vocabulário:** Substantivos e Verbos

---

### 📖 Conteúdo Detalhado

#### 1. Como Perguntar sobre a Profissão
- **`What's your occupation?`** (Qual é a sua ocupação?)
- **`What's your profession?`** (Qual é a sua profissão?)
- **`What do you do?`** (O que você faz?) -> **A forma mais comum e usual.**

#### 2. Como Responder sobre a Profissão
- **Estrutura Básica:** `I am a/an + profissão.`
- **Uso dos Artigos:**
    - `a` -> Usado antes de palavras com som de consoante. (Ex: `a cook`, `a doctor`)
    - `an` -> Usado antes de palavras com som de vogal. (Ex: `an actor`, `an electrician`)

#### 3. Descrevendo as Funções da Profissão
A pergunta `What do you do?` também pode ser respondida descrevendo as atividades realizadas.

| Profissão | Pronúncia | O que eles fazem (Inglês) | O que eles fazem (Português) |
| :--- | :--- | :--- | :--- |
| **Actor** | "ác-tor" | `I act in movies and plays.` | Eu atuo em filmes e peças teatrais. |
| **Cook** | "kuk" | `I prepare and cook dishes.` | Eu preparo e cozinho pratos. |
| **Doctor** | "dók-tor" | `I treat people.` | Eu trato pessoas. |
| **Police Officer** | "po-lís ó-fi-ser" | `I help and protect people.` | Eu ajudo e protejo pessoas. |
| **Secretary** | "sé-cre-ta-ri" | `I answer the phone and talk to people.` | Eu atendo o telefone e falo com pessoas. |
| **Student** | "stú-dent" | `I go to school and study.` | Eu vou para a escola e estudo. |
| **Waiter** | "uêi-ter" | `I serve people in restaurants.` | Eu sirvo pessoas em restaurantes. |
| **Realtor** | "rí-al-tor" | `I help people buy, sell, or rent houses and apartments.` | Eu ajudo pessoas a comprar, vender ou alugar casas e apartamentos. |

---

### 📚 Vocabulário Expandido

#### Substantivos (Nouns) Novos
| Inglês | Pronúncia | Português |
| :--- | :--- | :--- |
| **Movies** | "mú-vis" | Filmes / Cinema |
| **Plays** | "plêis" | Peças Teatrais |
| **Dishes** | "dí-shis" | Pratos (culinários) / Louça |
| **People** | "pí-pol" | Pessoas (plural de `person`) |
| **Phone** | "foun" | Telefone |
| **School** | "skul" | Escola |
| **Restaurants** | "rés-to-rants" | Restaurantes |
| **Houses** | "háu-zis" | Casas |
| **Apartments** | "a-párt-ments" | Apartamentos |

#### Verbos (Verbs) Novos
| Verbo (Inglês) | Pronúncia | Português | Exemplo |
| :--- | :--- | :--- | :--- |
| **To act** | "tu ákt" | Atuar / Agir | `I act.` |
| **To prepare** | "tu pri-pér" | Preparar | `I prepare dishes.` |
| **To cook** | "tu kuk" | Cozinhar | `I cook food.` |
| **To treat** | "tu trit" | Tratar (médico) | `I treat people.` |
| **To help** | "tu hélp" | Ajudar | `I help you.` |
| **To protect** | "tu pro-tékt" | Proteger | `I protect people.` |
| **To answer** | "tu án-ser" | Responder / Atender | `I answer the phone.` |
| **To talk** | "tu tok" | Falar / Conversar | `I talk to people.` |
| **To go** | "tu gou" | Ir | `I go to school.` |
| **To study** | "tu stâ-di" | Estudar | `I study English.` |
| **To serve** | "tu sêrv" | Servir | `I serve customers.` |
| **To buy** | "tu bai" | Comprar | `I buy a house.` |
| **To sell** | "tu sel" | Vender | `I sell cars.` |
| **To rent** | "tu rent" | Alugar | `I rent an apartment.` |

---

### 💡 Dicas do Professor
- **Repetição é a Chave:** Participe ativamente repetindo as frases em voz alta. Essa é a maneira mais eficaz de melhorar a pronúncia e a fluência.
- **Pratique a Pronúncia Difícil:** Preste atenção especial em sons como o "th" em `answer` e o "L" em `help`. Volte o vídeo e repita quantas vezes forem necessárias.
- **Use a Estrutura Completa:** Ao responder "What do you do?", pratique não só dizer a profissão (`I am a teacher`), mas também descrever suas atividades (`I teach students`).
- **Estude o Vocabulário:** Faça uma lista dos novos verbos e substantivos em seu caderno. Tente criar suas próprias frases com eles.