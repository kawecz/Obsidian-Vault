---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Ocupações e Profissões em Inglês I | Curso Completo - aula #05" src="https://www.youtube.com/embed/qLmKboPhKrQ?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 4: Ocupações e Profissões em Inglês (Occupations and Professions) - Parte 1
> Esta aula introduz o vocabulário relacionado a profissões e ocupações em inglês. O professor Rui Ventura explica a sutil diferença entre "occupation" e "profession" e ensina a estrutura fundamental para dizer o que alguém faz, usando os pronomes "He is" (Ele é) e "She is" (Ela é), juntamente com os artigos "a" e "an".

[[aula4.pdf]]

---

### 📘 Tópicos da Aula
1.  **Revisão: Apresentações e Saudações**
2.  **Diferença entre `Occupation` e `Profession`**
3.  **Estrutura para Falar sobre Profissões:** `He/She is a/an...`
4.  **Vocabulário de Profissões (25+ palavras)**

---

### 📖 Conteúdo Detalhado

#### 1. Revisão Rápida
- **"Prazer em Conhecê-lo":** `Nice to meet you`, `Glad to meet you`, `Pleased to meet you`, `It's a pleasure to meet you`.
- **Apresentando Pessoas:** `John, this is Sarah. Sarah, this is John.`
- **Saudações:** `Hi`, `Hello`, `Good morning`, `Good afternoon`, `Good evening`.
- **Perguntando "Como você está?":** `How are you?`, `How are you doing?`, `How are things?`, `How's life treating you?`
- **Estrutura de Resposta:** `I'm fine, thanks. And you?`

#### 2. Occupation vs. Profession
- **Occupation:** Ocupação. Algo que você faz para ganhar dinheiro, ocupando seu tempo. (Ex: Músico como um "bico").
- **Profession:** Profissão. Uma carreira na qual você investiu em estudo e treinamento para se tornar um profissional. (Ex: Professor de formação).
- **Uso Prático:** `Occupation` é o termo mais comum e usado no dia a dia.

#### 3. Estrutura Gramatical para Profissões
- **Pronomes:**
    - `He` (Ele) -> Dica: Lembre-se do super-herói "He-Man".
    - `She` (Ela) -> Dica: Lembre-se da super-heroína "She-Ra".
- **Verbo "To Be":** `is` (é)
- **Artigos:**
    - `a` -> Usado antes de palavras que começam com som de consoante. (Ex: `a baker`)
    - `an` -> Usado antes de palavras que começam com som de vogal (a, e, i, o, u). (Ex: `an actor`)

**Estrutura Completa:**
`He / She + is + a/an + profissão.`

**Exemplos:**
- `He is an actor.` (Ele é um ator.)
- `She is an actress.` (Ela é uma atriz.)
- `He is a baker.` (Ele é um padeiro.)

#### 4. Vocabulário de Profissões
| Profissão (Inglês) | Pronúncia (Dica) | Profissão (Português) | Exemplo de Frase |
| :--- | :--- | :--- | :--- |
| **Actor** | "ác-tor" | Ator | `He is an actor.` |
| **Actress** | "ác-tress" | Atriz | `She is an actress.` |
| **Architect** | "ár-ki-tekt" | Arquiteto(a) | `He is an architect.` |
| **Astronaut** | "ás-tro-not" | Astronauta | `He is an astronaut.` |
| **Baker** | "bêi-ker" | Padeiro(a) | `He is a baker.` |
| **Brick Layer** | "brik lêi-er" | Pedreiro | `He is a brick layer.` |
| **Butcher** | "bú-tcher" | Açougueiro(a) | `He is a butcher.` |
| **Cashier** | "ká-shir" | Caixa | `She is a cashier.` |
| **Cook** | "kuk" | Cozinheiro(a) | `He is a cook.` |
| **Dentist** | "dén-tist" | Dentista | `He is a dentist.` |
| **Doctor** | "dók-tor" | Médico(a) | `He is a doctor.` |
| **Driver** | "drái-ver" | Motorista | `They are drivers.` (Eles são motoristas) |
| **Electrician** | "e-lek-trí-shian" | Eletricista | `He is an electrician.` |
| **Engineer** | "en-gi-nír" | Engenheiro(a) | `He is an engineer.` |
| **Fireman** | "fáir-man" | Bombeiro | `He is a fireman.` |
| **Gardener** | "gár-de-ner" | Jardineiro(a) | `He is a gardener.` |
| **Lawyer** | "lói-er" | Advogado(a) | `He is a lawyer.` |
| **Mechanic** | "me-ká-nik" | Mecânico(a) | `He is a mechanic.` |
| **Nurse** | "nêrs" | Enfermeiro(a) | `She is a nurse.` |
| **Painter** | "pêin-ter" | Pintor(a) | `He is a painter.` |
| **Plumber** | "plô-mer" | Encanador | `He is a plumber.` |
| **Police Officer** | "po-lís ó-fi-ser" | Policial | `He is a police officer.` |
| **Realtor** | "rí-al-tor" | Corretor de Imóveis | `He is a realtor.` |
| **Secretary** | "sé-cre-ta-ri" | Secretário(a) | `She is a secretary.` |
| **Singer** | "sín-ger" | Cantor(a) | `He is a singer.` |
| **Soccer Player** | "só-ker plêi-er" | Jogador de Futebol | `He is a soccer player.` |
| **Student** | "stú-dent" | Estudante | `She is a student.` |
| **Teacher** | "tí-tcher" | Professor(a) | `She is a teacher.` |
| **Waiter** | "uêi-ter" | Garçom | `He is a waiter.` |
| **Waitress** | "uêi-tress" | Garçonete | `She is a waitress.` |

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`occupation`, `profession`, `actor`, `actress`, `architect`, `astronaut`, `baker`, `brick layer`, `butcher`, `cashier`, `cook`, `dentist`, `doctor`, `driver`, `electrician`, `engineer`, `fireman`, `gardener`, `lawyer`, `mechanic`, `nurse`, `painter`, `plumber`, `police officer`, `realtor`, `secretary`, `singer`, `soccer player`, `student`, `teacher`, `waiter`, `waitress`

**Pronomes (Pronouns):**
`he`, `she`, `they`

**Verbos (Verbs):**
`is` (verbo to be)

**Artigos (Articles):**
`a`, `an`

**Preposições (Prepositions):**
`to` (em `introduce to`)

---

### 💡 Dicas do Professor
- **Pratique a Pronúncia:** Repita as frases em voz alta após o professor. A fluência na fala vem da prática constante.
- **Use os Artigos Corretamente:** Lembre-se da regra: `a` antes de som de consoante, `an` antes de som de vogal.
- **Aprenda com Dicas Mnemônicas:** Use "He-Man" e "She-Ra" para lembrar de `he` (ele) e `she` (ela).
- **Estude em Grupo:** Para praticar os diálogos, reúna-se com amigos que também estão fazendo o curso. Cada um representa um personagem e depois trocam os papéis.