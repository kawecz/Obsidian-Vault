---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Países e Nacionalidades em Inglês I | Curso Completo - aula #07" src="https://www.youtube.com/embed/B4zovIybu00?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 5: Países e Nacionalidades em Inglês (Countries and Nationalities) - Parte 1
> Esta aula introduz o vocabulário essencial para falar sobre países, cidades e nacionalidades em inglês. O foco está em aprender a perguntar "De onde você é?" (`Where are you from?`) e a responder de maneira clara, tanto com o país quanto com a cidade de origem.

[[aula5.pdf]]

---

### 📘 Tópicos da Aula
1.  **Revisão:** Saudações e Profissões
2.  **Perguntando a Origem:** `Where are you from?`
3.  **Nomes de Países:** Pronúncia e Uso
4.  **Perguntando a Cidade:** `What city are you from?`
5.  **Respondendo com a Cidade:** `I am from a city called...`

---

### 📖 Conteúdo Detalhado

#### 1. Revisão Rápida
- **Saudações:** `How are you?`, `How are you doing?`, `How are things?`, `How's life treating you?`
- **Profissões:** `He is a doctor.`, `She is an electrician.` (Lembrando a regra do `a` e `an`).
- **Perguntando a Profissão:** `What's your occupation?`

#### 2. Perguntando "De onde você é?"
- **Pergunta Principal:** `Where are you from?`
    - Tradução literal: "Onde você é de?"
- **Resposta Básica:** `I am from [país].` ou `I'm from [país].`

#### 3. Nomes de Países e Pronúncia
| País (Inglês) | Pronúncia (Dica) | Pronúncia (Fonética) | Exemplo de Resposta |
| :--- | :--- | :--- | :--- |
| **Argentina** | "Ar-guen-tí-na" | /ˌɑːr.dʒənˈtiː.nə/ | `I am from Argentina.` |
| **Brazil** | "Bra-zíl" | /brəˈzɪl/ | `I am from Brazil.` |
| **Canada** | "Cá-na-dá" | /ˈkæn.ə.də/ | `I am from Canada.` |
| **China** | "Chái-na" | /ˈtʃaɪ.nə/ | `I am from China.` |
| **England** | "Ín-gland" | /ˈɪŋ.ɡlənd/ | `I am from England.` |
| **France** | "Fráns" | /fræns/ | `I am from France.` |
| **Germany** | "Dgérr-ma-ni" | /ˈdʒɜː.mə.ni/ | `I am from Germany.` |
| **Italy** | "Í-ta-li" | /ˈɪt.əl.i/ | `I am from Italy.` |
| **Japan** | "Dja-pán" | /dʒəˈpæn/ | `I am from Japan.` |
| **Portugal** | "Pór-chu-gal" | /ˈpɔːr.tʃə.ɡəl/ | `I am from Portugal.` |
| **Spain** | "Espêin" | /speɪn/ | `I am from Spain.` |
| **The USA** | "The iu-ês-êi" | /ðə ˌjuː.esˈeɪ/ | `I am from the USA.` |

**Observação sobre "The USA":**
- `USA` é uma sigla para `United States of America` (Estados Unidos da América).
- Por ser uma sigla que representa um nome composto ("os" Estados Unidos), usa-se o artigo definido **`the`** antes. O mesmo vale para `the UK` (United Kingdom).

#### 4. Perguntando "De qual cidade você é?"
- **Pergunta Específica:** `What city are you from?`
    - Tradução: "De qual cidade você é?"

#### 5. Respondendo com a Cidade
- **Resposta Simples:** `I am from [cidade].` (Ex: `I am from Curitiba.`)
- **Resposta Mais Elaborada:** `I am from a city called [cidade].`
    - Tradução: "Eu sou de uma cidade chamada [cidade]."

#### 6. Vocabulário de Cidades
| Cidade (Inglês) | Pronúncia (Dica) | País |
| :--- | :--- | :--- |
| **Buenos Aires** | "Buê-nos Ái-ris" | Argentina |
| **Curitiba** | "Cu-ri-tí-ba" | Brazil |
| **Toronto** | "To-rón-tou" | Canada |
| **Beijing** | "Bei-Djíng" | China |
| **London** | "Lân-dan" | England |
| **Paris** | "Pá-ris" | France |
| **Berlin** | "Ber-lín" | Germany |
| **Rome** | "Roum" | Italy |
| **Tokyo** | "Tou-kiou" | Japan |
| **Lisbon** | "Líz-bon" | Portugal |
| **Malaga** | "Má-la-ga" | Spain |
| **New York** | "Niu Iórk" | USA |

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`country`, `city`, `Argentina`, `Brazil`, `Canada`, `China`, `England`, `France`, `Germany`, `Italy`, `Japan`, `Portugal`, `Spain`, `USA`, `Buenos Aires`, `Curitiba`, `Toronto`, `Beijing`, `London`, `Paris`, `Berlin`, `Rome`, `Tokyo`, `Lisbon`, `Malaga`, `New York`

**Pronomes (Pronouns):**
`I`, `you`

**Verbos (Verbs):**
`am`, `are` (verbo to be)

**Preposições (Prepositions):**
`from`

**Artigos (Articles):**
`a`, `the`

---

### 💡 Dicas do Professor
- **The USA / The UK:** Lembre-se sempre de usar `the` antes de siglas de países que representam nomes compostos, como Estados Unidos (`the USA`) e Reino Unido (`the UK`).
- **Pratique a Pronúncia:** Nomes de países e cidades em inglês podem ter uma pronúncia muito diferente do português. Use as dicas fonéticas e repita constantemente.
- **Interaja com o Vídeo:** Fale as respostas em voz alta durante as pausas. Essa é a única maneira de desenvolver a fluência na conversação.
- **Expanda seu Vocabulário:** Após esta aula, pesquise e anote em seu caderno como se diz a sua cidade e o seu estado em inglês.