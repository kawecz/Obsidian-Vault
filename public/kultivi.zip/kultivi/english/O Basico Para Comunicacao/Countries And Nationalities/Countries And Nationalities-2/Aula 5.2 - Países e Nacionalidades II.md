---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Países e Nacionalidades em Inglês II | Curso Completo - aula #08" src="https://www.youtube.com/embed/qSdNJ4FbGYw?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 5.2: Países e Nacionalidades em Inglês (Countries and Nationalities) - Parte 2
> Esta aula continua o tema de países e nacionalidades, focando em como perguntar e responder sobre a nacionalidade de alguém. Além disso, introduz os pronomes pessoais em inglês (I, you, he, she, it, we, they) e inicia o uso da terceira pessoa (he/she) em diálogos simples.

[[aula5.2.pdf]]

---

### 📘 Tópicos da Aula
1.  **Perguntando a Nacionalidade:** `What's your nationality?`
2.  **Nacionalidades por País:** Pronúncia e Uso
3.  **Pronomes Pessoais:** `I, you, he, she, it, we, they`
4.  **Introduzindo a 3ª Pessoa:** `What's his/her name?`, `Where is he/she from?`

---

### 📖 Conteúdo Detalhado

#### 1. Perguntando e Respondendo sobre Nacionalidade
- **Pergunta:** `What's your nationality?` (Qual é a sua nacionalidade?)
- **Resposta Correta:** `I am [nacionalidade].` (Eu sou [nacionalidade].)
- **Resposta Incorreta (Evitar):** `My nationality is...` (Não soa natural em inglês).

#### 2. Nacionalidades por País
| País | Nacionalidade (Masculino/Feminino) | Pronúncia (Dica) | Exemplo de Resposta |
| :--- | :--- | :--- | :--- |
| **Argentina** | Argentinian | "Ar-guen-tí-ni-an" | `I am Argentinian.` |
| **Brazil** | Brazilian | "Bra-zí-li-an" | `I am Brazilian.` |
| **Canada** | Canadian | "Ca-nêi-di-an" | `I am Canadian.` |
| **China** | Chinese | "Chái-niz" | `I am Chinese.` |
| **England** | English | "Ín-glish" | `I am English.` |
| **France** | French | "Frensh" | `I am French.` |
| **Germany** | German | "Dgérr-man" | `I am German.` |
| **Italy** | Italian | "I-tá-li-an" | `I am Italian.` |
| **Japan** | Japanese | "Dja-pa-niz" | `I am Japanese.` |
| **Portugal** | Portuguese | "Por-chu-giz" | `I am Portuguese.` |
| **Spain** | Spanish | "Spá-nish" | `I am Spanish.` |
| **USA** | American | "A-mé-ri-can" | `I am American.` |

**Observação sobre Pronúncia:**
- **Italy:** Pode ser pronunciado como "I-tal-i" ou, mais comumente, com um "linking sound": "I-ral-i", onde o "t" soa como "r".

#### 3. Pronomes Pessoais (Personal Pronouns)
| Inglês | Pronúncia | Português | Uso |
| :--- | :--- | :--- | :--- |
| **I** | "ai" | Eu | Primeira pessoa do singular |
| **You** | "iú" | Você / Tu | Segunda pessoa do singular |
| **He** | "rî" | Ele | Terceira pessoa do singular (masculino) |
| **She** | "chî" | Ela | Terceira pessoa do singular (feminino) |
| **It** | "it" | Ele/Ela (neutro) | Terceira pessoa do singular (coisas, animais, objetos) |
| **We** | "uî" | Nós | Primeira pessoa do plural |
| **You** | "iú" | Vocês | Segunda pessoa do plural |
| **They** | "dêi" | Eles/Elas | Terceira pessoa do plural |

**Dicas Importantes:**
- **He/She:** Use `he` para homens e `she` para mulheres. Dica: Lembre-se dos super-heróis "He-Man" e "She-Ra".
- **It:** Use para objetos, animais e coisas, mesmo que em português tenham gênero (ex: a mesa = `it`, o livro = `it`).
- **You:** Serve tanto para "você" (singular) quanto "vocês" (plural).

#### 4. Usando a Terceira Pessoa (He/She)
Agora podemos fazer perguntas sobre outras pessoas.

**Estrutura com "He" (Ele):**
- `What's his name?` (Qual é o nome dele?)
- `His name is...` (O nome dele é...)
- `What city is he from?` (De que cidade ele é?)
- `He is from...` (Ele é de...)
- `What's his nationality?` (Qual é a nacionalidade dele?)
- `He is...` (Ele é...)

**Estrutura com "She" (Ela):**
- `What's her name?` (Qual é o nome dela?)
- `Her name is...` (O nome dela é...)
- `What city is she from?` (De que cidade ela é?)
- `She is from...` (Ela é de...)
- `What's her nationality?` (Qual é a nacionalidade dela?)
- `She is...` (Ela é...)

**Exemplo de Diálogo (Sobre "Takashi"):**
- A: `What's his name?`
- B: `His name is Takashi.`
- A: `What city is he from?`
- B: `He is from Nagoya.`
- A: `What's his nationality?`
- B: `He is Japanese.`

**Exemplo de Diálogo (Sobre "Bridget"):**
- A: `What's her name?`
- B: `Her name is Bridget.`
- A: `What city is she from?`
- B: `She is from Lyon.`
- A: `What's her nationality?`
- B: `She is French.`

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`nationality`, `name`, `city`, `country`, `Argentina`, `Brazil`, `Canada`, `China`, `England`, `France`, `Germany`, `Italy`, `Japan`, `Portugal`, `Spain`, `USA`

**Adjetivos (Adjectives):**
`Argentinian`, `Brazilian`, `Canadian`, `Chinese`, `English`, `French`, `German`, `Italian`, `Japanese`, `Portuguese`, `Spanish`, `American`

**Pronomes (Pronouns):**
`I`, `you`, `he`, `she`, `it`, `we`, `they`, `his`, `her`

**Verbos (Verbs):**
`am`, `are`, `is` (verbo to be)

**Preposições (Prepositions):**
`from`

---

### 💡 Dicas do Professor
- **Nacionalidade é sobre a Pessoa:** Sempre responda `I am [nacionalidade]`, nunca `My nationality is...`.
- **Pratique os Pronomes:** Entender e usar corretamente `he`, `she` e `it` é um passo fundamental para formar frases mais complexas.
- **Cuidado com "It":** Objetos e animais são sempre `it`, mesmo que em português sejam "ele" ou "ela".
- **Use os Diálogos como Modelo:** Pratique os diálogos de exemplo trocando os nomes, cidades e nacionalidades. Isso ajudará a fixar as estruturas.