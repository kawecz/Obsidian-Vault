---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Como se apresentar em Inglês | Curso Completo - aula #02" src="https://www.youtube.com/embed/mTHfVglQSRc?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 02: Introduções e Apresentações em Inglês (Introductions)
> Esta aula expande o vocabulário de nomes, focando em como se apresentar e apresentar outras pessoas em inglês. O professor enfatiza a importância da prática diária de 10-20 minutos, a Pronúncia natural (como o "linking sound") e apresenta frases essenciais para interações sociais básicas.

[[aula2.pdf]]

---

### 📘 Tópicos da Aula
1.  **Revisão da Aula #01:** Partes do Nome
2.  **Introducing Yourself:** Apresentando-se
3.  **Saudações e "Prazer em Conhecê-lo":** `Nice to meet you` e variações
4.  **Introducing Other People:** Apresentando outras pessoas
5.  **Diálogos Práticos**

---

### 📖 Conteúdo Detalhado

#### 1. Revisão: Partes do Nome (Names)
| Termo em Inglês | Pronúncia (Dica) | Significado |
| :--- | :--- | :--- |
| **Full/Complete Name** | "ful neim" / "com-pliit neim" | Nome Completo |
| **First Name** | "férst neim" | Primeiro Nome |
| **Middle Name** | "mí-del neim" | Nome do Meio |
| **Last Name** | "last neim" | Último Nome/Sobrenome |
| **Family Name** | "fá-mi-li neim" | Nome de Família |
| **Surname** | "sêr-neim" | Sobrenome |

**Observações:**
- **`Middle Name`:** A pronúncia mais comum e fluida é "mí-del", onde o "d" soa como um "r" suave. Pronúncia formal ("mí-dol") também é aceita.
- **Atenção Cultural:** Perguntar o `middle name` de um estranho em culturas anglófonas (como EUA) pode ser considerado indelicado.

#### 2. Apresentando-se (Introducing Yourself)
- **Saudações Iniciais:**
    - `Hi` / `Hello` (Oi / Olá)
- **Frases para se Apresentar:**
    - `I am...` (Eu sou...) -> Forma Contraída: `I'm...`
    - `My name is...` (Meu nome é...) -> Forma Contraída: `My name's...`
- **Diálogo Básico:**
    - A: `Hi, I am Paul. What's your name?`
    - B: `My name is Mike. Nice to meet you.`
    - A: `Nice to meet you too.`

#### 3. "Prazer em Conhecê-lo" (Nice to meet you)
- **Forma Principal:** `Nice to meet you.`
    - **Linking Sound:** Na fala rápida, "meet you" soa como "mi-tchu". Pronúncia: "nais tu mi-tchu".
- **Variações Comuns:**
    - `Glad to meet you.` (Feliz em conhecê-lo.)
    - `Pleased to meet you.` (Prazer em conhecê-lo.)
    - `It's a pleasure to meet you.` (É um prazer conhecê-lo.)
- **Uso do "too" (também):** Responder com `Nice to meet you too` é educado, mas não é estritamente obrigatório, especialmente se as falas se sobrepuserem.

#### 4. Apresentando Outras Pessoas (Introducing Other People)
- **Estrutura Básica:**
    - `[Pessoa A], this is [Pessoa B].` (Ex: `John, this is Sarah.`)
    - `[Pessoa B], this is [Pessoa A].` (Ex: `Sarah, this is John.`)
- **Frase Útil:**
    - `Let me introduce you to my friend...` (Deixe-me apresentar você ao meu amigo...)
    - `Let me introduce you to my brother...` (Deixe-me apresentar você ao meu irmão...)

#### 5. Diálogo de Exemplo (3 Pessoas)
- **Rui:** `Paul, this is my friend Mike.`
- **Paul:** `Hello, Mike. Nice to meet you.`
- **Mike:** `Hi, Paul. Nice to meet you too.`

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`introduction`, `name`, `first name`, `middle name`, `last name`, `friend`, `brother`, `pleasure`

**Adjetivos (Adjectives):**
`nice`, `glad`, `pleased`

**Verbos (Verbs):**
`to meet` (conhecer), `to introduce` (apresentar)

**Preposições (Prepositions):**
`to`

**Pronomes (Pronouns):**
`I`, `you`, `my`, `me`

**Expressões/Outros:**
`Hi`, `Hello`, `What's your name?`, `I am`, `My name is`, `Let me`

---

### 💡 Dicas do Professor
- **Constância > Duração:** Estude de 10 a 20 minutos por dia, todos os dias. É mais eficaz do que estudar por horas seguidas apenas uma vez por semana.
- **Pratique a Pronúncia:** Preste atenção aos "linking sounds" (como "meet you" virando "mi-tchu") para soar mais natural.
- **Interaja com o Vídeo:** Repita as frases em voz alta durante as pausas. A repetição é fundamental para a assimilação.
- **Não Traduza Literalmente:** Foque no significado e no uso das frases, não na tradução palavra por palavra.