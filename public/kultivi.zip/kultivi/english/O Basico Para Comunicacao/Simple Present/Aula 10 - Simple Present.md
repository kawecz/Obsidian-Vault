---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Inglês | Kultivi Extra Class - Simple Present | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/FUWtOkATf4c?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula Extra: Presente Simples (Simple Present)
> Esta aula explora a estrutura e o uso do Presente Simples em inglês. O foco está na conjugação de verbos, com atenção especial à terceira pessoa do singular (he, she, it), que segue regras específicas de acréscimo de sufixos. A aula também aborda a formação de frases negativas e interrogativas.

[[aula10.pdf]]

---

### 📘 Tópicos da Aula
1.  **Uso do Simple Present:** Hábitos e rotinas
2.  **Expressões de Tempo Comuns:** `every day`, `once a week`, etc.
3.  **Conjugação Afirmativa:** Regra geral e a 3ª pessoa do singular
4.  **Regras do "-s" na 3ª Pessoa:** `-s`, `-es`, `-ies`
5.  **Forma Negativa:** Uso de `do not` (`don't`) e `does not` (`doesn't`)
6.  **Forma Interrogativa:** Uso de `Do` e `Does`
7.  **Verbos Irregulares:** `to be` e `to have`

---

### 📖 Conteúdo Detalhado

#### 1. Uso do Simple Present
O Simple Present descreve:
- **Ações habituais e rotinas:** `I work every day.` (Eu trabalho todo dia.)
- **Fatos gerais e verdades universais:** `The sun rises in the east.` (O sol nasce no leste.)
- **Situações permanentes:** `She lives in London.` (Ela mora em Londres.)

#### 2. Expressões de Tempo com "Every"
| Expressão | Significado | Exemplo |
| :--- | :--- | :--- |
| **every day** | todos os dias | `I study every day.` |
| **every week** | toda semana | `She travels every week.` |
| **every weekend** | todo fim de semana | `We relax every weekend.` |
| **every month** | todo mês | `He pays bills every month.` |
| **every year** | todo ano | `They visit us every year.` |

**"Once" e "Twice":**
- **`once`** = uma vez -> `once a day` (uma vez por dia)
- **`twice`** = duas vezes -> `twice a week` (duas vezes por semana)
- Exemplo: `I go to the movies twice a month.` (Eu vou ao cinema duas vezes por mês.)

#### 3. Conjugação Afirmativa (Affirmative Form)
A grande diferença está na **terceira pessoa do singular (he, she, it)**.

| Pronome | Verbo (Ex: To Work) | Pronúncia | Exemplo |
| :--- | :--- | :--- | :--- |
| **I** | work | "uârk" | `I work.` |
| **You** | work | "uârk" | `You work.` |
| **He** | **works** | "uârks" | `He works.` |
| **She** | **works** | "uârks" | `She works.` |
| **It** | **works** | "uârks" | `It works.` (Isso funciona.) |
| **We** | work | "uârk" | `We work.` |
| **You** | work | "uârk" | `You work.` |
| **They** | work | "uârk" | `They work.` |

#### 4. Regras do "-s" na 3ª Pessoa do Singular (He, She, It)
| Regra | Verbo (Infinitivo) | 3ª Pessoa (He/She/It) | Exemplo |
| :--- | :--- | :--- | :--- |
| **Maioria dos verbos:** Acrescenta **`-s`** | work | work**s** | `He works every day.` |
| **Verbos terminados em `-ch, -sh, -ss, -x, -o, -z`:** Acrescenta **`-es`** | go | go**es** | `She goes to school.` |
| | kiss | kiss**es** | `He kisses his wife.` |
| **Verbos terminados em Consoante + `-y`:** Troca o `-y` por **`-ies`** | study | stud**ies** | `She studies English.` |
| | cry | cr**ies** | `The baby cries.` |
| **Verbos terminados em Vogal + `-y`:** Apenas acrescenta **`-s`** | play | play**s** | `He plays soccer.` |
| | buy | buy**s** | `She buys a car.` |

#### 5. Forma Negativa (Negative Form)
Usa-se o auxiliar **`do`** + **`not`** (ou **`does`** para he/she/it).

| Pronome | Forma Negativa | Contração | Exemplo |
| :--- | :--- | :--- | :--- |
| **I / You / We / They** | `do not work` | **`don't work`** | `They don't work here.` |
| **He / She / It** | `does not work` | **`doesn't work`** | `He doesn't work here.` |

**Observação:** Na negativa com `doesn't`, o verbo principal **volta para a forma base (sem -s)**.

#### 6. Forma Interrogativa (Interrogative Form)
Usa-se o auxiliar **`Do`** ou **`Does`** no início da frase.

| Pronome | Forma Interrogativa | Exemplo |
| :--- | :--- | :--- |
| **I / you / we / they** | `Do... work?` | `Do you work here?` |
| **he / she / it** | `Does... work?` | `Does she work here?` |

**Observação:** Na interrogativa com `Does`, o verbo principal **volta para a forma base (sem -s)**.

#### 7. Verbos Irregulares no Simple Present
Dois verbos essenciais não seguem as regras padrão.

**Verbo "To Be" (Ser/Estar)**

| Pronome | Conjugação |
| :--- | :--- |
| **I** | **am** |
| **You** | **are** |
| **He / She / It** | **is** |
| **We / You / They** | **are** |

**Verbo "To Have" (Ter)**
| Pronome | Conjugação |
| :--- | :--- |
| **I / You / We / They** | **have** |
| **He / She / It** | **has** |

---

### 📚 Categorização de Palavras-Chave

**Verbos (Verbs):**
`to work`, `to go`, `to kiss`, `to study`, `to cry`, `to play`, `to have`, `to be`

**Auxiliares:**
`do`, `does`, `don't`, `doesn't`

**Advérbios de Frequência:**
`every day`, `every week`, `every weekend`, `every month`, `every year`, `once`, `twice`

**Pronomes (Pronouns):**
`I`, `you`, `he`, `she`, `it`, `we`, `they`

---

### 💡 Dicas do Professor
- **A 3ª Pessoa é a Chave:** Todo o esforço de memorização está na terceira pessoa do singular (he, she, it). Domine as regras do `-s`, `-es` e `-ies`.
- **O Auxiliar "Rouba" o "-s":** Em frases negativas e interrogativas com `doesn't` e `does`, lembre-se que o verbo principal perde o "s". O auxiliar já carrega a informação da 3ª pessoa.
- **Pratique com Rotinas:** A melhor maneira de fixar o Simple Present é descrevendo sua rotina diária e seus hábitos.
- **Cuidado com os Irregulares:** Decore as conjugações únicas de `to be` e `to have`, pois elas são muito frequentes.