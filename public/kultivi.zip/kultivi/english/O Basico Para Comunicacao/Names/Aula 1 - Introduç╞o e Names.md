---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Inglês Curso Gratuito Completo | Prof Rui Ventura - Apresentação e aula #01" src="https://www.youtube.com/embed/1gm2HbEaZBE?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 01: Nomes em Inglês (Names)
> Esta primeira aula foca no vocabulário essencial para falar sobre nomes próprios em inglês. O professor Rui Ventura apresenta as diferentes partes de um nome (primeiro, meio, último) e suas variações de uso, com forte ênfase na prática de pronúncia e entonação através da repetição.

[[aula1.pdf]]

---

### 📘 Tópicos da Aula
1.  **Perguntando o Nome:** `What's your name?`
2.  **Partes de um Nome:** `first name`, `middle name`, `last name`, etc.
3.  **Prática de Pronúncia e Entonação**

---

### 📖 Conteúdo Detalhado

#### 1. Perguntando e Respondendo
- **Pergunta Principal:** `What's your name?` (Qual é o seu nome?)
    - Pronúncia: "wats ior neim".
    - É a contração de `What is your name?`.
- **Respostas Comuns:**
    1.  `My name is...` (Correta, mas soa muito formal/gramatical)
    2.  `It's...` (Forma mais natural e usual. Ex: `It's Rui`)
    3.  Dizer apenas o nome (Ex: `Rui`). Pode soar rude ou muito curto.

#### 2. Partes de um Nome (Estrutura)
| Termo em Inglês | Significado Equivalente | Exemplo (Professor) | Exemplo (Fictício) |
| :--- | :--- | :--- | :--- |
| **Full/Complete Name** | Nome Completo | Rui Basílio Novak da Silveira Cruz Ventura | Jonathan Smith Peterson |
| **First Name** | Primeiro Nome | Rui | Jonathan |
| **Christian Name** | Primeiro Nome (em contextos específicos) | Rui | Jonathan |
| **Forename** | Primeiro Nome (formal, para formulários) | Rui | Jonathan |
| **Middle Name** | Nome do Meio | Basílio Novak da Silveira Cruz | Smith |
| **Last Name** | Último Nome (Sobrenome) | Ventura | Peterson |
| **Family Name** | Nome de Família (Sobrenome) | Ventura | Peterson |
| **Surname** | Sobrenome | Ventura | Peterson |

**Observações Importantes:**
- **Foco Principal:** Para comunicação eficaz, concentre-se em `first name`, `middle name`, `last name` e `full name`.
- **Cultural:** Em culturas anglófonas (como EUA), perguntar o `middle name` de alguém que você acabou de conhecer pode ser considerado indelicado.
- **Nomes Compostos:** Nomes como "Rui Basílio" são entendidos com "Rui" sendo o `first name` e "Basílio" parte do `middle name`.

#### 3. Pronúncia e Entonação
- **`Middle Name`:** A pronúncia comum é "mí-del neim", onde o "d" soa como um "r" suave.
- **Entonação:** A forma como se fala uma frase altera seu significado.
    - `You work here.` (Afirmação)
    - `You work here?` (Pergunta)
- **Dica do Professor:** Não tente traduzir todas as palavras ao pé da letra (ex: `forename`, `surname`). Aprenda os conceitos.

#### 4. Frases Práticas para Treinar
- **Perguntando:**
    - `What's your full name?` -> `My full name is...`
    - `What's your first name?` -> `My first name is...` / `It's...`
    - `What's your last name?` -> `My last name is...` / `It's...`
- **Se não tem nome do meio:**
    - `Sorry, I don't have a middle name.`

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`name`, `first name`, `middle name`, `last name`, `full name`, `complete name`, `Christian name`, `forename`, `family name`, `surname`, `detail`, `pronunciation`, `intonation`, `phrase`, `conversation`, `grammar`, `video`, `course`, `tool`, `notebook`, `dictionary`

**Adjetivos (Adjectives):**
`full`, `complete`, `first`, `middle`, `last`, `Christian`, `family`, `fantastic`, `free` (gratuito), `natural`, `important`, `perfect`, `usual`, `grammatical`

**Preposições (Prepositions):**
`of`, `about`, `with`, `through`, `for`, `in`, `on`

---

### 💡 Dicas do Professor
- **Caderno Pessoal:** Tenha um caderno para anotar palavras novas. Separe páginas por letras para criar seu próprio dicionário.
- **Repetição:** Participe ativamente repetindo as frases dos vídeos. A repetição é crucial para a assimilação.
- **Confiança:** É possível aprender um inglês de qualidade e com pronúncia excelente sem morar fora do país.
- **Sequência:** Assista aos vídeos em ordem, sem pular, para não se perder no conteúdo.