---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Cumprimentos, saudações em Inglês II | Curso Completo - aula #04" src="https://www.youtube.com/embed/keF8V38A64U?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

----
> [!abstract] Aula 03.2: Saudações e Cumprimentos em Inglês (Greetings) - Parte 2
> Esta aula é a continuação direta da Aula #03, aprofundando as respostas à pergunta "How are you?". O foco está em ensinar como responder de maneira variada e natural, como agradecer e como devolver a pergunta de forma educada, incluindo uma gíria comum.

[[aula3.2.pdf]]

---

### 📘 Tópicos da Aula
1.  **Como Responder a "How are you?":** Variações de "Estou bem"
2.  **Como Agradecer:** `Thanks` vs. `Thank you`
3.  **Como Devolver a Pergunta:** `And you?`, `How about you?`, `What about you?`
4.  **Gíria (Slang):** `What's up?` e `Not much`
5.  **Diálogo de Exemplo**

---

### 📖 Conteúdo Detalhado

#### 1. Respondendo a "How are you?" (Parte 1: Intensificadores)
A resposta é dividida em partes que podem ser combinadas.

**Intensificadores (Como você está se sentindo):**

| Inglês | Pronúncia (Dica) | Significado |
| :--- | :--- | :--- |
| **I am / I'm** | "ai am" / "aim" | Eu estou |
| **very** | "vé-ri" | Muito |
| **pretty** | "pri-ti" | Muito (no contexto) |
| **quite** | "kuáit" | Bastante, Muito |

**Intensificadores (Estado):**

| Inglês | Pronúncia (Dica) | Significado |
| :--- | :--- | :--- |
| **fine** | "fáin" | Bem |
| **well** | "uél" | Bem |
| **good** | "gud" | Bem/Bom |
| **great** | "grêit" | Ótimo |
| **fantastic** | "fan-tás-tic" | Fantástico |
| **not bad** | "not bád" | Não mal (= Bem) |
| **so-so** | "sou-sou" | Mais ou menos |
| **not very well** | "not vé-ri uél" | Não muito bem |

**Combinações Práticas:**
- `I'm very well.` (Estou muito bem.)
- `I'm pretty good.` (Estou muito bem.)
- `I'm quite fine.` (Estou bastante bem.)
- `I'm great.` (Estou ótimo.)
- `Not bad.` (Não está mal.)
- `So-so.` (Mais ou menos.)

#### 2. Como Agradecer (Parte 2)
- **`Thanks`**: Pronúncia: "thánks". (Obrigado(a)). Foco no som de "TH" (língua entre os dentes).
- **`Thank you`**: Pronúncia: "thánk iu". (Obrigado(a)). Mesmo som de "TH".

**Dica de Pronúncia do "TH":**
- Coloque a ponta da língua levemente entre os dentes da frente e sopre o ar. Soa como um "s" com a língua para fora.
- Exemplo: "thanks" soa como se você estivesse dizendo o meio da palavra "paçoca" (só o "aço"), mas com a língua nos dentes.

#### 3. Devolvendo a Pergunta (Parte 3)
- **`And you?`** (E você?) -> O mais comum e básico.
- **`How about you?`** (E sobre você?)
- **`What about you?`** (E você?)

**Observação:** Não tente traduzir `How/What about you?` literalmente. Entenda a ideia de "devolver a pergunta" que eles transmitem.

#### 4. Gíria (Slang) do Dia
- **`What's up?`** Pronúncia: "uâts âp". (E aí? / Qual é?)
    - Resposta comum: **`Not much.`** (Nada demais. / Nada de mais.)

#### 5. Diálogo de Exemplo Completo
- **John:** `Hello, Paul. How are you?`
- **Paul:** `Hi, John. I'm fine, thanks. And you?`
- **John:** `Pretty good, thank you.`
- **Paul:** `Well, I have to go now. Goodbye, John. See you tomorrow.`
- **John:** `Bye-bye, Paul. Take care. See you soon. Bye.`

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`thanks`, `slang`

**Adjetivos (Adjectives):**
`fine`, `well`, `good`, `great`, `fantastic`, `bad`, `pretty` (como intensificador), `very`, `quite`, `so-so`

**Verbos (Verbs):**
`to be` (em `I am`)

**Expressões/Outros:**
`How are you?`, `And you?`, `How about you?`, `What about you?`, `What's up?`, `Not much`, `I have to go now`, `See you tomorrow`, `Take care`, `See you soon`

---

### 💡 Dicas do Professor
- **Combinações são Chave:** Misture as partes da resposta (Intensificador + Estado) para soar mais natural. Ex: `Pretty good`, `Very well`.
- **Foque no Básico:** A combinação mais comum e suficiente é: `Fine, thanks. And you?`
- **Pratique o "TH":** Dominar o som do "TH" é crucial para uma pronúncia correta de palavras extremamente comuns como "thanks" e "thank you".
- **Use as Gírias com Cautela:** `What's up?` é muito informal. Use apenas em contextos descontraídos com amigos.