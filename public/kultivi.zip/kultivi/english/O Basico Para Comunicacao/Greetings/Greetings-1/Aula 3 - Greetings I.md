---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Cumprimentos, saudações em Inglês I | Curso Completo - aula #03" src="https://www.youtube.com/embed/hOltSi7Sw-A?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

----
> [!abstract] Aula 03: Saudações e Cumprimentos em Inglês (Greetings) - Parte 1
> Esta aula foca nas saudações (greetings) e despedidas (goodbyes) em inglês, abrangendo desde as formas mais simples até interações um pouco mais elaboradas. O professor Rui Ventura reforça a importância da prática diária de 10-20 minutos e introduz a estrutura básica de uma conversa educada.

[[aula3.pdf]]

---

### 📘 Tópicos da Aula
1.  **Revisão das Aulas #01 e #02**
2.  **Saudações Informais:** `Hi`, `Hello`
3.  **Saudações Formais (com o horário):** `Good morning`, `Good afternoon`, `Good evening`
4.  **Despedidas (Goodbyes):** `Goodbye`, `Good night`, `Bye`, `See you later`, `So long`, `Take care`
5.  **Frase Útil para Despedir-se:** `I'm sorry, but I have to go now.`
6.  **Perguntando "Como você está?":** `How are you?` e variações

---

### 📖 Conteúdo Detalhado

#### 1. Revisão Rápida
- **Nomes (Aula #01):** `first name`, `middle name`, `last name`, `full name`.
- **Apresentações (Aula #02):** `Hi, my name is...`, `Nice to meet you`, `This is...`.

#### 2. Saudações (Greetings)
- **Informais:**
    - `Hi` (Oi)
    - `Hello` (Olá)
- **Formais (Relacionadas ao horário):**
    - `Good morning` (Bom dia) -> Usado até aproximadamente meio-dia.
    - `Good afternoon` (Boa tarde) -> Usado do meio-dia até o final da tarde.
        - Pronúncia: "gud af-ter-NOON". A tonicidade está em "noon".
    - `Good evening` (Boa noite) -> Usado como saudação ao chegar, a partir do fim da tarde/começo da noite.

#### 3. Despedidas (Goodbyes)
- `Goodbye` (Adeus) -> Mais formal.
- `Good night` (Boa noite) -> Usado **apenas** como despedida, ao final de um encontro.
- `Bye` / `Bye-bye` (Tchau) -> Informal.
- `See you later` (Vejo você mais tarde) -> Quando se planeja ver a pessoa em breve.
- `So long` (Até logo) -> Informal.
- `Take care` (Se cuida) -> Informal e amigável.
- `See you around` (Te vejo por aí) -> Informal.

**Diferença Crucial:**
- `Good evening` = Saudação (ao chegar).
- `Good night` = Despedida (ao ir embora).

#### 4. Frase Útil para se Despedir
- `I'm sorry, but I have to go now.` (Desculpe, mas eu tenho que ir agora.)
    - **Verbos novos:**
        - `to have` (ter)
        - `to go` (ir)

#### 5. Perguntando "Como você está?"
- **Perguntas Comuns (todas significam "Como vai você?"):**
    - `How are you?` (O mais comum)
    - `How are you doing?`
    - `How's it going?`
    - `How are things?`
    - `How's life treating you?` (Como a vida está tratando você?)
- **Estrutura de Resposta Educada:**
    1.  **Responder** ao estado: `I'm fine.` / `I'm pretty fine.` (Estou bem.)
    2.  **Agradecer** a preocupação: `Thanks.` (Obrigado.)
    3.  **Devolver a pergunta:** `And you?` (E você?)

**Exemplo de Diálogo:**
- A: `How are you?`
- B: `I'm pretty fine, thanks. And you?`
- A: `I'm fine, thanks.`

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`greeting`, `morning`, `afternoon`, `evening`, `night`, `life`, `things`, `thanks`, `care`

**Adjetivos (Adjectives):**
`good`, `fine`, `pretty` (no sentido de "bastante", "muito")

**Verbos (Verbs):**
`to have`, `to go`, `to be` (em `I'm`), `to do` (em `How are you doing?`), `to treat` (em `How's life treating you?`)

**Preposições (Prepositions):**
`but`, `and`, `around`

**Expressões/Outros:**
`Hi`, `Hello`, `Goodbye`, `Bye`, `See you`, `So long`, `Take care`, `How are you?`, `I'm sorry`

---

### 💡 Dicas do Professor
- **Constância:** Estude de 10 a 20 minutos por dia. É mais eficaz do que estudar por horas e depois ficar dias sem praticar.
- **Entonação:** Preste atenção na entonação de pergunta. Frases como `How are you?` sobem no final.
- **Linking Sound:** Na fala rápida, palavras se conectam. Exemplo: `Take care` soa como "tei-keir".
- **Pratique a Resposta Completa:** Ao responder "Como você está?", treine a estrutura completa: responder + agradecer + devolver a pergunta. Isso soa muito mais natural e educado.