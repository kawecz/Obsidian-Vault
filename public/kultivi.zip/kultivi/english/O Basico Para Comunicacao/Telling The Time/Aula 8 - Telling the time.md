---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Inglês | Kultivi - Telling the time | CURSO GRATUITO COMPLETO - Aula #12" src="https://www.youtube.com/embed/scuDZxa5odU?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 8: Dizendo as Horas em Inglês (Telling the Time)
> Esta aula ensina a perguntar e a dizer as horas em inglês. O foco está nas estruturas usadas para horários "cheios", "e minutos" e "para minutos", incluindo o uso de termos específicos como `quarter` (quinze) e `half` (meia). A aula também aborda o uso contextual de `a.m.` e `p.m.`.

[[aula8.pdf]]

---

### 📘 Tópicos da Aula
1.  **Perguntando as Horas:** `What time is it?`
2.  **Horas Cheias:** Uso de `o'clock`
3.  **Minutos Passados da Hora (00-30):** Uso de `past`
4.  **Minutos para a Hora (31-59):** Uso de `to`
5.  **Termos Especiais:** `a quarter` (15), `half` (30)
6.  **Uso de A.M. e P.M.**

---

### 📖 Conteúdo Detalhado

#### 1. Perguntando as Horas
- **Pergunta Principal:** `What time is it?` (Que horas são?)
- **Forma Comum:** `What time is it now?` (Que horas são agora?)

#### 2. Horas Cheias (Ex: 7:00, 8:00, 9:00)
- **Estrutura:** `It's + [hora] + o'clock.`
- **`o'clock`:** Usado **apenas** para horários redondos (minutos = 00).
- **Exemplos:**
    - `It's 7 o'clock.` (São 7 horas.)
    - `It's 12 o'clock.` (São 12 horas.)

#### 3. Minutos Passados da Hora (00-30 Minutos)
Quando os minutos estão entre 1 e 30, dizemos quantos minutos **passaram** da hora.

- **Estrutura:** `It's + [minutos] + past + [hora].`
- **Exemplos:**
    - `It's five past seven.` (São 7:05.)
    - `It's ten past seven.` (São 7:10.)
    - `It's (a) quarter past seven.` (São 7:15.) -> `a quarter` = 15 minutos
    - `It's twenty-five past seven.` (São 7:25.)
    - `It's half past seven.` (São 7:30.) -> `half` = 30 minutos

#### 4. Minutos para a Hora (31-59 Minutos)
Quando os minutos estão entre 31 e 59, dizemos quantos minutos **faltam** para a próxima hora.

- **Estrutura:** `It's + [minutos] + to + [próxima hora].`
- **Exemplos:**
    - `It's twenty to eight.` (São 7:40.) -> Faltam 20 para as 8.
    - `It's (a) quarter to eight.` (São 7:45.) -> Faltam 15 para as 8.
    - `It's five to eight.` (São 7:55.) -> Faltam 5 para as 8.

#### 5. Resumo Visual: Estrutura do Relógio
| Minutos | Pronúncia | Estrutura | Exemplo (7:XX) |
| :--- | :--- | :--- | :--- |
| **:00** | `o'clock` | `It's [hora] o'clock.` | `It's 7 o'clock.` |
| **:01 - :30** | `past` | `It's [min] past [hora].` | `It's ten past seven.` (7:10) |
| **:15** | `a quarter past` | `It's (a) quarter past [hora].` | `It's (a) quarter past seven.` (7:15) |
| **:30** | `half past` | `It's half past [hora].` | `It's half past seven.` (7:30) |
| **:31 - :59** | `to` | `It's [min] to [hora+1].` | `It's twenty to eight.` (7:40) |
| **:45** | `a quarter to` | `It's (a) quarter to [hora+1].` | `It's (a) quarter to eight.` (7:45) |

#### 6. Uso de A.M. e P.M.
- **A.M.** (*Ante Meridiem*): Meia-noite (00:00) ao meio-dia (11:59).
- **P.M.** (*Post Meridiem*): Meio-dia (12:00) à meia-noite (23:59).
- **Uso no Dia a Dia:** Em conversas informais, quando o contexto já deixa claro se é manhã, tarde ou noite, o uso de `a.m.`/`p.m.` é opcional.
    - Ex: Se é de tarde e alguém pergunta "What time is it?", a resposta `It's 4 o'clock` é suficiente. Não é necessário dizer `It's 4 p.m.`.

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`time`, `hour`, `minute`, `quarter`, `half`, `clock`

**Preposições (Prepositions):**
`past`, `to`

**Expressões/Outros:**
`o'clock`, `a.m.`, `p.m.`, `What time is it?`

---

### 💡 Dicas do Professor
- **`o'clock` só para hora cheia:** Lembre-se que `o'clock` é usado exclusivamente quando os minutos são zero.
- **A Regra do 30 Minutos:** Use `past` para minutos de 1 a 30. Use `to` para minutos de 31 a 59.
- **Pratique com um Relógio de Ponteiro:** É mais fácil visualizar a regra do `past` e `to` com um relógio analógico.
- **Contexto é Tudo:** Em conversas casuais, você raramente precisará usar `a.m.` ou `p.m.`. Apenas mencione se houver ambiguidade.
- **Formas Alternativas:** Você sempre pode dizer o horário de forma direta (ex: `It's seven ten` para 7:10). As formas com `past` e `to` soam um pouco mais formais/nativas.