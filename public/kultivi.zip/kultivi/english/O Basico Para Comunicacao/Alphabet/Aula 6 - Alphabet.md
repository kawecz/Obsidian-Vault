---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - basico
---

---
<iframe title="Inglês | Kultivi - Alphabet | CURSO GRATUITO COMPLETO - Aula #09" src="https://www.youtube.com/embed/6Ulu7lMbUUw?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 6: O Alfabeto Inglês (The Alphabet) e Soletração (Spelling)
> Esta aula é dedicada ao alfabeto inglês e à prática da soletração (spelling). Dominar a pronúncia correta de cada letra é fundamental para soletrar nomes, endereços e qualquer palavra nova que você encontrar. A aula inclui a clássica "Alphabet Song" para auxiliar na memorização.

[[aula6.pdf]]

---

### 📘 Tópicos da Aula
1.  **O Alfabeto Inglês:** Pronúncia de cada letra
2.  **A "Alphabet Song":** Música para memorização
3.  **Letras que Causam Confusão:** Grupos com sons similares
4.  **Como Pedir para Soletrar:** `How do you spell...?`
5.  **Prática de Soletração:** Soletrando sobrenomes

---

### 📖 Conteúdo Detalhado

#### 1. O Alfabeto Inglês (The Alphabet)
A pronúncia das letras em inglês é diferente do português. Abaixo está a lista completa com a pronúncia aproximada.

| Letra | Pronúncia (Fonética) | Letra | Pronúncia (Fonética) |
| :--- | :--- | :--- | :--- |
| **A** | "êi" | **N** | "én" |
| **B** | "bî" | **O** | "ôu" |
| **C** | "cî" | **P** | "pî" |
| **D** | "dî" | **Q** | "kiú" |
| **E** | "î" | **R** | "ár" |
| **F** | "éf" | **S** | "éss" |
| **G** | "dgî" | **T** | "tî" |
| **H** | "êitch" | **U** | "iú" |
| **I** | "ái" | **V** | "vî" |
| **J** | "dgêi" | **W** | "dâb-liu" |
| **K** | "kêi" | **X** | "éks" |
| **L** | "él" | **Y** | "uái" |
| **M** | "ém" | **Z** | "zî" |

#### 2. A "Alphabet Song" (A Música do Alfabeto)
Cantar a música é uma excelente forma de memorizar a ordem e a pronúncia.
- **Letra:** `A B C D E F G, H I J K L M N O P, Q R S T U V, W X Y and Z.`
- **Dica:** Procure por "Alphabet Song" no YouTube para praticar.

#### 3. Grupos de Letras que Causam Confusão
Alguns sons são muito similares e confundem os falantes de português.

| Grupo | Letras | Pronúncia | Dica para Lembrar |
| :--- | :--- | :--- | :--- |
| **Vogais** | `A`, `E`, `I` | "êi", "î", "ái" | Pratique a sequência: "êi, î, ái" |
| | `Y` | "uái" | Soa como "uái" |
| **Consoantes 1** | `D`, `G` | "dî", "dgî" | Lembre-se de "DJ" (Disk Jockey) |
| | `J` | "dgêi" | |
| **Consoantes 2** | `K`, `Q` | "kêi", "kiú" | Lembre-se de "OK" ("ôu kêi") |
| **Consoantes 3** | `M`, `N` | "ém", "én" | `M` a boca fecha, `N` a boca fica aberta |

#### 4. Como Pedir para Soletrar (How do you spell...?)
- **`How do you spell your last name?`** (Como você soletra o seu sobrenome?)
- **`How do you spell it?`** (Como soletra isso?) -> Mais comum e natural.
- **`Can you spell [palavra], please?`** (Você pode soletrar [palavra], por favor?) -> Formal e educado.

#### 5. Prática de Soletração (Spelling Practice)
**Soletrando Sobrenomes:**
- **Ventura:** `V - E - N - T - U - R - A`
- **Williams:** `W - I - L - L - I - A - M - S` (Nota: "LL" é pronunciado como `double L`)
- **Zweig:** `Z - W - E - I - G`
- **Roosevelt:** `R - O - O - S - E - V - E - L - T`
- **Schwarzenegger:** `S - C - H - W - A - R - Z - E - N - E - G - G - E - R` (Nota: "GG" é `double G`)

**Dica de Pronúncia do "W":**
- A pronúncia mais comum e padrão é **"dâb-liu"**. A pronúncia "dâb-liu" também existe, mas é menos usual.

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`alphabet`, `letter`, `name`, `last name`, `spelling`

**Verbos (Verbs):**
`to spell` (soletrar)

**Pronomes (Pronouns):**
`it`, `your`, `her`, `his`

**Expressões/Outros:**
`How do you...?`, `Can you...?`, `please`, `double` (para letras repetidas)

---

### 💡 Dicas do Professor
- **Pratique com a Música:** Cantar o alfabeto várias vezes ao dia é a maneira mais rápida de decorar.
- **Crie uma Lista Pessoal:** Pegue 10 palavras por dia (pode ser em português mesmo) e pratique soletrá-las em inglês. Isso treina o reconhecimento das letras e sua pronúncia.
- **Foque nos Sons Diferentes:** Dedique um tempo extra para praticar as letras `A, E, I, G, J, W` e `Y`, que têm os sons mais diferentes para um falante de português.
- **Use "How do you spell it?":** Esta é a forma mais natural e comum de pedir para soletrar algo que você acabou de ouvir.
- **"Double" para Letras Repetidas:** Ao soletrar, quando uma letra se repete, diga `double` + a letra. Ex: `L` -> `double L`.