---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - adjetivos_pronomes
---

---
<iframe title="Inglês | Kultivi Extra Class - Places in Town II | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/80pdjLPY3_k?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Lugares na Cidade (Places in Town) - Parte 2: Localização
> Esta segunda aula foca em como perguntar e dar a localização de lugares na cidade. Aprenderemos estruturas para perguntar se algo existe em uma área e como descrever onde um local está situado usando preposições de lugar.

[[../aula5.pdf|aula5]]

---

### **Perguntando sobre a Existência de um Local**
**Estrutura:** `Excuse me, is there a [local] [here/around/nearby]?`
- **Significado:** Com licença, existe um(a) { local }  aqui por perto/na redondeza?
- **Variações:** `here`, `around`, `nearby` são intercambiáveis.

**Exemplo Prático:**
- **Pergunta:** `Excuse me, is there a restaurant here?`
- **Tradução:** Com licença, existe um restaurante aqui perto?

#### **Respostas Possíveis:**
| Resposta (Inglês) | Resposta (Português) | Uso |
| :--- | :--- | :--- |
| **Yes, there is.** | Sim, existe. | Resposta afirmativa para UM local. |
| **Yes, there are some.** | Sim, existem alguns. | Resposta afirmativa para VÁRIOS locais (plural). |
| **No, there isn't.** | Não, não existe. | Resposta negativa. |
| **Sorry, I don't know.** | Desculpe, eu não sei. | Quando não se sabe a resposta. |

---

### **Perguntando e Descrevendo a Localização**
**Pergunta Chave:** `Where is the [local]?` (Onde fica o/a {local}?)

#### **Preposições de Lugar para Dar a Localização**
| Preposição/Expressão | Significado | Uso | Exemplo |
| :--- | :--- | :--- | :--- |
| **On** | Na / No | Para indicar a rua onde algo está. | `It's on Main Street.` (Fica na Rua Principal.) |
| **Across from** | Em frente (do outro lado da rua) | Para algo diretamente do outro lado. | `It's across from the bank.` (Fica em frente ao banco.) |
| **Next to / Beside** | Ao lado de | Para algo adjacente, muito próximo. | `It's next to the school.` (Fica ao lado da escola.) |
| **Between** | Entre | Para algo no meio de dois outros. | `It's between the post office and the movie theater.` (Fica entre o correio e o cinema.) |
| **On the corner of** | Na esquina de | Para algo localizado no cruzamento de duas ruas. | `It's on the corner of Main Street and Second Street.` (Fica na esquina da Rua Principal com a Segunda Rua.) |

---

### **Diálogo de Exemplo e Estrutura Completa**
**Situação:** Alguém quer comprar um livro.
- **Pessoa A:** `I want to buy a book. Is there a bookstore around?` (Eu quero comprar um livro. Existe uma livraria por perto?)
- **Pessoa B:** `Yes, there is.` (Sim, existe.)
- **Pessoa A:** `Where is the bookstore?` (Onde é a livraria?)
- **Pessoa B (resposta detalhada):** `The bookstore is on First Street. It's next to the school and across from the library.` (A livraria fica na Primeira Rua. Fica ao lado da escola e em frente à biblioteca.)

**Dica:** Para dar uma localização precisa, comece sempre pela rua (`on [street name]`), depois adicione as outras preposições.

---

### **Análise Gramatical e Vocabulário**

#### **Substantivos (Nouns) - Novos Locais**
- **Drugstore** (Farmácia)
- **Bank** (Banco)
- **Train Station** (Estação de Trem)
- **Hospital** (Hospital)

#### **Adjetivos (Adjectives)**
- **Main** (Principal) - `Main Street`
- **First, Second** (Primeira, Segunda) - `First Street`, `Second Street`
- **Central** (Central) - `Central Avenue`

#### **Preposições (Prepositions) - Revisão e Novas**
- **On** (em, sobre uma superfície/rua)
- **From** (de)
- **To** (para)
- **And** (e)

#### **Verbos (Verbs)**
- **To be** (Ser/Estar) - Forma `is` em `Where is...?` e `It is...`.
- **To know** (Saber) - `I don't know`.

#### **Expressões Chave**
- **Excuse me** (Com licença)
- **I don't know** (Eu não sei)