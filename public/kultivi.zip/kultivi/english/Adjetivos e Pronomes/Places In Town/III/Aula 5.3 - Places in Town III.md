---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - adjetivos_pronomes
---

---
<iframe title="Inglês Kultivi | Extra Class - Places In Town III | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/3kM5i_aoU3Q?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Lugares na Cidade (Places in Town) - Parte 3: Como Chegar
> Esta terceira e última aula da série ensina a dar e entender direções para chegar a um local específico. O foco está no vocabulário de movimentos e na estruturação de instruções claras.


[[../aula5.pdf|aula5]]

---

### **Perguntando Como Chegar a um Local**
**Estrutura:** `How can I get to the [local]?`
- **Significado:** Como posso chegar ao/à {local}?
- **Exemplo:** `How can I get to the bank?` (Como posso chegar ao banco?)

---

### **Instruções de Direção (Comandos)**
| Comando | Significado | Uso |
| :--- | :--- | :--- |
| **Go ahead for [number] blocks.** | Siga em frente por [número] quadras. | Para indicar distância linear. |
| **Go straight ahead.** | Siga em frente. / Vá reto. | Sinônimo mais comum de `go ahead`. |
| **Go up the street.** | Siga (subindo) a rua. | Usado seguindo o fluxo dos carros ou apontando para "cima" no mapa. |
| **Go down the street.** | Sigue (descendo) a rua. | Usado no contrafluxo ou apontando para "baixo" no mapa. |
| **Turn right.** | Vire à direita. | |
| **Turn left.** | Vire à esquerda. | |
| **Take the U-turn.** | Pegue o retorno. | Para fazer uma curva de 180 graus. |
| **Cross the street.** | Atravesse a rua. | |

---

### **Especificando Onde Virar**
| Estrutura | Significado | Exemplo |
| :--- | :--- | :--- |
| **Turn right/left on [street name].** | Vire à direita/esquerda NA [nome da rua]. | `Turn right on Main Street.` |
| **Turn right/left at the [ponto de referência].** | Vire à direita/esquerda NO/NA [ponto de referência]. | `Turn left at the traffic light.` (… no semáforo.) `Turn right at the drugstore.` (… na farmácia.) |

**Pontos de Referência Comuns:**
- **Traffic Light** (Semáforo)
- **Blinking Light** (Luz intermitente/piscante)
- **Drugstore** (Farmácia)
- **Hospital** (Hospital)
- **Movie Theater** (Cinema)

---

### **Indicando a Chegada ao Local**
**Estrutura:** `The [local] is on your [left/right].`
- **Significado:** O/A {local} estará à sua {esquerda/direita}.
- **Exemplo 1:** `The bank is on your right.` (O banco estará à sua direita.)
- **Exemplo 2:** `The church is on your left.` (A igreja estará à sua esquerda.)

---

### **Diálogo de Exemplo Completo**
**Situação:** Chegando ao Coffee Shop.
- **Pessoa A:** `How can I get to the coffee shop?` (Como posso chegar à cafeteria?)
- **Pessoa B (dando as direções):**
    1.  `Go ahead for two blocks.` (Siga em frente por duas quadras.)
    2.  `Turn right.` (Vire à direita.)
    3.  `Go ahead for four blocks.` (Siga em frente por quatro quadras.)
    4.  `Turn left.` (Vire à esquerda.)
    5.  `Go ahead for one block.` (Siga em frente por uma quadra.)
    6.  `Cross the street.` (Atravesse a rua.)
    7.  `The coffee shop is on your left.` (A cafeteria estará à sua esquerda.)

---

### **Análise Gramatical e Vocabulário**

#### **Substantivos (Nouns)**
- **Block** (Quadra)
- **Street** (Rua)
- **Avenue** (Avenida)
- **Traffic Light** (Semáforo)
- **U-turn** (Retorno)

#### **Adjetivos (Adjectives)**
- **Right** (Direita)
- **Left** (Esquerda)
- **Straight** (Reta)

#### **Preposições (Prepositions)**
- **On** (em/na - usado com nomes de ruas)
- **At** (no/na - usado com pontos de referência)
- **For** (por - usado para indicar distância/duração)

#### **Verbos (Verbs) - Novos e Revisão**
- **To get (to)** (Chegar a)
- **To go** (Ir)
- **To turn** (Virar)
- **To take** (Pegar)
- **To cross** (Atravessar)