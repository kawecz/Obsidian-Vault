---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - adjetivos_pronomes
---

---
<iframe title="Inglês | Kultivi Extra Class - Places in Town I | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/XvWjZqx2JOo?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Lugares na Cidade (Places in Town) - Parte 1: Vocabulário
> Esta é a primeira de três aulas sobre locais na cidade. O foco aqui é expandir o vocabulário e introduzir verbos relacionados a atividades realizadas nesses lugares. A estrutura "A place where people..." será usada para definir cada local.

[[../aula5.pdf|aula5]]

---

### **Lista de Lugares e Suas Definições**
| Local (Inglês) | Local (Português) | Definição (O que é?) |
| :--- | :--- | :--- |
| **Airport** | Aeroporto | A place where people **take planes** to **travel**. |
| **Bar** | Bar | A place where people **drink**, **listen to music**, and **talk**. |
| **Bookstore / Bookshop** | Livraria | A place where people **buy books**. |
| **Bus Station** | Rodoviária | A place where people **take a bus** to **travel**. |
| **Bus Stop** | Ponto de Ônibus | A place where people **take buses** to **move** in the city. |
| **Butcher Shop** | Açougue | A place where people **buy meat**. |
| **Church** | Igreja | A place where people **pray** and **give thanks**. |
| **City Hall** | Prefeitura | A place where the **Mayor works**. |
| **Clothing Store** | Loja de Roupas | A place where people **buy clothes**. |
| **Coffee Shop** | Cafeteria | A place where people **meet friends**, **drink coffee**, and **talk**. |
| **Florist** | Floricultura | A place where people **buy flowers**. |
| **Gas Station** | Posto de Gasolina | A place where people **fill up** the **gas tank**. |
| **Gym** | Academia | A place where people **work out** to **get fit**. |
| **Library** | Biblioteca | A place where people **study**, **read**, or **borrow books**. |
| **Movie Theater** | Cinema | A place where people **watch movies**. |
| **Night Club** | Boate | A place where people go to **dance** and **have fun**. |
| **Park** | Parque | A place where people go to **walk** and **relax**. |
| **Police Station** | Delegacia de Polícia | A place where **police officers work**. |
| **Post Office** | Correio | A place for people to **mail letters** and **postcards**. |
| **School** | Escola | A place where **teachers teach** and **students learn**. |
| **Shopping Center / Mall** | Shopping Center | A place where people **see** and **buy many different things**. |
| **Supermarket** | Supermercado | A place where people **buy things for the house**. |
| **Zoo** | Zoológico | A place where people **see wild animals**. |

---

### **Lista de Verbos Novos**
| Verbo | Significado | Exemplo de Uso |
| :--- | :--- | :--- |
| **To take** | Pegar, levar, tomar | `Take a plane`, `Take a bus`, `Take the kids to school` |
| **To travel** | Viajar | `People travel to other cities.` |
| **To drink** | Beber | `People drink coffee.` |
| **To listen to** | Ouvir | `Listen to music.` |
| **To talk** | Conversar | `Talk to friends.` |
| **To buy** | Comprar | `Buy books`, `Buy flowers`, `Buy meat` |
| **To pray** | Rezar | `Pray in a church.` |
| **To thank** | Agradecer | `Thank you` (obrigado) vem deste verbo. |
| **To meet** | Encontrar, conhecer | `Meet friends at a coffee shop.` |
| **To work** | Trabalhar | `The Mayor works at City Hall.` |
| **To work out** | Malhar, fazer exercício | `Work out at the gym.` |
| **To study** | Estudar | `Study at the library.` |
| **To read** | Ler | `Read books.` |
| **To borrow** | Pegar emprestado | `Borrow books from the library.` |
| **To watch** | Assistir | `Watch movies at the cinema.` |
| **To walk** | Caminhar, andar | `Walk in the park.` |
| **To relax** | Relaxar | `Relax in the park.` |
| **To mail / To send** | Enviar (correio) | `Mail a letter at the post office.` |
| **To teach** | Ensinar | `Teachers teach at school.` |
| **To learn** | Aprender | `Students learn at school.` |
| **To see** | Ver | `See wild animals at the zoo.` |
| **To dance** | Dançar | `Dance at a night club.` |
| **To have fun** | Divertir-se | `Have fun with friends.` |
| **To fill up** | Encher | `Fill up the gas tank.` |
| **To get fit** | Ficar em forma | `Get fit at the gym.` |

---

### **Análise Gramatical e Vocabulário Extra**

#### **Substantivos (Nouns)**
- **Locais:** Airport, Bar, Bookstore, Bus Station, Bus Stop, Butcher Shop, Church, City Hall, Clothing Store, Coffee Shop, Florist, Gas Station, Gym, Library, Movie Theater, Night Club, Park, Police Station, Post Office, School, Shopping Center, Supermarket, Zoo.
- **Coisas:** Plane, Bus, Music, Book, Meat, Coffee, Flower, Gas Tank, Letter, Postcard, Movie, Wild Animal.
- **Pessoas:** People, Mayor, Police Officer, Teacher, Student, Friend.

#### **Adjetivos (Adjectives)**
- **Wild** (selvagem) - `Wild animals`
- **Different** (diferente) - `Different things`
- **Many** (muitos) - `Many things`

#### **Preposições (Prepositions)**
- **To** - `Listen to music`, `Go to the movies`
- **For** - `Buy things for the house`
- **In** - `Walk in the park`
- **At** - `Meet at the coffee shop`
- **With** - `Talk with friends`

#### **Observações Importantes**
- **Linking Sound:** Quando uma palavra termina com a consoante `S` e a seguinte começa com `S`, os sons se unem. Exemplo: `Bus Station` soa como "bu station".
- **e- prefix:** O "e" em `e-mail` significa `electronic` (eletrônico). O mesmo vale para `e-class` (aula online) e `e-shop` (loja online).
- **Who vs. Whom:** `Who` é para o sujeito da ação. `Whom` (mais formal) é usado quando é o objeto da ação e vem após uma preposição (to, with, for).
- **To Borrow vs. To Lend:** `To borrow` = pegar emprestado. `To lend` = emprestar.