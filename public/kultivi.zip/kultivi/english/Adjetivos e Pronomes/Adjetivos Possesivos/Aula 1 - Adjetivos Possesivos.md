---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - adjetivos_pronomes
---

---
<iframe title="Inglês | Kultivi Extra Class - Possessive Adjectives | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/cMryyfeIhwM?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula Extra: Adjetivos Possessivos (Possessive Adjectives)
> Esta aula foca nos adjetivos possessivos em inglês, palavras que indicam posse ou relação. Diferente do português, eles são muito mais simples, pois não variam em gênero (masculino/feminino) ou número (singular/plural), mantendo a mesma forma independentemente do que possuem.

[[aula1.pdf]]

---

### 📘 Tópicos da Aula
1.  **O que são Adjetivos Possessivos:** Definição e função
2.  **Comparação com o Português:** A simplicidade do inglês
3.  **Lista Completa de Adjetivos Possessivos**
4.  **Pronúncia de `His` e `Her`**
5.  **Prática com Cores e Frases**

---

### 📖 Conteúdo Detalhado

#### 1. O que são Adjetivos Possessivos?
São palavras que indicam a quem algo pertence. Eles sempre acompanham um substantivo.
- **Exemplo:** `My car` (Meu carro). `My` indica que o carro pertence a "mim".

#### 2. Comparação: Português vs. Inglês
A grande vantagem do inglês é a simplicidade.

| Posse em Português | Adjetivo em Inglês | Exemplo em Inglês |
| :--- | :--- | :--- |
| Meu, Minha, Meus, Minhas | **My** | `My car` (Meu carro), `My cars` (Meus carros), `My sister` (Minha irmã), `My sisters` (Minhas irmãs) |
| Teu, Tua, Teus, Tuas, Seu, Sua, Seus, Suas | **Your** | `Your house` (Sua casa), `Your friends` (Seus amigos) |
| Dele | **His** | `His book` (Livro dele) |
| Dela | **Her** | `Her cat` (Gato dela) |
| Dele/Dela (para coisas/animais) | **Its** | `Its color` (A cor dele/dela - do objeto) |
| Nosso, Nossa, Nossos, Nossas | **Our** | `Our school` (Nossa escola) |
| Seus, Suas (de vocês) | **Your** | `Your bags` (As mochilas de vocês) |
| Deles, Delas | **Their** | `Their bikes` (As bicicletas deles) |

#### 3. Lista Completa dos Adjetivos Possessivos
| Pronome Pessoal | Adjetivo Possessivo | Pronúncia (Dica) | Exemplo |
| :--- | :--- | :--- | :--- |
| **I** (Eu) | **My** (Meu/Minha) | "mai" | `My name is...` |
| **You** (Você) | **Your** (Seu/Sua) | "iôr" | `Your phone.` |
| **He** (Ele) | **His** (Dele) | "rîs" | `His car.` |
| **She** (Ela) | **Her** (Dela) | "hêr" | `Her job.` |
| **It** (Ele/Ela - coisa/animal) | **Its** (Dele/Dela) | "its" | `Its door.` (A porta dele - do carro) |
| **We** (Nós) | **Our** (Nosso/Nossa) | "auâr" | `Our house.` |
| **You** (Vocês) | **Your** (Seus/Suas) | "iôr" | `Your keys.` |
| **They** (Eles/Elas) | **Their** (Deles/Delas) | "dêar" | `Their friends.` |

#### 4. Pronúncia Correta: `His` vs. `Her`
- **`His` (Dele):** Pronúncia correta é **"rîs"**, com som de "i" curto. **Não é "rís"**.
- **`Her` (Dela):** Pronúncia correta é **"hêr"**, com som de "ê" aberto.
    - **Cuidado com confusões:**
        - `Her` (dela) -> "hêr"
        - `Hair` (cabelo) -> "hêr"
        - `Here` (aqui) -> "hîar"

#### 5. Prática com Cores e Frases
**Vocabulário de Cores:**
- `White` (Branco), `Yellow` (Amarelo), `Blue` (Azul), `Grey` (Cinza), `Orange` (Laranja), `Red` (Vermelho), `Purple` (Roxo), `Green` (Verde), `Black` (Preto), `Pink` (Rosa), `Brown` (Marrom)

**Perguntas e Respostas:**
- **What color is your house?** (Qual a cor da sua casa?)
    - `My house is white.` (Minha casa é branca.)
- **What color is his suit?** (Qual a cor do terno dele?)
    - `His suit is brown.` (O terno dele é marrom.)
- **What color is her car?** (Qual a cor do carro dela?)
    - `Her car is pink.` (O carro dela é rosa.)
- **What is its color?** (Qual a cor dele? - falando de um animal/objeto)
    - `Its color is black.` (A cor dele é preta.)
- **What color are our umbrellas?** (Qual a cor dos nossos guarda-chuvas?)
    - `Our umbrellas are purple.` (Nossos guarda-chuvas são roxos.)
- **What color are your backpacks?** (Qual a cor das mochilas de vocês?)
    - `Your backpacks are blue.` (As mochilas de vocês são azuis.)
- **What color are their bikes?** (Qual a cor das bicicletas deles?)
    - `Their bikes are yellow.` (As bicicletas deles são amarelas.)

---

### 📚 Categorização de Palavras-Chave

**Adjetivos Possessivos (Possessive Adjectives):**
`my`, `your`, `his`, `her`, `its`, `our`, `their`

**Substantivos (Nouns):**
`name`, `house`, `car`, `suit`, `color`, `umbrella`, `backpack`, `bike`

**Cores (Colors):**
`white`, `yellow`, `blue`, `grey`, `orange`, `red`, `purple`, `green`, `black`, `pink`, `brown`

**Pronomes (Pronouns):**
`I`, `you`, `he`, `she`, `it`, `we`, `they`

---

### 💡 Dicas do Professor
- **Uma Forma para Tudo:** A maior dica é lembrar que cada adjetivo possessivo em inglês tem uma única forma, ao contrário do português. `My` serve para "meu", "minha", "meus" e "minhas".
- **Cuidado com a Pronúncia:** Preste muita atenção para não confundir `his` ("rîs") com "rís", e `her` ("hêr") com `hair` (cabelo) ou `here` (aqui).
- **Use `Its` para Coisas:** Lembre-se de usar `its` para objetos, animais e coisas. Não use `his` ou `her` para um carro, um livro ou um gato, a menos que queira personificá-los.
- **Pratique com Objetos ao Seu Redor:** Olhe para os objetos ao seu redor e pratique frases: "This is my phone. That is your book. This is his chair."