---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - adjetivos_pronomes
---

---
<iframe title="Inglês | Kultivi Extra Class - To Be: Past | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/jff35-tPHDc?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Verbo "To Be" no Passado (Was/Were)
> Esta aula rápida aborda a conjugação do verbo "to be" (ser/estar) no passado simples (Simple Past). Aprenda a usar "was" e "were" em frases afirmativas, negativas e interrogativas.

[[aula6.pdf]]

---

### **Conjugação do Verbo "To Be" no Passado**

| Pronome | Verbo (Passado) | Forma Contraída (Afirmativa) | Forma Contraída (Negativa) | Tradução (Ser/Estar) |
| :--- | :--- | :--- | :--- | :--- |
| I | Was | I'm → I was | Was not → Wasn't | Eu era/estava |
| You | Were | You're → You were | Were not → Weren't | Você era/estava |
| He | Was | He's → He was | Was not → Wasn't | Ele era/estava |
| She | Was | She's → She was | Was not → Wasn't | Ela era/estava |
| It | Was | It's → It was | Was not → Wasn't | Ele/Ela (coisa/animal) era/estava |
| We | Were | We're → We were | Were not → Weren't | Nós éramos/estávamos |
| You | Were | You're → You were | Were not → Weren't | Vocês eram/estavam |
| They | Were | They're → They were | Were not → Weren't | Eles/Elas eram/estavam |

---

### **Estruturas das Frases**

#### **1. Afirmativa (Affirmative)**
**Sujeito + Was/Were + Complemento.**
- **I was a student.** (Eu era um aluno.)
- **She was here.** (Ela estava aqui.)
- **We were tired.** (Nós estávamos cansados.)

#### **2. Negativa (Negative)**
**Sujeito + Was/Were + Not + Complemento.**
- **I was not a student.** / **I wasn't a student.** (Eu não era um aluno.)
- **She was not here.** / **She wasn't here.** (Ela não estava aqui.)
- **We were not tired.** / **We weren't tired.** (Nós não estávamos cansados.)

#### **3. Interrogativa (Questions)**
**Was/Were + Sujeito + Complemento?**
- **Were you a student?** (Você era um aluno?)
    - **Resposta Curta:** `Yes, I was.` / `No, I wasn't.`
- **Was she here?** (Ela estava aqui?)
    - **Resposta Curta:** `Yes, she was.` / `No, she wasn't.`
- **Were they tired?** (Eles estavam cansados?)
    - **Resposta Curta:** `Yes, they were.` / `No, they weren't.`

---

### **Análise Gramatical**

- **Verbos (Verbs):** O foco é a conjugação do verbo **To Be** no passado: **Was** e **Were**.
- **Advérbios (Adverbs):** **Not** para a forma negativa.
- **Contrações (Contractions):** `Was not` vira `Wasn't`; `Were not` vira `Weren't`.