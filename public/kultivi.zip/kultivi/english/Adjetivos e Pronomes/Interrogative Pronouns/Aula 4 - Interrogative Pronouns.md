---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - adjetivos_pronomes
---

---
<iframe title="Inglês | Kultivi Extra Class - Interrogative Pronouns | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/ieBP0p_DiKg?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula: Pronomes Interrogativos (Question Words)
> Esta aula aborda os pronomes interrogativos em inglês, também conhecidos como *Question Words* ou *W-Questions*, devido à maioria começar com "Wh". Essas palavras são fundamentais para a construção de perguntas, indo além do uso simples de auxiliares como *do*, *does* ou *did*.

[[aula4.pdf]]

---

### **Lista dos Pronomes Interrogativos**
| Pronome | Significado Básico | Função Principal |
| :--- | :--- | :--- |
| **What** | O que / Qual | Perguntar sobre coisas, objetos, atividades. |
| **Where** | Onde / Aonde | Perguntar sobre lugares e localização. |
| **When** | Quando | Perguntar sobre tempo e momentos. |
| **Why** | Por que / Por quê | Perguntar sobre razões e causas. |
| **Who** | Quem | Perguntar sobre pessoas (sujeito da ação). |
| **Whom** | Quem | Perguntar sobre pessoas (objeto da ação, usado com preposição). |
| **Whose** | De quem | Perguntar sobre posse. |
| **Which** | Qual / Quais | Perguntar sobre escolhas entre opções específicas. |
| **How** | Como / Quão | Perguntar sobre maneiras, condições, estados. |

---

### **What (O que / Qual)**
- **Uso 1 (Qual):** Seguido de um substantivo para perguntar sobre algo específico.
    - **Exemplo:** `What color do you prefer?` (Qual cor você prefere?)
    - **Resposta:** `I prefer red.`
- **Uso 2 (O que):** Para perguntar sobre atividades ou coisas de forma geral.
    - **Exemplo:** `What do you want to do now?` (O que você quer fazer agora?)
    - **Nota:** O `do` nesta frase é um **verbo auxiliar** para formar a interrogativa e não é traduzido.

**Estrutura:**
- `What + [substantivo] + do/does + sujeito + verbo...?` (PARA "QUAL")
- `What + do/does + sujeito + verbo...?` (PARA "O QUE")

---

### **Where (Onde / Aonde)**
- **Significado:** Usado para perguntar sobre lugares. Diferente do português, não há distinção entre "onde" (estático) e "aonde" (movimento).
- **Exemplo 1 (Estático):** `Where do you live?` (Onde você mora?)
- **Exemplo 2 (Movimento):** `Where do you want to go?` (Aonde você quer ir?)

**Pronúncia:** A pronúncia correta é /wɛər/, semelhante a "uér", e não "uéri".

---

### **When (Quando)**
- **Significado:** Pergunta sobre tempo.
- **Exemplo 1:** `When does she like to study?` (Quando ela gosta de estudar?)
- **Exemplo 2:** `When are we going to the movies?` (Quando nós vamos ao cinema?)
- **Estrutura:** O pronome interrogativo sempre vem **antes do verbo auxiliar** (`does`, `are`).

---

### **Why (Por que) & Because (Porque)**
- **Why:** Usado **sempre para perguntas**.
    - **Exemplo:** `Why do you want to learn English?` (Por que você quer aprender inglês?)
- **Because:** Usado **sempre para respostas**.
    - **Resposta:** `Because I love English.` (Porque eu amo inglês.)
- **Gíria/Resposta Informal:** `Just because.` (Porque sim/não. - sem dar explicações)
- **Formas Coloquiais de "Because":** `'cause` ou `cuz`.

---

### **Who (Quem)**
- **Uso como Sujeito:** Quando "quem" pratica a ação, **não usa** verbo auxiliar. O verbo é conjugado na 3ª pessoa do singular.
    - **Exemplo:** `Who works with you?` (Quem trabalha com você?) | `Who drives your car?`
- **Uso como Objeto:** Quando "quem" sofre a ação, **usa** verbo auxiliar.
    - **Exemplo:** `Who do you work with?` (Com quem você trabalha?) - A preposição (`with`) fica no final na linguagem informal/cotidiana.

---

### **Whom (Quem)**
- **Uso:** Formal. Usado quando "quem" é o **objeto da frase e é precedido por uma preposição** (to, with, for).
- **Exemplo 1:** `With whom are you talking?` (Com quem você está falando?) - Estrutura formal.
- **Exemplo 2:** `To whom I have to work?` (Com quem eu tenho que trabalhar?) - Estrutura formal.
- **Na linguagem do dia a dia,** `who` é frequentemente usado no lugar de `whom`.

---

### **Whose (De quem)**
- **Significado:** Pergunta sobre posse, propriedade.
- **Estrutura 1:** `Whose + [substantivo] + is/are...?`
    - **Exemplo:** `Whose car is this?` (De quem é este carro?)
- **Estrutura 2:** `Whose + is/are + [substantivo]...?`
    - **Exemplo:** `Whose is this car?` (De quem é este carro?) - Ambas as estruturas são corretas.

---

### **Which (Qual / Quais)**
- **Uso:** Para perguntar sobre escolhas entre opções **específicas ou limitadas**. Pode substituir o `What` quando há opções explícitas ou implícitas.
- **Exemplo 1 (Opções explícitas):** `Which color do you prefer, black or white?` (Qual cor você prefere, preto ou branco?)
- **Exemplo 2 (Opções implícitas):** `Which car do you prefer?` (Qual carro você prefere?) - Implica uma escolha entre os carros que existem/você conhece.

---

### **How (Como / Quão)**
- **Uso Básico:** Perguntar sobre maneira, estado ou condição.
    - **Exemplo 1:** `How do you go to school?` (Como você vai à escola?) - `I go by car.`
    - **Exemplo 2:** `How does she like her coffee?` (Como ela gosta do café?) - `She likes it strong.`

#### **Derivações do "How"**
| Expressão | Significado | Uso | Exemplo |
| :--- | :--- | :--- | :--- |
| **How much** | Quanto / Quanta | Substantivos **INCONTÁVEIS** (água, tempo, dinheiro) | `How much water do you want?` (Quanta água você quer?) |
| **How many** | Quantos / Quantas | Substantivos **CONTÁVEIS** (horas, carros, pessoas) | `How many hours do you have?` (Quantas horas você tem?) |
| **How long** | Por quanto tempo / Quão longo | Duração ou comprimento físico | `How long is the movie?` (Quanto tempo dura o filme?) |
| **How tall** | Quão alto | Altura de pessoas/objetos altos e finos | `How tall are you?` (Quão alto você é?) |
| **How big** | Quão grande | Tamanho geral/área | `How big is the room?` (Quão grande é o quarto?) |
| **How small** | Quão pequeno | Tamanho pequeno | `How small is a bean?` (Quão pequeno é um grão de feijão?) |

---

### **Análise Gramatical (Palavras-Chave da Aula)**
- **Nouns (Substantivos):** Color, car, school, coffee, money, water, time, hours, movie, room, bean.
- **Adjectives (Adjetivos):** Red, black, white, strong, tall, big, small.
- **Prepositions (Preposições):** With, to, for, by, of.
- **Verbos Auxiliares:** Do, does, did, are, is.