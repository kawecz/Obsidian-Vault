---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - adjetivos_pronomes
---

---
<iframe title="Inglês | Kultivi Extra Class - Numbers and Addresses | CURSO GRATUITO COMPLETO - Aula #11" src="https://www.youtube.com/embed/eL6huQdE4Nk?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula 11: Números, Endereços e Telefones
> Esta aula prática ensina a dizer endereços completos e números de telefone em inglês, focando no uso correto das preposições `in`, `on` e `at`. É uma aula essencial para situações do dia a dia, como preencher formulários ou dar informações de contato.


[[aula2.pdf]]

---

### 📘 Tópicos da Aula
1.  **Perguntando "Onde você mora?":** `Where do you live?`
2.  **Preposições de Localização:** `in`, `on`, `at`
3.  **Estrutura de um Endereço Completo**
4.  **CEP (Zip Code)**
5.  **Números de Telefone**

---

### 📖 Conteúdo Detalhado

#### 1. Perguntando "Onde você mora?"
- **Pergunta Principal:** `Where do you live?` (Onde você mora?)
- **Verbo "To Live":** Significa "morar" ou "viver". Pronúncia: **"lív"**. Cuidado para não confundir com `to leave` ("partir"), que se pronuncia "lîv".

#### 2. Preposições de Localização: `In`, `On`, `At`
A preposição muda dependendo da especificidade do local.

| Preposição | Uso | Exemplo |
| :--- | :--- | :--- |
| **IN** | Países, Estados, Cidades, Bairros (áreas amplas) | `I live in Brazil.` (País)<br>`I live in Paraná.` (Estado)<br>`I live in Curitiba.` (Cidade)<br>`I live in Água Verde.` (Bairro) |
| **ON** | Nomes de Ruas, Avenidas, Estradas (sem o número) | `I live on Chile Street.`<br>`I live on Presidente Kennedy Avenue.`<br>`I live on BR-277 Road.` |
| **AT** | Endereços completos (quando inclui o número) | `I live at 782 Chile Street.` |

**Regra Prática:**
- **IN** -> Lugares grandes (País, Estado, Cidade, Bairro)
- **ON** -> Vias (Rua, Avenida, Estrada) *sem o número*
- **AT** -> Endereço completo *com o número*

#### 3. Estrutura de um Endereço Completo
A ordem em inglês é diferente do português.

- **Português:** Número DEPOIS do nome da rua.
    - Ex: Rua Chile, 782
- **Inglês:** Número ANTES do nome da rua.
    - Ex: `782 Chile Street`

**Pergunta para o Endereço Completo:**
- `What's your address?` (Qual é o seu endereço?)
- **Resposta:** `It's [número] [nome da rua] [tipo de via].`
    - Ex: `It's 782 Chile Street.`

**Abreviações Comuns:**
- `Street` -> `St.`
- `Avenue` -> `Ave.`
- `Road` -> `Rd.`

#### 4. CEP (Zip Code)
- **Em inglês:** `Zip Code`
- **Pergunta:** `What's your zip code?`
- **Resposta:** Digite os números individualmente.
    - Ex: `It's 8-3-2-0-0-0-0-0-0-0.` (Para o CEP 83200-000)

#### 5. Números de Telefone (Phone Numbers)
- **Pergunta:** `What's your phone number?`
- **Pergunta Específica:**
    - `What's your landline?` (Qual é seu telefone fixo?)
    - `What's your cell phone number?` (Qual é seu celular?)

**Como Dizer o Número:**
- A forma mais comum é dizendo os números em **pares (duplas)**.
- O número **zero** é frequentemente dito como **`oh`**.
- Pode-se usar **`double`** para números repetidos.
- **Exemplo:** Para o número `(41) 98765-4321`
    - `It's four-one, nine-eight-seven, six-five, four-three-two-one.`
    - Ou: `It's four-one, nine-eight-seven, six-five, four-three, two-one.`

**Pronúncia dos Números (0-9):**

| Número | Pronúncia |
| :--- | :--- |
| **0** | `zero` ou `oh` |
| **1** | `one` |
| **2** | `two` |
| **3** | `three` |
| **4** | `four` |
| **5** | `five` |
| **6** | `six` |
| **7** | `seven` |
| **8** | `eight` |
| **9** | `nine` |

---

### 📚 Categorização de Palavras-Chave

**Substantivos (Nouns):**
`address`, `country`, `state`, `city`, `neighborhood`, `street`, `avenue`, `road`, `zip code`, `phone number`, `landline`, `cell phone`

**Verbos (Verbs):**
`to live` (morar/viver)

**Preposições (Prepositions):**
`in`, `on`, `at`

**Pronomes (Pronouns):**
`I`, `you`, `your`

---

### 💡 Dicas do Professor
- **A Ordem do Endereço é Invertida:** Sempre coloque o número primeiro: `[Número] [Nome da Rua]`.
- **Preposições são Guias, Não Regras:** Usar a preposição errada (ex: `in` instead of `on`) não impedirá a comunicação. Aprenda as regras, mas não se paralise por medo de errar.
- **Pratique com Seu Próprio Endereço:** A melhor maneira de aprender é praticando com informações reais. Treine dizer seu próprio endereço completo e número de telefone em inglês.
- **"Oh" para Zero:** Em números de telefone, `oh` soa mais natural do que `zero`.
- **Contexto é Tudo:** `Where do you live?` pode ser respondido de maneira geral (com `in`) ou específica (com `on` ou `at`), dependendo do que a conversa pede.