---
banner: https://yt3.googleusercontent.com/ceSNNxBQ4TNr_egBCvoROlo9O8p_HXsVqZcgZo0aNUVMB8CfW9ecn3EzNLkFp2CV5Fd8KYQO=s900-c-k-c0x00ffffff-no-rj
tags:
  - kultivi-ingles
  - adjetivos_pronomes
---

---
<iframe title="Inglês | Kultivi Extra Class - Modal Verbs | CURSO GRATUITO COMPLETO | CURSO GRATUITO COMPLETO" src="https://www.youtube.com/embed/hjFuG2PROKs?feature=oembed" height="113" width="200" style="aspect-ratio: 1.76991 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>

---
> [!abstract] Aula Extra: Verbos Modais (Modal Verbs)
> Esta aula explora os verbos modais em inglês, uma categoria especial de verbos auxiliares que expressam habilidade, possibilidade, permissão, obrigação, conselho e intenção futura. Eles são irregulares e seguem suas próprias regras, não necessitando de auxiliares como `do`/`does` e não se flexionam na terceira pessoa do singular.

[[aula3.pdf]]

---

### 📘 Tópicos da Aula
1.  **O que são Verbos Modais:** Características e regras gerais
2.  **Lista dos Principais Verbos Modais:** `can`, `could`, `may`, `might`, `must`, `shall`, `should`, `will`, `would`
3.  **Uso e Aplicação de Cada Modal:** Com exemplos práticos
4.  **Formas Afirmativa, Negativa e Interrogativa**

---

### 📖 Conteúdo Detalhado

#### 1. Regras Gerais dos Verbos Modais
- **Não flexionam na 3ª pessoa do singular:** Eles **nunca** recebem `-s`, `-es` ou `-ies`.
    - Correto: `She can work.` ❌ Errado: `She cans work.`
- **Não usam o auxiliar `do`/`does`/`did`:** Eles próprios funcionam como auxiliares.
    - Correto: `Can he work?` ❌ Errado: `Does he can work?`
- **Não são usados com `to` no infinitivo:** O verbo principal que os segue fica no infinitivo sem `to`.
    - Correto: `I can work.` ❌ Errado: `I can to work.`
- **Precisam de um verbo principal:** Eles não podem formar uma frase sozinhos.
    - Correto: `I can swim.` ❌ Incorreto/Sem sentido: `I can.`

#### 2. Lista e Uso dos Verbos Modais

| Modal Verb | Uso Principal | Exemplo | Tradução |
| :--- | :--- | :--- | :--- |
| **Can** | Habilidade, Possibilidade, Pedido/Permissão (informal) | `You can swim.` `I can stay.` `Can I go?` | Você sabe nadar. Eu posso ficar. Posso ir? |
| **Could** | Passado de "can", Possibilidade, Pedido/Permissão (mais formal) | `I could fly kites.` `Could you help me?` | Eu sabia empinar pipas. Você poderia me ajudar? |
| **May** | Possibilidade, Pedido/Permissão (formal) | `It may rain.` `May I help you?` | Pode chover. Posso ajudá-lo? |
| **Might** | Possibilidade Remota | `It might rain.` (céu está claro) | Pode ser que chova. |
| **Must** | Obrigação Forte, Dever | `You must stop smoking.` | Você deve parar de fumar. |
| **Shall** | Sugestão, Intenção Futura (formal, usado com `I`/`we`) | `Shall we dance?` | Que tal dançarmos? |
| **Should** | Conselho | `You should study.` | Você deveria estudar. |
| **Will** | Futuro, Decisões | `We will win.` | Nós vamos vencer. |
| **Would** | Forma condicional ("ia"), Pedidos formais | `I would like coffee.` `Would you help me?` | Eu gostaria de café. Você me ajudaria? |

#### 3. Formas Negativa e Interrogativa
A estrutura é a mesma para todos os modais: o modal vem antes do sujeito na interrogativa e é seguido por `not` na negativa.

| Tipo | Estrutura | Exemplo com `Can` | Exemplo com `Should` |
| :--- | :--- | :--- | :--- |
| **Afirmativa** | Sujeito + Modal + Verbo Principal | `She can work.` | `You should go.` |
| **Negativa** | Sujeito + Modal + **not** + Verbo Principal | `She **cannot** work.` / `She **can't** work.` | `You **should not** go.` / `You **shouldn't** go.` |
| **Interrogativa** | **Modal** + Sujeito + Verbo Principal | **Can** she work? | **Should** I go? |
| **Interrogativa Negativa**| **Modal** + Sujeito + **not** + Verbo Principal | **Can't** she work? | **Shouldn't** we go? |

**Contrações Negativas Comuns:**
- `cannot` -> `can't`
- `could not` -> `couldn't`
- `will not` -> `won't`
- `would not` -> `wouldn't`
- `should not` -> `shouldn't`
- `must not` -> `mustn't`

---

### 📚 Categorização de Palavras-Chave

**Verbos Modais (Modal Verbs):**
`can`, `could`, `may`, `might`, `must`, `shall`, `should`, `will`, `would`

**Verbos Principais (Main Verbs):**
`work`, `swim`, `stay`, `help`, `go`, `rain`, `dance`, `stop`, `try`, `ask`, `survive`, `like`, `believe`, `see`

**Partículas de Negação:**
`not`, `n't` (contração)

---

### 💡 Dicas do Professor
- **Nunca o "-s":** Esta é a regra de ouro. Se você está usando um modal (`can`, `should`, etc.), o verbo principal nunca ganha um "s", mesmo com `he`, `she` ou `it`.
- **Eles São os Auxiliares:** Em frases interrogativas e negativas, os modais já cumprem a função do `do`/`does`. Não use os dois juntos.
- **Sem "To":** Após um modal, o verbo principal sempre vem no infinitivo sem `to`.
- **Grau de Formalidade:** Use `can` para pedidos informais, `could` para ser mais educado e `may` para situações muito formais.
- **Pratique com a Sua Rotina:** Pense em frases sobre o seu dia usando os modais. Ex: `I can speak English.` `I must go to work.` `I should drink more water.`